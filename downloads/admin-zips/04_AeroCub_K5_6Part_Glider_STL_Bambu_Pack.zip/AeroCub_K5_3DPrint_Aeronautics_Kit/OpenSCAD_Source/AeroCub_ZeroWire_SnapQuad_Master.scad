// ============================================================================
// OSITO DRONE LLC — ZERO-WIRE SNAPQUAD (Aero-Cub K-5 / CUB-75) MASTER CAD
// 100% Support-Free (0.00g Support), Watertight 2-Manifold CSG (OpenSCAD 2021)
// ============================================================================
// Engineering & Printability Specifications:
// 1. True-X 75.00mm Wheelbase (R_motor = 37.50mm at 45°, 135°, 225°, 315°:
//    R_mouth = 9.60mm + D_shoulder = 27.90mm = 37.50mm exact)
// 2. 42.00mm ID / 44.44mm OD (45.60mm Outer Rim) x 8.70mm Ultralight Prop Ducts
//    -> 1.00mm/side tip clearance for 40.0mm Gemfan 1610-2 / 1608-3 props
// 3. 1002 / 0802 3-Hole M1.4 Motor Mounts (6.6mm PCD at 60°/180°/300°),
//    Ø3.00mm Shaft/C-Clip Relief Bore & 45° Conical M1.4 Screw Counterbores
// 4. 4.30mm Wide 0° Conduit Strut (1.05mm Sidewalls) w/ 45° Gabled Channel +
//    3x Staggered Snap-Detent Wire Retention Nubs (Zero-Glue Captive Routing)
// 5. Bourns 70AAJ-3-M0G (or Mill-Max 811-22-003-30-001101) 3-Pin 2.54mm
//    Male Spring Header Pocket in Frame (R_backstop = 3.68mm) + Bourns
//    70AAJ-3-F0G Female 3-Pad Target Strip Pocket in Pods (R_backstop = 8.40mm)
//    -> 4.720mm Backstop Span (+0.39mm Bourns / +1.08mm Mill-Max 811 Preload,
//       Coaxial Z = 5.440mm, 45° Self-Supporting Roofs, <=4.7mm Bridges)
// 6. 100% Support-Free 45° Diamond-V Keyed Dovetails & Elephant-Foot Chamfers:
//    Key A = 5.00mm Twin-Prong (CCW), Key B = 3.60mm Solid Rib (CW)
// 7. 25.5x25.5mm Cardinal Whoop AIO FC Standoffs (Z = 13.10mm, Ø1.80mm M2
//    Self-Tapping Bores -> +4.25mm Bare Clearance for Bottom JST-1.25 & USB-C)
//    + 4x Unobstructed >=3.34x6.54mm Pure-Vertical Quadrant FC Wire Windows
// 8. Rear (-Y) Captive BT2.0 Battery Pigtail Strain-Relief C-Clip on SQ01
// 9. Support-Free Gothic TPU 68D Bear-Cub Canopy w/ 4x Open Ø4.6mm M2 Screw
//    Counterbores, Teardrop LED Eyes, Gusseted Ears & Rear Ø3.0mm Antenna Port
// 10. Symmetric 45°-Arched 1S LiHV Battery Sled (<=5.3mm Bridge, 0 Overhang
//     Cliffs, 0.40mm Bottom Chamfers, Keyhole T-Lug + XY Snap Latch + 52mm Skids)
// ============================================================================

$fn = 36;

// CLI Parameter: openscad -o <out.stl> -D "PART=..." AeroCub_ZeroWire_SnapQuad_Master.scad
PART = 0;

// --- Geometric Constants (mm) ---
wheelbase_diag      = 75.0;
m_rad               = wheelbase_diag / 2.0; // 37.50 mm
m_xy                = m_rad / sqrt(2);      // 26.5165 mm

// Ducts (Optimized for 40.0mm Gemfan 1610-2 / 1608-3 props within 53.03mm spacing)
duct_id             = 42.0;                 // 1.00 mm/side tip clearance
duct_wall           = 1.22;                 // >= 1.20 mm (3 crisp 0.4mm Arachne walls)
duct_od             = duct_id + 2 * duct_wall; // 44.44 mm (r = 22.22 mm)
duct_height         = 8.70;                 // Clears radial USB-C overmold + saves mass
bumper_rim_od       = 45.60;                // +0.58mm radial x 45° outer crash bumper rim

// Motor Mount (1002 22000KV primary / 0802 compatible)
motor_boss_od       = 13.80;                // >= 2.175 mm solid outer wall around Ø2.85mm M1.4 counterbores
motor_boss_h        = 3.20;
motor_pcd           = 6.60;
motor_screw_dia     = 1.48;
motor_shaft_dia     = 3.00;                 // Clears C-clip & Ø2.7mm stator bearing boss

// Support-Free 45° Diamond-V Dovetail Joint Parameters (+0.175mm/side slip-fit)
arm_reach_r         = 9.60;                 // SQ01 socket mouth R = 9.60 mm
pod_tab_shoulder    = m_rad - arm_reach_r;  // 27.90 mm -> 9.60 + 27.90 = 37.50 mm exact!
dt_floor_z          = 0.48;                 // 3 solid 0.16mm PETG-CF floor layers in SQ01

// Male Diamond-V Dovetail Tab (Pod, Z_pod = 0.00..6.78mm -> Z_world = 0.48..7.26mm)
dt_male_w_stem      = 4.30;                 // Z_pod = 0.35..1.05mm (clears Z=1.44mm quadrant web)
dt_male_w_waist     = 9.90;                 // Exact 45° outward V-flare (Z_pod = 1.05..3.85..5.23mm)
dt_male_w_top       = 6.80;                 // Exact 45° inward roof (Z_pod = 5.23..6.78mm)
dt_male_h           = 6.78;
dt_male_chamf       = 0.35;                 // 0.35mm x 45° bottom elephant-foot relief

// Female Diamond-V Socket (Frame, Z_world = 0.40..8.14mm, +0.175mm/side & +0.16mm Z slip-fit)
dt_fem_w_stem       = 4.65;                 // +0.175 mm/side clearance
dt_fem_w_waist      = 10.25;                // +0.175 mm/side clearance
dt_fem_w_top        = 7.15;                 // +0.175 mm/side clearance at Z_world = 7.36mm
dt_fem_h_fit        = 6.96;                 // Z_local = 6.96mm (Z_world = 7.36mm > 7.26mm male top!)

// Bidirectional Polarizing Top Keying Ribs (Support-Free Outer Collar R=8.35..9.60mm)
key_a_w             = 5.00; // FL (M4 CCW) & RR (M1 CCW)
key_b_w             = 3.60; // FR (M2 CW)  & RL (M3 CW)
key_slot_a_w        = 5.35;
key_slot_b_w        = 3.95;
key_rib_top_z_pod   = 8.39; // Pod rib top Z_pod = 8.39mm (Z_world = 8.87mm, +4.23mm below FC!)

// Bourns 70AAJ-3-M0G / Mill-Max 811-22-003-30-001101 (SQ01) & Bourns 70AAJ-3-F0G (Pods)
// Coaxial centerline: Z_world = 5.440 mm (Z_pod = 4.960 mm + 0.480 mm, dY=dZ=0.000mm)
// Axial preload: R_backstop_fem = 3.680 mm, R_backstop_male = 8.400 mm -> 4.720 mm span!
// -> +0.39 mm preload on Bourns 70AAJ-3-M0G (3.81+1.30=5.11mm)
// -> +1.08 mm preload on Mill-Max 811-22-003-30-001101 (4.50+1.30=5.80mm, <=1.40mm stroke)
pogo_pitch          = 2.54;
pogo_fem_backstop_r = 3.68;
pogo_fem_w          = 7.76; // Fits 7.54mm Bourns 70AAJ-3-M0G & 7.62mm Mill-Max 811
pogo_fem_z0         = 4.30; // Preserves >=2.25mm PETG-CF Battery Armor Ceiling (Z_floor > 4.25mm!)
pogo_fem_h          = 2.64; // Z_world = 4.30..6.94 mm (center Z = 5.620 mm)
pogo_male_backstop_x= 29.10;// R_arm = 37.50 - 29.10 = 8.400 mm (8.40 - 3.68 = 4.720 mm!)
pogo_male_w         = 7.68; // Fits 7.52mm Bourns 70AAJ-3-F0G (+1.11mm solid pod walls)
pogo_male_z0        = 3.82; // Z_pod = 3.82..6.46 mm (center Z_world = 5.620 mm)
pogo_male_h         = 2.64;
pogo_male_d         = 1.30; // Exact 1.30mm Bourns 70AAJ-3-F0G housing depth

// Wire Routing
strut_w             = 4.30; // 1.05mm solid sidewalls around 2.20mm channel
strut_channel_w     = 2.20;
strut_channel_h_v   = 1.05; // Vertical wall before 45° gable peak at Z = 1.70mm
strut_channel_peak  = 1.70; // Preserves 3.20 - 1.70 = 1.50mm solid blade-shield roof!

// Whoop AIO FC Bay (25.5 x 25.5mm Cardinal Diamond: R = 18.0312 mm at 0°, 90°, 180°, 270°)
// Raised to Z = 13.10mm -> +4.25mm bare clearance over Z=8.85mm arm hoods for bottom JST-1.25mm!
fc_mount_span       = 25.5;
fc_radius           = fc_mount_span / sqrt(2); // 18.0312 mm
fc_hole_dia         = 1.80;                    // Self-tapping M2 screw bore (>=1.56mm boss wall)
frame_deck_h        = 3.25;
quad_web_h          = 1.44;                    // 9 solid 0.16mm PETG-CF layers in quadrant web
arm_hood_h          = 8.85;                    // 13.10 - 8.85 = 4.25mm >= 4.20mm bare JST clearance
fc_standoff_h       = 9.85;                    // Standoff top Z = 3.25 + 9.85 = 13.10 mm

// Battery Sled & Belly Rails
batt_len            = 58.0;
batt_w              = 18.5;
batt_h              = 7.40;
skid_span           = 52.0;
sled_arch_h         = 14.35;                   // 45° self-supporting dorsal arch (<=5.3mm bridge!)
sled_z_offset       = -(sled_arch_h + 0.25);   // -14.60 mm mated world Z translation for SQ07

// Positive overlap and negative cut epsilons for 100% 2-manifold CSG
eps  = 0.12;
eps2 = 2 * eps;


// ============================================================================
// HELPER MODULES (100% Support-Free 2-Manifold Polygon Extrusions)
// ============================================================================

// Extrudes a 2D (X, Z) polygon along +Y from y = y_start to y = y_start + length
// with +X -> +X_world and +Y_2D -> +Z_world directly (positive signed volume!).
module extrude_xz_along_y(y_start, length) {
    translate([0, y_start + length, 0])
        rotate([90, 0, 0])
            linear_extrude(height = length)
                children();
}

// Support-Free 45° Diamond-V Male Dovetail Prism along +X (Z=0..6.90mm)
module dovetail_male_diamond(length, w_stem=dt_male_w_stem, w_waist=dt_male_w_waist, w_top=dt_male_w_top, chamf=dt_male_chamf) {
    dz_flare = (w_waist - w_stem) / 2.0; // 2.80mm exact 45° flare
    dz_roof  = (w_waist - w_top) / 2.0;  // 1.55mm exact 45° roof
    rotate([90, 0, 90])
        linear_extrude(height = length)
            polygon([
                [-(w_stem/2 - chamf), 0.00],
                [ (w_stem/2 - chamf), 0.00],
                [  w_stem/2,          chamf],
                [  w_stem/2,          1.05],
                [  w_waist/2,         1.05 + dz_flare],
                [  w_waist/2,         dt_male_h - dz_roof],
                [  w_top/2,           dt_male_h],
                [ -w_top/2,           dt_male_h],
                [ -w_waist/2,         dt_male_h - dz_roof],
                [ -w_waist/2,         1.05 + dz_flare],
                [ -w_stem/2,          1.05],
                [ -w_stem/2,          chamf]
            ]);
}

// Support-Free 45° Diamond-V Female Dovetail Cutter along +X (Z_local=0 at Z_world=0.40mm)
// Tapers at <=45° all the way to a narrow 5.65mm crown (<<10mm bridge, >0.50mm solid top skin!).
module dovetail_female_diamond(length, w_stem=dt_fem_w_stem, w_waist=dt_fem_w_waist, w_top=dt_fem_w_top) {
    dz_flare = (w_waist - w_stem) / 2.0; // 2.80mm exact 45° upward V-cradle (nz > 0!)
    w_crown  = 5.65;                     // 5.65mm <= 10.0mm bridge!
    h_waist_top = dt_fem_h_fit - (w_waist - w_top) / 2.0; // 5.61mm
    h_crown     = dt_fem_h_fit + (w_top - w_crown) / 2.0; // 7.91mm (Z_world = 8.31mm < 8.85mm)
    rotate([90, 0, 90])
        linear_extrude(height = length)
            polygon([
                [-w_stem/2,  0.00],
                [ w_stem/2,  0.00],
                [ w_stem/2,  1.05],
                [ w_waist/2, 1.05 + dz_flare],
                [ w_waist/2, h_waist_top],
                [ w_top/2,   dt_fem_h_fit],
                [ w_crown/2, h_crown],
                [-w_crown/2, h_crown],
                [-w_top/2,   dt_fem_h_fit],
                [-w_waist/2, h_waist_top],
                [-w_waist/2, 1.05 + dz_flare],
                [-w_stem/2,  1.05]
            ]);
}

// 45°-Peaked Teardrop Cylinder along +Z (0° overhang crown when rotated horizontal!)
module teardrop_cyl_z(d, h) {
    r = d / 2.0;
    linear_extrude(height = h)
        hull() {
            circle(r = r, $fn = 28);
            polygon([
                [-r * 0.7071, r * 0.7071],
                [ r * 0.7071, r * 0.7071],
                [ 0,          r * 1.4142]
            ]);
        }
}


// ============================================================================
// MODULE 1: center_xframe (SQ01) — 0.00g Support PETG-CF Core
// ============================================================================
module center_xframe() {
    arm_reach = arm_reach_r; // Exact R = 9.60mm mouth -> R_motor = 9.60 + 27.90 = 37.50mm
    arm_w     = 13.30;       // (13.30 - 10.25)/2 = 1.525mm >= 1.50mm solid socket sidewalls

    difference() {
        union() {
            // 1. Central Hub + Battery Armor Foundation:
            // - Z = 0.00..1.92mm: Full 19.50 x 24.40mm battery bay lower deck
            // - Z = 0.00..3.25mm: r = 9.55mm (< 9.60mm mouth!) upper deck
            // - Z = 0.00..4.65mm: Central r = 6.95mm Battery Armor Dome
            hull() {
                cylinder(r = 9.55, h = 1.92);
                translate([-9.75, -12.2, 0])
                    cube([19.50, 24.4, 1.92]);
            }
            cylinder(r = 9.55, h = frame_deck_h);
            cylinder(r = 6.95, h = 4.65);

            // 2A. Fore/Aft (+Y / -Y) Cardinal FC Standoff Arms (90°, 270°, Z = 0..1.92mm)
            for (a = [90, 270]) {
                rotate([0, 0, a]) {
                    hull() {
                        translate([7.0, -3.4, 0])
                            cube([1.0, 6.8, 1.92]);
                        translate([fc_radius, 0, 0])
                            cylinder(d = 6.4, h = 1.92);
                    }
                }
            }

            // 2B. Left/Right (+X / -X) Cardinal Ribs & 4 Quadrant Wire-Window Deck Webs (Z = 0..1.44mm)
            for (sx = [-1, 1]) {
                for (sy = [-1, 1]) {
                    mirror([sx < 0 ? 1 : 0, 0, 0])
                        mirror([0, sy < 0 ? 1 : 0, 0])
                            linear_extrude(height = quad_web_h)
                                polygon([
                                    [ 9.20, 0.00],
                                    [20.49, 0.00],
                                    [20.49, 4.80],
                                    [18.20, 9.60],
                                    [ 9.20, 9.60]
                                ]);
                }
            }

            // 3. Rear (-Y) Cardinal BT2.0 Pigtail Strain-Relief C-Clip Boss
            hull() {
                translate([-3.30, -18.20, 0])
                    cube([6.60, 1.00, 4.80]);
                translate([-3.10, -22.10, 0])
                    cube([6.20, 1.00, 4.80]);
            }

            // 4. 4x Diagonal Receiving Arm Sockets (45°, 135°, 225°, 315°; Z = 0..8.85mm)
            // Leaves +4.25mm (>= 4.20mm) bare clearance below Z=13.10mm Whoop AIO standoffs!
            for (a = [45, 135, 225, 315]) {
                rotate([0, 0, a]) {
                    translate([2.60, -arm_w/2, 0])
                        cube([arm_reach - 2.60, arm_w, arm_hood_h]);
                }
            }

            // 5. 4x Raised Whoop AIO Standoff Posts (Z = 13.10mm, Ø4.92mm -> 1.56mm M2 Boss Wall)
            for (a = [0, 90, 180, 270]) {
                rotate([0, 0, a])
                    translate([fc_radius, 0, 0]) {
                        cylinder(d = 4.92, h = frame_deck_h + fc_standoff_h);
                        if (a == 90 || a == 270) {
                            translate([0, 0, 1.92 - eps])
                                cylinder(d1 = 6.16, d2 = 4.92, h = 0.62 + eps);
                        } else {
                            translate([0, 0, quad_web_h - eps])
                                cylinder(d1 = 6.16, d2 = 4.92, h = 0.62 + eps);
                        }
                    }
            }
        }

        // --- SUBTRACTIONS ---

        // A. Wide Central Solder-Tail Exit Well (Z = 4.65mm..top; preserves >=0.80mm 5-layer apex
        // & 2.07mm 13-layer continuous PETG-CF Battery Armor Ceiling over 45°-Gabled Belly T-Slot!)
        rotate([0, 0, 45])
            translate([-3.45, -3.45, 4.65])
                cube([6.90, 6.90, 10.0]);

        // B. 4x Self-Tapping M2 FC Standoff Bores (Ø1.80mm) + Bottom & Top 45° Chamfers
        for (a = [0, 90, 180, 270]) {
            rotate([0, 0, a])
                translate([fc_radius, 0, 0]) {
                    translate([0, 0, -eps])
                        cylinder(d = fc_hole_dia, h = frame_deck_h + fc_standoff_h + eps2);
                    translate([0, 0, -eps])
                        cylinder(d1 = fc_hole_dia + 0.70 + 2*eps, d2 = fc_hole_dia, h = 0.35 + eps);
                    translate([0, 0, frame_deck_h + fc_standoff_h - 0.35])
                        cylinder(d1 = fc_hole_dia, d2 = fc_hole_dia + 0.70 + 2*eps, h = 0.35 + eps);
                }
        }

        // B2. Rear (-Y) Captive BT2.0 Pigtail Strain-Relief C-Clip Channel
        translate([0, -20.15, -eps])
            cylinder(d = 3.20, h = 6.0);
        translate([-1.125, -22.50, -eps])
            cube([2.25, 2.40, 6.0]);
        translate([0, -20.15, -eps])
            cylinder(d1 = 3.90, d2 = 3.20, h = 0.35 + eps);

        // C. 4x Support-Free Diamond-V Keyed Sockets + 70AAJ-3-M0G / Mill-Max 811 Cavities
        for (a = [45, 135, 225, 315]) {
            is_key_a = (a == 135 || a == 315); // M4 (FL) & M1 (RR) are Key A (5.00mm CCW)

            rotate([0, 0, a]) {
                // C0. Open Diagonal Pod-Neck Slide Corridor beyond R = 9.60mm
                // Below Z=1.45mm stays 4.65mm wide (preserving 3.34x6.54mm quadrant windows & >=1.27mm walls!)
                translate([arm_reach, 0, 0])
                    rotate([90, 0, 90])
                        linear_extrude(height = 12.0)
                            polygon([
                                [-(dt_fem_w_stem/2 + 0.35), -eps],
                                [ (dt_fem_w_stem/2 + 0.35), -eps],
                                [  dt_fem_w_stem/2,          0.35],
                                [  dt_fem_w_stem/2,          10.0],
                                [ -dt_fem_w_stem/2,          10.0],
                                [ -dt_fem_w_stem/2,          0.35]
                            ]);

                // C1a. Deep Inboard Lower Tongue Guide Trench (R = 6.10..7.05mm, Z = 0.43..1.62mm, non-coplanar w/ C1b!)
                translate([6.10, -(dt_fem_w_stem/2 - 0.04), 0.43])
                    cube([1.05, dt_fem_w_stem - 0.08, 1.19]);

                // C1b. Continuous Diamond-V Female Dovetail Socket & Slide Corridor (R = 6.95..16.50mm)
                translate([6.95, 0, 0.40])
                    dovetail_female_diamond(9.55, dt_fem_w_stem, dt_fem_w_waist, dt_fem_w_top);

                // C2. Compliant Waist-Only Snap Detent Pocket at R = 8.15..9.50mm (45° axial entry/exit ramps, preserves R=9.60mm mouth!)
                hull() {
                    translate([8.60, 0, 0.40])
                        rotate([90, 0, 90])
                            linear_extrude(height = 0.40)
                                polygon([
                                    [-(dt_fem_w_waist/2 - 0.10), 3.75],
                                    [ (dt_fem_w_waist/2 - 0.10), 3.75],
                                    [  dt_fem_w_waist/2 + 0.28,  4.13],
                                    [  dt_fem_w_waist/2 + 0.28,  5.33],
                                    [  dt_fem_w_top/2 + 0.28,    dt_fem_h_fit - 0.28],
                                    [ -dt_fem_w_top/2 - 0.28,    dt_fem_h_fit - 0.28],
                                    [ -dt_fem_w_waist/2 - 0.28,  5.33],
                                    [ -dt_fem_w_waist/2 - 0.28,  4.13]
                                ]);
                    translate([8.15, 0, 0.40])
                        rotate([90, 0, 90])
                            linear_extrude(height = 1.35)
                                polygon([
                                    [-(dt_fem_w_waist/2 - 0.10), 3.75],
                                    [ (dt_fem_w_waist/2 - 0.10), 3.75],
                                    [  dt_fem_w_waist/2 - 0.02,  3.83],
                                    [  dt_fem_w_waist/2 - 0.02,  5.59],
                                    [  dt_fem_w_top/2 - 0.02,    dt_fem_h_fit - 0.02],
                                    [ -dt_fem_w_top/2 + 0.02,    dt_fem_h_fit - 0.02],
                                    [ -dt_fem_w_waist/2 + 0.02,  5.59],
                                    [ -dt_fem_w_waist/2 + 0.02,  3.83]
                                ]);
                }

                // C3. Support-Free 45°-Beveled Outer Mouth Keyway (R = 8.35..9.60mm -> 0 Open-Mouth Cliff!)
                if (is_key_a) {
                    difference() {
                        hull() {
                            translate([8.00, -2.675, 7.32])
                                cube([0.10, 5.35, 1.78]);
                            translate([8.35, 0, 7.30])
                                rotate([90, 0, 90])
                                    linear_extrude(height = 1.90)
                                        polygon([
                                            [-6.85/2,                 0],
                                            [ 6.85/2,                 0],
                                            [ key_slot_a_w/2,         0.75],
                                            [ key_slot_a_w/2,         1.80],
                                            [-key_slot_a_w/2,         1.80],
                                            [-key_slot_a_w/2,         0.75]
                                        ]);
                        }

                        // Central 1.40mm Polarizing Rib w/ 45° Self-Supporting Bottom Ramp!
                        hull() {
                            translate([7.75, -0.70, 7.15])
                                cube([0.15, 1.40, 2.00]);
                            translate([9.45, -0.70, 8.85])
                                cube([0.20, 1.40, 0.30]);
                        }
                    }
                } else {
                    hull() {
                        translate([7.85, -1.975, 7.32])
                            cube([0.10, 3.95, 0.40]);
                        translate([8.35, 0, 7.30])
                            rotate([90, 0, 90])
                                linear_extrude(height = 1.90)
                                    polygon([
                                        [-6.85/2,                 0],
                                        [ 6.85/2,                 0],
                                        [ key_slot_b_w/2,         1.30],
                                        [ key_slot_b_w/2,         1.80],
                                        [-key_slot_b_w/2,         1.80],
                                        [-key_slot_b_w/2,         1.30]
                                    ]);
                    }
                }

                // C5. Bourns 70AAJ-3-M0G / Mill-Max 811-22-003-30-001101 Spring Header Cavity
                // Backstop R = 3.68mm -> 4.720mm span to R = 8.40mm pod target backstop!
                translate([pogo_fem_backstop_r, 0, pogo_fem_z0])
                    rotate([90, 0, 90])
                        linear_extrude(height = 4.10)
                            polygon([
                                [-pogo_fem_w/2,        0],
                                [ pogo_fem_w/2,        0],
                                [ pogo_fem_w/2,        pogo_fem_h],
                                [ 2.28,                pogo_fem_h + (pogo_fem_w/2 - 2.28)],
                                [-2.28,                pogo_fem_h + (pogo_fem_w/2 - 2.28)],
                                [-pogo_fem_w/2,        pogo_fem_h]
                            ]);

                // C6. Wide 6.56mm Rear 3-Pin Solder-Tail Relief Window (Level Z=8.54mm 45° Gabled Roof -> 0.00mm2 >50° Overhang!)
                hull() {
                    translate([2.88, 0, pogo_fem_z0])
                        rotate([90, 0, 90])
                            linear_extrude(height = 0.97)
                                polygon([
                                    [-3.28, 0],
                                    [ 3.28, 0],
                                    [ 3.28, 2.64],
                                    [ 1.68, 4.24],
                                    [-1.68, 4.24],
                                    [-3.28, 2.64]
                                ]);
                    translate([2.35, 0, 4.65])
                        rotate([90, 0, 90])
                            linear_extrude(height = 0.10)
                                polygon([
                                    [-3.28, 0],
                                    [ 3.28, 0],
                                    [ 3.28, 2.29],
                                    [ 1.68, 3.89],
                                    [-1.68, 3.89],
                                    [-3.28, 2.29]
                                ]);
                }
            }
        }

        // D. 4x Unobstructed >=3.34x6.54mm Pure-Vertical Quadrant FC Wire Windows (Z = -eps..15.0mm)
        // Strictly outside |X| <= 9.75mm battery keepout (|X|_min = 10.348mm), >=1.27mm solid walls!
        for (sx = [-1, 1]) {
            for (sy = [-1, 1]) {
                mirror([sx < 0 ? 1 : 0, 0, 0])
                    mirror([0, sy < 0 ? 1 : 0, 0])
                        translate([0, 0, -eps])
                            linear_extrude(height = 15.0)
                                polygon([
                                    [10.348, 5.032],
                                    [15.228, 0.677],
                                    [17.452, 3.168],
                                    [12.572, 7.523]
                                ]);
            }

            // Open-Sky Top-Deck Cardinal +/-X Wire U-Channel w/ Inboard 45° Upper V-Flare (0 Floating Z-Minima, >=1.55mm socket wall!)
            translate([sx > 0 ? 2.95 : -9.35, -0.78, 4.65])
                cube([6.40, 1.56, 6.00]);
            translate([sx > 0 ? 2.80 : -5.50, 0, 0])
                rotate([90, 0, 90])
                    linear_extrude(height = 2.70)
                        polygon([
                            [-0.78, 6.75],
                            [ 0.78, 6.75],
                            [ 2.65, 8.62],
                            [ 2.65, 11.0],
                            [-2.65, 11.0],
                            [-2.65, 8.62]
                        ]);
        }

        // E. Support-Free 45°-Hipped Belly Keyhole T-Slot + Snap-Detent Guide Slots (Max Diagonal Bridge = 6.96mm << 10mm!)
        // E1. Aft Vertical Entry Keyhole (Y in [-4.20, +0.05], Z <= 1.50mm)
        extrude_xz_along_y(-4.20, 4.25)
            polygon([
                [-5.65, -eps],
                [ 5.65, -eps],
                [ 5.30,  0.35],
                [ 5.30,  1.50],
                [-5.30,  1.50],
                [-5.30,  0.35]
            ]);

        // E2/E3. Forward Locked 45° V-Flange T-Slot (Y in [-0.05, +4.20], Z <= 1.55mm, +0.20mm/side clearance & 0.95mm/side lock!)
        extrude_xz_along_y(-0.05, 4.25)
            polygon([
                [-4.25, -eps],
                [ 4.25, -eps],
                [ 4.05,  0.08],
                [ 5.20,  1.23],
                [ 5.20,  1.55],
                [-5.20,  1.55],
                [-5.20,  1.23],
                [-4.05,  0.08]
            ]);

        // E1_roof. 4-Sided 45.0° Hipped Pyramid Roof (Z=1.48..3.85mm -> 5.90x3.70mm Crown, 6.96mm max diagonal!)
        hull() {
            translate([-5.30, -4.20, 1.46])
                cube([10.60, 8.40, 0.06]);
            translate([-2.95, -1.85, 3.81])
                cube([5.90, 3.70, 0.04]);
        }

        // E4a. Fore (+Y in [10.45, 15.85]) Cardinal Anti-Yaw Guide Slot
        extrude_xz_along_y(10.45, 5.40)
            polygon([
                [-2.10, -eps],
                [ 2.10, -eps],
                [ 1.75,  0.35],
                [ 1.75,  1.25],
                [ 1.35,  1.65],
                [-1.35,  1.65],
                [-1.75,  1.25],
                [-1.75,  0.35]
            ]);

        // E4b. Aft (-Y in [-15.85, -10.60]) Snap-Detent Guide Slot
        difference() {
            extrude_xz_along_y(-15.85, 5.25)
                polygon([
                    [-2.25, -eps],
                    [ 2.25, -eps],
                    [ 1.90,  0.35],
                    [ 1.90,  1.25],
                    [ 1.45,  1.70],
                    [-1.45,  1.70],
                    [-1.90,  1.25],
                    [-1.90,  0.35]
                ]);

            for (sx_d = [-1, 1]) {
                mirror([sx_d < 0 ? 1 : 0, 0, 0])
                    translate([0, 0, -eps])
                        linear_extrude(height = 1.85)
                            polygon([
                                [2.00, -13.75],
                                [1.48, -13.00],
                                [2.00, -12.25]
                            ]);
            }
        }

        // G. Mathematically Enforced Duct Keepout Cylinders (+0.07mm margin over r=22.22mm inboard wall)
        for (sx = [-1, 1]) {
            for (sy = [-1, 1]) {
                translate([sx * m_xy, sy * m_xy, -eps])
                    cylinder(r = duct_od/2 + 0.07, h = 20);
            }
        }
    }
}


// ============================================================================
// MODULE 2: snap_duct_pod (Core Support-Free Pod Module: SQ02..SQ05)
// ============================================================================
module snap_duct_pod(key_w = 5.0) {
    tab_shoulder = pod_tab_shoulder;                // 27.90 mm -> 75.00 mm True-X exact!
    tab_tip      = pogo_male_backstop_x + pogo_male_d; // 29.10 + 1.30 = 30.40 mm
    tab_len      = tab_tip - tab_shoulder;          // 2.50 mm full Diamond-V head
    tongue_tip   = 31.05;                           // R_world = 6.45mm > 6.19mm SQ07 T-Lug!

    difference() {
        union() {
            // 1A. Core 360° Prop Duct + Full 360° Upper Rim (ID=42.0mm, OD=44.44mm, H=8.70mm)
            rotate_extrude()
                polygon([
                    [duct_id/2,        0.00],
                    [duct_od/2,        0.00],
                    [duct_od/2,        duct_height - 1.48],
                    [bumper_rim_od/2,  duct_height - 0.90],
                    [bumper_rim_od/2,  duct_height],
                    [duct_id/2,        duct_height]
                ]);

            // 1B. Outer 210° Lower Crash Bumper Rim (recessed flush to 44.44mm OD on inboard +-75° arc!)
            rotate([0, 0, 75])
                rotate_extrude(angle = 210)
                    polygon([
                        [duct_od/2 - 0.12, 0.00],
                        [bumper_rim_od/2,  0.00],
                        [bumper_rim_od/2,  0.90],
                        [duct_od/2 - 0.12, 1.60]
                    ]);

            // 2. Central 1002/0802 Motor Hub (OD=13.80mm, H=3.24mm) + Inward 0° Wire-Exit Lobe
            // +0.04mm taller than Z=3.20mm strut avoids circle-to-wall coplanar tangency slivers!
            hull() {
                cylinder(d = motor_boss_od, h = motor_boss_h + 0.04);
                translate([5.60, 0, 0])
                    cylinder(d = 6.20, h = motor_boss_h + 0.04);
            }

            // 3A. 0° Inward Wire-Conduit Strut & Lower Tongue Spine (4.30mm wide x 3.20mm tall, 0.35mm chamfer)
            translate([motor_boss_od/2 - 0.8, 0, 0])
                rotate([90, 0, 90])
                    linear_extrude(height = tab_shoulder - (motor_boss_od/2 - 0.8) + 0.25)
                        polygon([
                            [-(strut_w/2 - 0.35), 0.00],
                            [ (strut_w/2 - 0.35), 0.00],
                            [  strut_w/2,         0.35],
                            [  strut_w/2,         3.20],
                            [ -strut_w/2,         3.20],
                            [ -strut_w/2,         0.35]
                        ]);

            // Extended lower guide tongue (X = 30.20..31.05mm, Z = 0..0.98mm w/ 45° nose & bottom chamfer)
            hull() {
                translate([tab_shoulder + 0.50, 0, 0])
                    rotate([90, 0, 90])
                        linear_extrude(height = tab_tip - tab_shoulder - 0.50)
                            polygon([
                                [-(dt_male_w_stem/2 - 0.35), 0.00],
                                [ (dt_male_w_stem/2 - 0.35), 0.00],
                                [  dt_male_w_stem/2,         0.35],
                                [  dt_male_w_stem/2,         0.98],
                                [ -dt_male_w_stem/2,         0.98],
                                [ -dt_male_w_stem/2,         0.35]
                            ]);
                translate([tongue_tip - 0.30, 0, 0])
                    rotate([90, 0, 90])
                        linear_extrude(height = 0.30)
                            polygon([
                                [-0.90, 0.00],
                                [ 0.90, 0.00],
                                [ 1.25, 0.35],
                                [ 1.25, 0.82],
                                [-1.25, 0.82],
                                [-1.25, 0.35]
                            ]);
            }

            // 3B. 2x Aero-Slim Radial Bottom Finger-Guard Struts at 120° & 240° (2.20mm x 2.60mm)
            for (a = [120, 240]) {
                rotate([0, 0, a])
                    translate([motor_boss_od/2 - 0.4, 0, 0])
                        rotate([90, 0, 90])
                            linear_extrude(height = duct_id/2 - motor_boss_od/2 + 0.9)
                                polygon([
                                    [-0.75, 0.00],
                                    [ 0.75, 0.00],
                                    [ 1.10, 0.35],
                                    [ 1.10, 2.60],
                                    [-1.10, 2.60],
                                    [-1.10, 0.35]
                                ]);
            }

            // 4A. Narrow Upper Spine Fillet inside 4.28mm Conduit Envelope (X = 27.10..28.05mm, Z >= 1.10mm)
            // Non-coplanar Z=3.16mm entry w/ Z=3.20mm strut (0 degenerate tris!) & 0.000mm3 interference w/ SQ01 mouth!
            hull() {
                translate([27.10, -2.14, 1.10])
                    cube([0.20, 4.28, 2.06]);
                translate([tab_shoulder + 0.05, -2.14, 1.10])
                    cube([0.20, 4.28, 5.20]);
            }

            // 4B. Main Support-Free 45° Diamond-V Male Dovetail Head (X = 27.90..30.40mm)
            translate([tab_shoulder, 0, 0])
                dovetail_male_diamond(tab_len, dt_male_w_stem, dt_male_w_waist, dt_male_w_top, dt_male_chamf);

            // 5. Bidirectional Polarizing Top Rib on Outer Collar (X = 27.90..29.06mm < 29.10mm pogo pocket!)
            if (key_w > 4.0) {
                for (sy_k = [-1, 1]) {
                    hull() {
                        translate([tab_shoulder, sy_k > 0 ? 0.90 : -key_w/2, dt_male_h - eps])
                            cube([1.10, (key_w - 1.80)/2, key_rib_top_z_pod - dt_male_h + eps]);
                        translate([tab_shoulder + 1.12, sy_k > 0 ? 0.90 : -key_w/2, dt_male_h - eps])
                            cube([0.04, (key_w - 1.80)/2, key_rib_top_z_pod - dt_male_h - 0.12]);
                    }
                }
            } else {
                hull() {
                    translate([tab_shoulder, -key_w/2, dt_male_h - eps])
                        cube([1.10, key_w, key_rib_top_z_pod - dt_male_h + eps]);
                    translate([tab_shoulder + 1.12, -key_w/2, dt_male_h - eps])
                        cube([0.04, key_w, key_rib_top_z_pod - dt_male_h - 0.12]);
                }
            }

            // 6. Compliant Waist-Only Snap Detent Ramp at X = 28.50..28.80mm (0.000mm3 slide-in interference!)
            hull() {
                translate([tab_shoulder + 0.60, 0, 0])
                    rotate([90, 0, 90])
                        linear_extrude(height = 0.30)
                            polygon([
                                [-(dt_male_w_waist/2 - 0.06), 3.79],
                                [ (dt_male_w_waist/2 - 0.06), 3.79],
                                [  dt_male_w_waist/2 + 0.14,  3.99],
                                [  dt_male_w_waist/2 + 0.14,  5.09],
                                [  dt_male_w_top/2 + 0.14,    dt_male_h - 0.14],
                                [ -dt_male_w_top/2 - 0.14,    dt_male_h - 0.14],
                                [ -dt_male_w_waist/2 - 0.14,  5.09],
                                [ -dt_male_w_waist/2 - 0.14,  3.99]
                            ]);
                translate([tab_shoulder + 0.25, 0, 0])
                    rotate([90, 0, 90])
                        linear_extrude(height = 1.00)
                            polygon([
                                [-(dt_male_w_waist/2 - 0.06), 3.79],
                                [ (dt_male_w_waist/2 - 0.06), 3.79],
                                [  dt_male_w_waist/2 - 0.02,  3.83],
                                [  dt_male_w_waist/2 - 0.02,  5.21],
                                [  dt_male_w_top/2 - 0.02,    dt_male_h - 0.02],
                                [ -dt_male_w_top/2 + 0.02,    dt_male_h - 0.02],
                                [ -dt_male_w_waist/2 + 0.02,  5.21],
                                [ -dt_male_w_waist/2 + 0.02,  3.83]
                            ]);
            }
        }

        // --- SUBTRACTIONS ---

        // A. Ø3.00mm Motor Shaft / C-Clip Relief Bore + Bottom Chamfer
        translate([0, 0, -eps])
            cylinder(d = motor_shaft_dia, h = motor_boss_h + eps2);
        translate([0, 0, -eps])
            cylinder(d1 = motor_shaft_dia + 0.70 + 2*eps, d2 = motor_shaft_dia, h = 0.35 + eps);

        // B. 3-Hole M1.4 Motor Pattern (60°, 180°, 300°) + Ø2.85mm x 1.15mm Counterbores w/ 45° Roofs
        for (m_ang = [60, 180, 300]) {
            rotate([0, 0, m_ang])
                translate([motor_pcd/2, 0, 0]) {
                    translate([0, 0, -eps])
                        cylinder(d = motor_screw_dia, h = motor_boss_h + eps2);
                    translate([0, 0, -eps])
                        cylinder(d = 2.85, h = 1.15 + eps);
                    translate([0, 0, 1.15 - 0.02])
                        cylinder(d1 = 2.85, d2 = motor_screw_dia, h = 0.70);
                }
        }

        // C1. Stage 1 Vertical Motor-Wire Drop inside 0° Hub Lobe (>=1.92mm solid wall outside Ø2.85mm counterbores!)
        translate([4.50, -strut_channel_w/2, -eps])
            cube([2.00, strut_channel_w, motor_boss_h + eps2]);

        // C2. Stage 2 & 3 Support-Free 45°-Gabled Under-Strut Conduit + 3x Snap-Detent Retention Nubs
        difference() {
            translate([4.50, 0, 0])
                rotate([90, 0, 90])
                    linear_extrude(height = 22.80)
                        polygon([
                            [-strut_channel_w/2 - 0.25, -eps],
                            [ strut_channel_w/2 + 0.25, -eps],
                            [ strut_channel_w/2,         0.25],
                            [ strut_channel_w/2,         strut_channel_h_v],
                            [ 0.45,                      strut_channel_peak],
                            [-0.45,                      strut_channel_peak],
                            [-strut_channel_w/2,         strut_channel_h_v],
                            [-strut_channel_w/2,         0.25]
                        ]);

            for (x_nub = [8.50, 13.50, 18.50]) {
                for (sy_n = [-1, 1]) {
                    mirror([0, sy_n < 0 ? 1 : 0, 0])
                        translate([x_nub, 0, 0])
                            rotate([90, 0, 90])
                                linear_extrude(height = 1.60)
                                    polygon([
                                        [strut_channel_w/2 + 0.30, -eps],
                                        [strut_channel_w/2 + 0.30,  0.62],
                                        [strut_channel_w/2 - 0.28,  0.32],
                                        [strut_channel_w/2 - 0.28,  0.18],
                                        [strut_channel_w/2,        -eps]
                                    ]);
                }
            }
        }

        // C3. Stage 4 3-Wire Solder-Tail Chamber: Narrow 45° Conduit Ramp inside 4A + Wide 6.52mm Chamber inside 4B!
        // Zero side punch-out through 4A (0 floating minima!) and non-coplanar Z=3.86mm floor w/ D (0 degenerate tris!)
        hull() {
            translate([26.10, 0, 0.35])
                rotate([90, 0, 90])
                    linear_extrude(height = 0.20)
                        polygon([
                            [-1.12, 0], [1.12, 0], [1.12, 0.80], [0.50, 1.42], [-0.50, 1.42], [-1.12, 0.80]
                        ]);
            translate([28.05, 0, pogo_male_z0 + 0.04])
                rotate([90, 0, 90])
                    linear_extrude(height = 0.25)
                        polygon([
                            [-1.45, 0], [1.45, 0], [1.45, 1.40], [0.50, 2.35], [-0.50, 2.35], [-1.45, 1.40]
                        ]);
        }
        translate([28.05, 0, pogo_male_z0 + 0.04])
            rotate([90, 0, 90])
                linear_extrude(height = 1.18)
                    polygon([
                        [-3.26, 0],
                        [ 3.26, 0],
                        [ 3.26, 1.12],
                        [ 1.63, 2.75],
                        [-1.63, 2.75],
                        [-3.26, 1.12]
                    ]);

        // D. Bourns 70AAJ-3-F0G Flat 3-Pad Target Pocket (7.68w x 2.64h x 1.30d mm, 45° Open-Crown Roof!)
        // Eliminates flat open-mouth overhang wall while retaining 0.88mm/side top + 1.11mm side lips!
        translate([pogo_male_backstop_x, 0, 0])
            rotate([90, 0, 90])
                linear_extrude(height = pogo_male_d + 0.50)
                    polygon([
                        [-pogo_male_w/2,        pogo_male_z0],
                        [ pogo_male_w/2,        pogo_male_z0],
                        [ pogo_male_w/2,        pogo_male_z0 + pogo_male_h],
                        [ pogo_male_w/2 - 0.88, pogo_male_z0 + pogo_male_h + 0.88],
                        [-pogo_male_w/2 + 0.88, pogo_male_z0 + pogo_male_h + 0.88],
                        [-pogo_male_w/2,        pogo_male_z0 + pogo_male_h]
                    ]);

        // E. Upper Bumper Rim Neck Relief above +X Dovetail
        translate([duct_od/2 + 0.02, -7.50, duct_height - 1.50])
            cube([2.00, 15.00, 2.00]);
    }
}

module pod_m4_fl_keya() { snap_duct_pod(key_a_w); }
module pod_m2_fr_keyb() { snap_duct_pod(key_b_w); }
module pod_m3_rl_keyb() { snap_duct_pod(key_b_w); }
module pod_m1_rr_keya() { snap_duct_pod(key_a_w); }


// ============================================================================
// MODULE 3: bearcub_canopy (SQ06) — 100% Support-Free (0.00g) TPU 68D Canopy
// Zero Z-minima islands, zero slivers, <=45° self-supporting Gothic geometry!
// ============================================================================
module bearcub_canopy() {
    foot_xy = fc_mount_span / 2.0; // 12.75 mm (R = 18.0312 mm)
    foot_d  = 6.60;                // Exact 32.10 x 32.10 mm footprint

    difference() {
        union() {
            // 1. 4x Flat-Bottomed Standoff Feet + Pure <=38° Inward-Tapering Legs
            for (sx = [-1, 1]) {
                for (sy = [-1, 1]) {
                    hull() {
                        translate([sx * foot_xy, sy * foot_xy, 0])
                            cylinder(d = foot_d, h = 2.00);
                        translate([sx * 9.60, sy * 9.60, 0])
                            cylinder(d = 6.00, h = 2.00);
                    }

                    hull() {
                        translate([sx * 9.60, sy * 9.60, 0.00])
                            cylinder(d = 6.40, h = 2.00);
                        translate([sx * 5.00, sy * 5.00, 8.20])
                            cylinder(d = 6.80, h = 0.80);
                    }
                }
            }

            // 2. Self-Supporting Gothic Bear-Cub Dome (0.00mm2 flat overhang, <=38° flare!)
            difference() {
                rotate([0, 0, -45]) {
                    hull() {
                        translate([0, 0, 5.20])
                            cylinder(r = 7.05, h = 0.20);
                        translate([0, 0, 8.95])
                            scale([1.0, 1.03, 1.0])
                                cylinder(r = 9.65, h = 0.25);
                        translate([0, 0, 12.20])
                            scale([1.0, 1.03, 1.0])
                                cylinder(r = 7.60, h = 0.25);
                        translate([0, 0, 14.35])
                            scale([1.0, 1.02, 1.0])
                                cylinder(r = 3.60, h = 0.45);
                    }
                }

                for (a_arch = [0, 90]) {
                    rotate([0, 0, a_arch])
                        rotate([90, 0, 0])
                            linear_extrude(height = 40.0, center = true)
                                polygon([
                                    [-6.50, -1.0],
                                    [ 6.50, -1.0],
                                    [ 6.50,  2.20],
                                    [ 0.00,  8.70],
                                    [-6.50,  2.20]
                                ]);
                }
            }

            // 3. Zero-Overhang Directional Bear Snout (+Y_world) & Leg-Supported Bear Ears
            rotate([0, 0, -45]) {
                hull() {
                    translate([-2.70, 6.20, 7.80])
                        cube([5.40, 2.00, 3.40]);
                    translate([-2.40, 11.80, 2.60])
                        cube([4.80, 1.00, 3.00]);
                    translate([-2.70, 13.60, 7.60])
                        cube([5.40, 0.80, 2.70]);
                }

                for (sx = [-1, 1]) {
                    hull() {
                        translate([sx * 6.80, 0.00, 7.60])
                            cylinder(d = 5.00, h = 1.00);
                        translate([sx * 6.10, 0.00, 13.00])
                            cylinder(d = 3.80, h = 1.55);
                    }
                }
            }
        }

        // --- SUBTRACTIONS ---
        translate([-50, -50, -25.0])
            cube([100, 100, 25.0]);

        // A. Pure <=44.4° Pointed Conical Internal Electronics Vault (r2 = 0 -> ZERO flat cap!)
        translate([0, 0, -eps])
            cylinder(d = 14.40, h = 6.20 + eps);
        translate([0, 0, 6.20])
            cylinder(r1 = 7.20, r2 = 0.00, h = 7.35);

        // B1/B2. Twin 45°-Teardrop Green LED Eye Ports (Ø2.20mm) & Rear Whip Port (Ø3.00mm)
        rotate([0, 0, -45]) {
            for (sx = [-1, 1]) {
                translate([sx * 1.40, 6.80, 8.85])
                    rotate([0, 0, 180])
                        rotate([90, 0, 0])
                            teardrop_cyl_z(2.20, 10.0);
            }

            translate([0, -4.50, 9.90])
                rotate([90, 0, 0])
                    teardrop_cyl_z(3.00, 10.0);
        }

        // C. 4x Coaxial M2 Screw Bores (Ø2.25mm + Bottom Chamfer) & Open Ø4.60mm Counterbores
        for (sx = [-1, 1]) {
            for (sy = [-1, 1]) {
                translate([sx * foot_xy, sy * foot_xy, 0]) {
                    translate([0, 0, -eps])
                        cylinder(d = 2.25, h = 20.0);
                    translate([0, 0, -eps])
                        cylinder(d1 = 2.95 + 2*eps, d2 = 2.25, h = 0.35 + eps);
                    translate([0, 0, 2.00])
                        cylinder(d = 4.60, h = 20.0);
                }
            }
        }

        // D. Motor-Duct Bumper Keepouts in Local Frame (+1.00mm margin)
        for (a = [0, 90, 180, 270]) {
            rotate([0, 0, a])
                translate([m_rad, 0, -eps])
                    cylinder(r = bumper_rim_od/2 + 1.00, h = 5.0);
        }
    }
}


// ============================================================================
// MODULE 4: battery_sled (SQ07) — 45°-Arched Support-Free Sled (<=5.3mm Bridge!)
// ============================================================================
module battery_sled() {
    outer_l = batt_len;     // 58.0 mm
    outer_w = 20.90;        // 1.20mm sidewalls around 18.50mm battery bay
    wall_h  = 8.45;         // Open-top U-cradle sidewall height outside central saddle
    outer_h = sled_arch_h;  // 14.35 mm self-supporting 45° dorsal saddle crown
    skid_w  = skid_span;    // 52.0 mm wide landing stance

    difference() {
        union() {
            // 1A. Main 1S LiHV U-Cradle Body w/ 0.40mm x 45° Bottom Elephant-Foot Chamfers!
            extrude_xz_along_y(-outer_l/2, outer_l)
                polygon([
                    [-(outer_w/2 - 0.40), 0.00],
                    [ (outer_w/2 - 0.40), 0.00],
                    [  outer_w/2,         0.40],
                    [  outer_w/2,         wall_h],
                    [ -outer_w/2,         wall_h],
                    [ -outer_w/2,         0.40]
                ]);

            // 1B. Self-Supporting <=45° Tapered Dorsal Saddle Arch (Zero Open-Air Overhang Cliffs!)
            hull() {
                translate([-(outer_w/2 - 0.08), -20.50, 6.85])
                    cube([outer_w - 0.16, 43.80, 0.20]);
                translate([-4.25, -13.00, outer_h - 0.20])
                    cube([8.50, 28.80, 0.20]);
            }

            // 2. 100% X-Symmetric Wide-Stance Truss Landing Skids w/ 0.35mm x 45° Bottom Chamfers!
            for (sx = [-1, 1]) {
                mirror([sx < 0 ? 1 : 0, 0, 0]) {
                    for (y_pos = [-17.5, 17.5]) {
                        hull() {
                            translate([outer_w/2 - 0.90, y_pos - 2.0, 0.48])
                                cube([1.10, 4.0, 2.12]);
                            translate([outer_w/2 - 0.85, y_pos - 1.65, 0.00])
                                cube([1.25, 3.30, 0.45]);
                            translate([skid_w/2 - 2.30, y_pos - 1.4, 0.38])
                                cube([2.20, 2.8, 1.12]);
                            translate([skid_w/2 - 1.95, y_pos - 1.05, 0.00])
                                cube([1.50, 2.10, 0.38]);
                        }
                    }

                    extrude_xz_along_y(-22.5, 45.0)
                        polygon([
                            [skid_w/2 - 2.05, 0.00],
                            [skid_w/2 - 0.35, 0.00],
                            [skid_w/2,        0.35],
                            [skid_w/2,        1.50],
                            [skid_w/2 - 2.40, 1.50],
                            [skid_w/2 - 2.40, 0.35]
                        ]);

                    // Symmetric Z=0 rear finger-grip ribs w/ exact 45.0° bottom chamfers on all sides (0.00mm2 >50° overhang!)
                    hull() {
                        translate([outer_w/2 - 0.60, -outer_l/2 + 1.50, 0.45])
                            cube([1.70, 7.00, 4.75]);
                        translate([outer_w/2 - 0.60, -outer_l/2 + 1.95, 0.00])
                            cube([1.25, 6.10, 0.45]);
                    }
                }
            }

            // 3A. Support-Free Beveled Male Keyhole T-Lug (7.00mm neck -> 10.00mm flange, 0.000mm3 T-slot clearance!)
            extrude_xz_along_y(-0.05, 3.40)
                polygon([
                    [-3.50, outer_h - eps],
                    [ 3.50, outer_h - eps],
                    [ 3.50, outer_h + 0.42],
                    [ 5.00, outer_h + 1.72],
                    [ 5.00, outer_h + 1.80],
                    [-5.00, outer_h + 1.80],
                    [-5.00, outer_h + 1.72],
                    [-3.50, outer_h + 0.42]
                ]);

            // 3B. Fore (+Y = 14.15..15.65) Anti-Yaw Guide Pin (3.10mm wide)
            translate([-1.55, 14.15, outer_h - eps])
                cube([3.10, 1.50, 1.50 + eps]);

            // 3C. Aft (-Y = -12.15..-10.70) XY-Flexing Tuning-Fork Snap-Detent Pin
            difference() {
                union() {
                    translate([-1.40, -12.15, outer_h - eps])
                        cube([2.80, 1.45, 1.50 + eps]);
                    for (sx_f = [-1, 1]) {
                        mirror([sx_f < 0 ? 1 : 0, 0, 0])
                            translate([0, 0, outer_h - eps])
                                linear_extrude(height = 1.50 + eps)
                                    polygon([
                                        [1.40, -12.10],
                                        [1.68, -11.45],
                                        [1.40, -10.75]
                                    ]);
                    }
                }
                translate([-0.42, -12.25, outer_h - 0.40])
                    cube([0.84, 1.70, 2.40]);
            }
        }

        // --- SUBTRACTIONS ---

        // A. 1S 450/550mAh Stick Battery Cavity + Exact 45.0° Dorsal Arch Vault!
        // Shrinks top bridge from 18.17mm down to <=5.30mm (<<10.0mm!) with 0.00mm2 >45° overhang!
        extrude_xz_along_y(-outer_l/2 - eps, outer_l + eps2)
            polygon([
                [-batt_w/2, 1.05],
                [ batt_w/2, 1.05],
                [ batt_w/2, 6.85],
                [ 2.65,     13.45],
                [-2.65,     13.45],
                [-batt_w/2, 6.85]
            ]);

        // B2. Fore & Aft Floor Weight-Relief Windows w/ 0.35mm x 45° Bottom Chamfers!
        for (yw = [[16.50, 9.70], [-26.20, 9.70]]) {
            hull() {
                translate([-(batt_w/2 - 2.60), yw[0], 0.35])
                    cube([batt_w - 5.20, yw[1], 1.10]);
                translate([-(batt_w/2 - 2.25), yw[0] - 0.35, -eps])
                    cube([batt_w - 4.50, yw[1] + 0.70, 0.35 + eps]);
            }
        }

        // B3. Support-Free 45° Diamond Sidewall Lightening Windows
        for (y_dia = [-21.5, -7.0, 7.0, 21.5]) {
            translate([0, y_dia, 4.65])
                rotate([0, 90, 0])
                    rotate([0, 0, 45])
                        cube([4.00, 4.00, outer_w + 4.0], center = true);
        }

        // C. Symmetric Fore (+Y) & Aft (-Y) Amass BT2.0 Connector Access Notches
        translate([-4.70, outer_l/2 - 5.20, 1.05])
            cube([9.40, 5.50, 9.00]);
        translate([-4.70, -outer_l/2 - eps, 1.05])
            cube([9.40, 5.50, 9.00]);
    }
}


// ============================================================================
// MODULE 5: all_pieces_plate (SQ08)
// ============================================================================
module all_pieces_plate() {
    center_xframe();

    translate([-68.0, 52.0, 0])
        pod_m4_fl_keya();

    translate([68.0, 52.0, 0])
        pod_m2_fr_keyb();

    translate([-68.0, -52.0, 0])
        pod_m3_rl_keyb();

    translate([68.0, -52.0, 0])
        pod_m1_rr_keya();

    translate([0, 62.0, 0])
        bearcub_canopy();

    translate([0, -62.0, 0])
        battery_sled();
}


// ============================================================================
// RENDER DISPATCHER
// ============================================================================
if (PART == 1) {
    center_xframe();
} else if (PART == 2) {
    pod_m4_fl_keya();
} else if (PART == 3) {
    pod_m2_fr_keyb();
} else if (PART == 4) {
    pod_m3_rl_keyb();
} else if (PART == 5) {
    pod_m1_rr_keya();
} else if (PART == 6) {
    bearcub_canopy();
} else if (PART == 7) {
    battery_sled();
} else if (PART == 8) {
    all_pieces_plate();
} else if (PART == 0) {
    // Physical Mated Assembly Preview (PART == 0) — 100% Zero-Interference Kinematics
    color("DimGray") center_xframe();
    for (i = [0:3]) {
        ang = [135, 45, 225, 315][i];
        kw  = [key_a_w, key_b_w, key_b_w, key_a_w][i];
        col = (i == 0 || i == 1) ? "MediumSeaGreen" : "DarkOrange";
        rotate([0, 0, ang])
            translate([m_rad, 0, dt_floor_z])
                rotate([0, 0, 180])
                    color(col) snap_duct_pod(kw);
    }
    color("RoyalBlue")
        translate([0, 0, frame_deck_h + fc_standoff_h])
            rotate([0, 0, 45])
                bearcub_canopy();
    color("DarkSlateGray")
        translate([0, 0, sled_z_offset])
            battery_sled();
}
