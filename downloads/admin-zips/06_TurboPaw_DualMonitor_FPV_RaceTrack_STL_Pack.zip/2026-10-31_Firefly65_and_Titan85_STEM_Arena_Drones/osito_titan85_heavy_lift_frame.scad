// ============================================================================
// OSITO-TITAN-85: 49.2g Sub-50g Heavy-Lift STEM Logistics & Bridge Crane Drone
// Airframe: 85mm PETG-CF Spine + TPU 95A Tandem-Bumper Ducts
// Motors: 1102 18000KV (4-bolt 9mm circle) | Props: 45mm 4-Blade Heavy-Lift
// Payload Mechanism: 2.8g Electro-Permanent Magnetic (EPM) Belly Cargo Winch
// ============================================================================

$fn = 72;

wheelbase_mm = 85.0;
duct_inner_r = 23.2;       // 45mm 4-blade prop + 0.7mm tip clearance
duct_wall_t = 1.35;
duct_height = 10.5;
spine_t = 3.0;             // Carbon-Fiber PETG structural X-truss
epm_winch_r = 7.5;         // Center-of-gravity Electro-Permanent Magnet housing

module heavy_lift_duct(cx, cy) {
    ang_arm = atan2(cy, cx);
    translate([cx, cy, 0]) {
        difference() {
            union() {
                difference() {
                    cylinder(r = duct_inner_r + duct_wall_t, h = duct_height, center = false);
                    translate([0, 0, -0.5])
                        cylinder(r = duct_inner_r, h = duct_height + 1.0, center = false);
                }
                // 4 heavy-duty stator struts + expanded 18.40mm OD pad for 1102 9mm M2 bolt pattern
                for (a = [45, 135, 225, 315]) {
                    rotate([0, 0, ang_arm + a])
                        translate([0, -1.0, 0])
                            cube([duct_inner_r + 0.4, 2.0, 2.8]);
                }
                cylinder(r = 9.20, h = spine_t, center = false);
            }
            // 4.0mm shaft/c-clip bore + 4x M2 holes on 9.0mm bolt circle (>= 3.625mm outer wall)
            translate([0, 0, -0.5])
                cylinder(d = 4.0, h = spine_t + 1.5, center = false);
            for (m = [0, 90, 180, 270]) {
                rotate([0, 0, ang_arm + 45 + m])
                    translate([4.50, 0, -0.5])
                        cylinder(d = 2.15, h = spine_t + 1.5, center = false);
            }
        }
    }
}

module petg_cf_structural_spine() {
    arm_r = wheelbase_mm / 2.0;
    fc_r = (25.5 / 2.0) * sqrt(2.0);
    difference() {
        union() {
            for (a = [45, 135, 225, 315]) {
                rotate([0, 0, a]) {
                    translate([0, -3.2, 0])
                        cube([arm_r - 6.0, 6.4, spine_t]);
                    hull() {
                        translate([arm_r - 12.0, -3.2, 0])
                            cube([1.0, 6.4, spine_t]);
                        translate([arm_r, 0, 0])
                            cylinder(r = 9.20, h = spine_t);
                    }
                }
            }
            // Central 25.5x25.5mm diamond Whoop AIO FC deck + M2 standoffs
            hull() {
                for (a = [0, 90, 180, 270])
                    rotate([0, 0, a])
                        translate([fc_r, 0, 0])
                            cylinder(d = 5.6, h = spine_t);
            }
            for (a = [0, 90, 180, 270])
                rotate([0, 0, a])
                    translate([fc_r, 0, 0])
                        cylinder(d = 4.8, h = spine_t + 3.0);
        }
        // FC M2 screw bores
        for (a = [0, 90, 180, 270])
            rotate([0, 0, a])
                translate([fc_r, 0, -0.5])
                    cylinder(d = 1.85, h = spine_t + 4.0);
        // Keep motor bores & 9mm M2 holes open + carve top 2.80 x 0.90mm motor-wire U-channels
        for (a = [45, 135, 225, 315]) {
            rotate([0, 0, a]) {
                translate([arm_r, 0, -0.5])
                    cylinder(d = 4.0, h = spine_t + 1.5);
                for (m = [0, 90, 180, 270])
                    translate([arm_r, 0, 0])
                        rotate([0, 0, 45 + m])
                            translate([4.50, 0, -0.5])
                                cylinder(d = 2.15, h = spine_t + 1.5);
                translate([11.5, -1.40, spine_t - 0.90])
                    cube([arm_r - 18.2, 2.80, 1.50]);
            }
        }
    }
}

module epm_magnetic_cargo_winch_bay() {
    // Centered directly on Z-axis integrated with Z=0 structural spine
    difference() {
        cylinder(r = epm_winch_r + 1.8, h = 6.2, center = false);
        translate([0, 0, 1.6])
            cylinder(r = epm_winch_r - 1.2, h = 5.2, center = false);
    }
}

module titan85_complete_frame() {
    offset_xy = (wheelbase_mm / 2.0) / sqrt(2.0);
    union() {
        heavy_lift_duct( offset_xy,  offset_xy);
        heavy_lift_duct(-offset_xy,  offset_xy);
        heavy_lift_duct(-offset_xy, -offset_xy);
        heavy_lift_duct( offset_xy, -offset_xy);
        petg_cf_structural_spine();
        epm_magnetic_cargo_winch_bay();
    }
}

titan85_complete_frame();
