// ============================================================================
// OSITO-FIREFLY-65: 31.8g Indoor LED Light-Show & Visual Telemetry Halo Shroud
// Airframe: 65mm Ducted Micro-Whoop | 36-LED WS2812B-2020 Addressable RGBIC Ring
// Core Fleet Reuse: Matrix 1S G473 FC (25.5x25.5mm), 0802 19500KV, MTF-01 Sensor
// Material: Translucent Frosted White TPU 95A (Light-Diffusing Prop Guard Ring)
// ============================================================================

$fn = 72;

wheelbase_mm = 65.0;
duct_inner_r = 16.25;      // 31mm 3-blade prop + 0.75mm radial tip clearance
duct_wall_t = 1.15;
duct_height = 8.4;
led_count = 36;
halo_radius = 49.5;        // Outer perimeter halo ring radius
fc_mount_pitch = 25.5;     // Whoop 25.5x25.5mm standard

module motor_duct(cx, cy) {
    ang_arm = atan2(cy, cx);
    translate([cx, cy, 0]) {
        difference() {
            union() {
                difference() {
                    cylinder(r = duct_inner_r + duct_wall_t, h = duct_height, center = false);
                    translate([0, 0, -0.5])
                        cylinder(r = duct_inner_r, h = duct_height + 1.0, center = false);
                }
                // 3 aerodynamic stator struts + expanded 12.40mm OD motor mount boss (0802 6.6mm BCD)
                for (a = [0, 120, 240]) {
                    rotate([0, 0, ang_arm + a])
                        translate([0, -0.9, 0])
                            cube([duct_inner_r + 0.4, 1.8, 2.4]);
                }
                cylinder(r = 6.20, h = 2.6, center = false);
            }
            // Center shaft bore + 3x M1.4 holes on 6.60mm BCD (>= 2.10mm outer wall)
            translate([0, 0, -0.5])
                cylinder(d = 2.20, h = 4.0, center = false);
            for (m = [0, 120, 240]) {
                rotate([0, 0, ang_arm + m])
                    translate([3.30, 0, -0.5])
                        cylinder(d = 1.60, h = 4.0, center = false);
            }
        }
    }
}

module ws2812b_2020_halo_channel() {
    // 36-LED addressable RGBIC flexible PCB channel around perimeter diffuser (flush Z=0 base)
    difference() {
        cylinder(r = halo_radius + 1.4, h = 4.6, center = false);
        translate([0, 0, -0.5])
            cylinder(r = halo_radius - 0.8, h = 5.6, center = false);
        // 36 optical collimator windows around 360 deg perimeter
        for (i = [0 : led_count - 1]) {
            rotate([0, 0, i * (360 / led_count)])
                translate([halo_radius, 0, 2.5])
                    cube([3.5, 2.2, 2.2], center = true);
        }
    }
}

module mtf01_nadir_bay() {
    // Center belly mount + 25.5x25.5mm diamond FC deck & routed diagonal motor-wire arms
    arm_r = wheelbase_mm / 2.0;
    fc_r = (fc_mount_pitch / 2.0) * sqrt(2.0);
    difference() {
        union() {
            // MTF-01 center frame & diamond FC deck
            translate([-9.0, -9.0, 0])
                cube([18.0, 18.0, 2.6]);
            hull() {
                for (a = [0, 90, 180, 270])
                    rotate([0, 0, a])
                        translate([fc_r, 0, 0])
                            cylinder(d = 5.4, h = 2.6);
            }
            for (a = [0, 90, 180, 270])
                rotate([0, 0, a])
                    translate([fc_r, 0, 0])
                        cylinder(d = 4.6, h = 5.2);
            // 4 diagonal structural arms + teardrop motor-pad gussets + outer halo ties
            for (a = [45, 135, 225, 315]) {
                rotate([0, 0, a]) {
                    translate([8.0, -2.5, 0])
                        cube([arm_r - 12.0, 5.0, 2.8]);
                    hull() {
                        translate([arm_r - 9.0, -2.5, 0])
                            cube([1.0, 5.0, 2.6]);
                        translate([arm_r, 0, 0])
                            cylinder(r = 6.20, h = 2.6);
                    }
                    translate([arm_r + duct_inner_r + 0.5, -2.2, 0])
                        cube([(halo_radius - 0.4) - (arm_r + duct_inner_r + 0.5), 4.4, 3.2]);
                }
            }
        }
        // MTF-01 Optical Flow + LiDAR downward window
        translate([-7.1, -5.1, -0.5])
            cube([14.2, 10.2, 4.0]);
        // Center weight relief outside MTF-01 collar
        for (a = [0, 90, 180, 270])
            rotate([0, 0, a])
                translate([fc_r, 0, -0.5])
                    cylinder(d = 1.85, h = 6.5);
        // Motor bores & screw holes kept clear through gusset
        for (a = [45, 135, 225, 315]) {
            rotate([0, 0, a]) {
                translate([arm_r, 0, -0.5])
                    cylinder(d = 2.20, h = 4.0);
                for (m = [0, 120, 240])
                    translate([arm_r, 0, 0])
                        rotate([0, 0, a + m])
                            translate([3.30, 0, -0.5])
                                cylinder(d = 1.60, h = 4.0);
                // Top 2.60 x 0.85mm motor-wire U-channel into FC waist
                translate([11.2, -1.30, 1.95])
                    cube([arm_r - 15.8, 2.60, 1.50]);
            }
        }
    }
}

module firefly65_complete_frame() {
    offset_xy = (wheelbase_mm / 2.0) / sqrt(2.0);
    union() {
        motor_duct( offset_xy,  offset_xy);
        motor_duct(-offset_xy,  offset_xy);
        motor_duct(-offset_xy, -offset_xy);
        motor_duct( offset_xy, -offset_xy);
        ws2812b_2020_halo_channel();
        mtf01_nadir_bay();
    }
}

firefly65_complete_frame();
