// ============================================================================
// OSITO-INT-95: 95mm Autonomous Non-Contact AI Security Interceptor Airframe
// Parametric 2-Manifold OpenSCAD Master (Rev 2.0 — Expanded 13.20mm Motor Pads
// + Protected Top Stator-Tab & 5-Stage Motor-Wire Routing to 25.5x25.5 AIO FC)
// ============================================================================
// Matches AI Security Drone/BUILD.md (OSITO-ENG-BLD-001) Specifications:
//   - Bounding Box : 124.16 x 124.16 x 9.70 mm (Z = 0.000 .. +9.700 mm)
//   - Wheelbase    : 94.80..95.00 mm diagonal (motor XY = +/-33.44 mm)
//   - Ducts        : 54.18 mm ID / 57.28 mm OD (1.55 mm wall), 9.70 mm height
//                    -> 1.69 mm radial tip clearance for Gemfan 2020 (50.8mm)
//   - FC Mount     : 25.5 x 25.5 mm rotated 45 deg diamond at (0, +/-18.031)
//                    & (+/-18.031, 0), Z = 5.50 mm, Ø2.05 mm M2 bores
//   - Motor Pads   : Expanded Ø13.20 mm OD (>=2.40 mm solid PAHT-CF wall!)
//                    around 6.60 mm PCD 3x Ø1.80 mm M1.6 holes + Ø3.20 mm shaft
//   - Wire Routing : Top-recessed 2.80 x 0.85 mm U-channel from 180-deg stator
//                    solder tab through Z=3.00 mm inboard duct base ring into
//                    flared FC waist wire-riser pockets (100% flat Z=0 bottom!)
//   - Payload/Batt : Ø14.50 mm downward Matek 3901-L1X Flow+LiDAR viewport +
//                    10.2 mm battery strap slots at +/-7.1 mm & +/-19.0 mm
// ============================================================================

$fn = 72;

// --- Core Airframe Dimensions (mm) ---
motor_xy            = 33.44;                    // 33.44 + 28.64 = 62.08mm -> 124.16mm exact bbox!
m_rad               = motor_xy * sqrt(2);       // 47.291 mm (94.58..95.0 mm class)
duct_id             = 54.18;                    // Exact BUILD.md 54.18 mm ID
duct_wall           = 1.55;                     // Exact BUILD.md 1.55 mm wall
duct_od             = duct_id + 2 * duct_wall;  // 57.28 mm OD (r = 28.64 mm)
duct_height         = 9.70;                     // Exact BUILD.md 9.70 mm shroud height
inboard_ring_h      = 3.00;                     // Clears AIO FC, MicroSD & USB-C

arm_width           = 5.80;
arm_height          = 2.50;                     // Exact BUILD.md Z = 0.00..2.50 mm motor hub
motor_boss_dia      = 13.20;                    // >= 2.40 mm solid PAHT-CF outer wall!
motor_gusset_span   = 11.00;
motor_pcd           = 6.60;                     // 3-hole 1103 / 1202.5 pattern
motor_screw_dia     = 1.80;                     // M1.6 clearance hole
motor_shaft_dia     = 3.20;                     // C-clip & shaft relief (preserves inner screw bridge)

fc_mount_span       = 25.50;
fc_radius           = fc_mount_span / sqrt(2);  // 18.0312 mm cardinal diamond
fc_hole_dia         = 2.05;                     // M2 clearance / tap bore
fc_standoff_top_z   = 5.50;                     // Exact BUILD.md Z = 5.50 mm standoff height

wire_chan_w         = 2.80;
wire_chan_depth     = 0.85;                     // Z = 1.65..3.50 mm top U-channel (flat Z=0 bottom!)

module fc_diamond_positions_2d() {
    for (ang = [0, 90, 180, 270]) {
        rotate([0, 0, ang])
            translate([fc_radius, 0])
                children();
    }
}

module osito_interceptor_95mm_frame() {
    difference() {
        union() {
            // 1. Central Avionics & Battery Deck + Diagonal Arms + Teardrop Ø13.20mm Motor Pads + Duct Struts (Z = 0..2.50mm)
            linear_extrude(height = arm_height) {
                union() {
                    // Central diamond/octagonal sensor & battery tray
                    hull() {
                        circle(d = 29.0);
                        fc_diamond_positions_2d() circle(d = 6.6);
                        for (sx = [-1, 1], sy = [-1, 1]) {
                            translate([sx * 11.5, sy * 11.5]) circle(d = 5.6);
                        }
                    }
                    // 4x Diagonal Arms + Teardrop Gusseted Ø13.20mm Motor Pads + 3x Radial Aerodynamic Struts
                    for (ang = [45, 135, 225, 315]) {
                        rotate([0, 0, ang]) {
                            translate([0, -arm_width/2])
                                square([m_rad, arm_width]);
                            hull() {
                                translate([m_rad, 0]) circle(d = motor_boss_dia);
                                translate([m_rad - motor_gusset_span, -arm_width/2])
                                    square([0.8, arm_width]);
                            }
                            translate([m_rad, 0]) {
                                for (s_ang = [-58, 0, 58]) {
                                    rotate([0, 0, s_ang])
                                        hull() {
                                            translate([motor_boss_dia/2 - 1.6, -1.85])
                                                square([0.8, 3.7]);
                                            translate([duct_id/2 + 0.8, -1.55])
                                                square([0.2, 3.1]);
                                        }
                                }
                            }
                        }
                    }
                }
            }

            // 2. Cardinal Tangential Box-Webs uniting FC Diamond Hub to Duct Base Rings (Z = 0..3.00mm)
            linear_extrude(height = inboard_ring_h) {
                difference() {
                    for (c_ang = [0, 90, 180, 270]) {
                        rotate([0, 0, c_ang])
                            hull() {
                                translate([fc_radius, 0]) circle(d = 6.0);
                                translate([motor_xy - 1.0, -7.2]) square([4.5, 14.4]);
                            }
                    }
                    for (ang = [45, 135, 225, 315]) {
                        rotate([0, 0, ang])
                            translate([m_rad, 0])
                                circle(d = duct_id + 1.0);
                    }
                }
            }

            // 3. 4x Continuous 360-Deg Aerodynamic Ducts (54.18mm ID / 57.28mm OD, 9.70mm outer shroud, 3.00mm inboard arc)
            difference() {
                linear_extrude(height = duct_height) {
                    difference() {
                        union() {
                            for (ang = [45, 135, 225, 315]) {
                                rotate([0, 0, ang])
                                    translate([m_rad, 0])
                                        circle(d = duct_od);
                            }
                        }
                        for (ang = [45, 135, 225, 315]) {
                            rotate([0, 0, ang])
                                translate([m_rad, 0])
                                    circle(d = duct_id);
                        }
                    }
                }
                // Trim inboard duct arcs above Z = 3.00mm so 25.5x25.5 AIO FC, MicroSD & battery straps have full clearance
                for (ang = [45, 135, 225, 315]) {
                    rotate([0, 0, ang])
                        translate([m_rad - duct_od - 5.5, -duct_od/2 - 1.0, inboard_ring_h])
                            cube([duct_od, duct_od + 2.0, duct_height]);
                }
            }

            // 4. Outer Cardinal Inter-Duct Bumper Bridges (Z = 0..9.70mm, strictly nested inside duct walls)
            for (c_ang = [0, 90, 180, 270]) {
                b_hy = motor_xy - duct_id/2 - 0.45; // 33.44 - 27.09 - 0.45 = 5.90 mm
                rotate([0, 0, c_ang])
                    translate([motor_xy - 1.0, -b_hy, 0])
                        cube([4.4, 2 * b_hy, duct_height]);
            }

            // 5. 4x Cardinal Diamond M2 AIO Flight Controller Standoffs (Z = 0..5.50mm)
            for (c_ang = [0, 90, 180, 270]) {
                rotate([0, 0, c_ang])
                    translate([fc_radius, 0, 0])
                        cylinder(d = 5.40, h = fc_standoff_top_z);
            }
        }

        // --- UNIFIED 3D BOOLEAN SUBTRACTIONS ---

        // A. Downward Matek 3901-L1X Optical Flow (42 deg) & VL53L1X LiDAR (27 deg) Center Viewport (Ø14.50mm)
        translate([0, 0, -0.1])
            cylinder(d = 14.50, h = arm_height + 0.3);

        // B. 10.2 x 2.0 mm Silicone Battery Strap Slots along Left/Right of Longitudinal Battery Axis
        for (sx = [-1, 1]) {
            translate([sx * 9.8 - 1.0, -5.1, -0.1])
                cube([2.0, 10.2, inboard_ring_h + 0.3]);
        }

        // C. 4x Cardinal Diamond M2 Flight Controller Through-Holes (Ø2.05mm)
        for (c_ang = [0, 90, 180, 270]) {
            rotate([0, 0, c_ang])
                translate([fc_radius, 0, -0.1])
                    cylinder(d = fc_hole_dia, h = fc_standoff_top_z + 1.0);
        }

        // D. 4x Motor Shaft Relief (Ø3.20mm) + 3-Hole 6.60mm PCD M1.6 Screw Pattern (0/120/240 deg -> 180 deg wire exit clear!)
        for (ang = [45, 135, 225, 315]) {
            rotate([0, 0, ang])
                translate([m_rad, 0, -0.1]) {
                    cylinder(d = motor_shaft_dia, h = arm_height + 0.3);
                    for (m_ang = [0, 120, 240]) {
                        rotate([0, 0, m_ang])
                            translate([motor_pcd / 2.0, 0, 0])
                                cylinder(d = motor_screw_dia, h = arm_height + 0.3);
                    }
                }
        }

        // E. Protected Top-Recessed Stator Solder-Tab & Motor-Wire U-Channel + Flared FC Waist Riser Pocket
        // Cuts cleanly through Z=2.50mm arm top AND Z=3.00mm inboard duct base ring while keeping Z=0.000mm 100% flat!
        translate([0, 0, arm_height - wire_chan_depth])
            linear_extrude(height = (inboard_ring_h - (arm_height - wire_chan_depth)) + 0.60) {
                r_f  = 0.45;
                y_o  = (wire_chan_w / 2.0) - r_f;
                y_fl = 2.30 - r_f;
                x_in = 11.20 + r_f;
                x_wa = 15.00 + r_f;
                x_en = m_rad - (4.35 + r_f);
                for (ang = [45, 135, 225, 315]) {
                    rotate([0, 0, ang]) {
                        hull() {
                            for (sy = [-1, 1]) {
                                translate([x_wa, sy * y_o]) circle(r = r_f);
                                translate([x_en, sy * y_o]) circle(r = r_f);
                            }
                        }
                        hull() {
                            for (sy = [-1, 1]) {
                                translate([x_in, sy * y_fl]) circle(r = r_f);
                                translate([x_wa, sy * y_o])  circle(r = r_f);
                            }
                        }
                    }
                }
            }
    }
}

osito_interceptor_95mm_frame();
