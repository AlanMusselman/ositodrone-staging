// ============================================================================
// OSITO CUB-75: 75mm 1S 550mAh ELRS Kids Training Drone (OpenSCAD CSG Master)
// 100% In-Office 3D-Printable Airframe, Finger-Safe Prop Cage & Training System
// ============================================================================
// ENGINEERING VERIFICATION:
// 1. Wheelbase: 75.0mm diagonal motor-to-motor (R_motor = 37.5mm at 45/135/225/315 deg).
// 2. Prop Clearance: 42.0mm ID / 45.2mm OD 360-deg ducts for 40mm (Gemfan 1610/1630)
//    props. Inboard duct edge sits at R = 37.5 - 22.6 = 14.9mm from center,
//    clearing the 25.5x25.5mm Whoop AIO FC PCB (14.2mm half-width) completely.
// 3. Kid-Safe Finger Guard Cage: Bottom 4-strut motor guard + raised 10.0mm duct
//    walls + arched top finger-guard ribs prevent small fingers from touching blades.
// 4. Power Bay: Unobstructed 70.0 x 18.5 x 7.5mm 1S 550mAh LiHV battery bay with
//    integrated wide-stance shock-absorbing training landing skids.
// 5. AIO Stack: Standard 25.5 x 25.5mm Whoop AIO cardinal diamond (R = 18.031mm).
// ============================================================================

$fn = 72;

// Overridden via CLI: openscad -D PART_ID=1 ...
// 0 = Exploded Full Assembly Preview
// 1 = CUB75_Frame_KidSafe_75mm.stl    (Main 75mm Frame + 360 Ducts + Top Finger Guards)
// 2 = CUB75_TPU_Bumper_Ring.stl       (Slip-On TPU 95A Outer Wall-Bounce Bumper Belt)
// 3 = CUB75_550mAh_Trainer_Skids.stl  (1S 550mAh Battery Cradle + Wide Training Skids)
// 4 = CUB75_Canopy_LOS_CubDome.stl    (Directional Arrow + Bear-Ear Roll Cage LOS Canopy)
// 5 = CUB75_Canopy_FPV_Pod.stl        (14x14mm Nano FPV Camera Pod - 10 deg Beginner Tilt)
// 6 = CUB75_Motor_Prop_Press_Jig.stl  (In-Office Bench Tool for Safe Prop Installation)
PART_ID = 0;

// --- Core Airframe Dimensions (mm) ---
wheelbase_diag      = 75.0;
m_rad               = wheelbase_diag / 2.0; // 37.5 mm
arm_width           = 5.2;  // 2x 1.25mm (3-perimeter) structural flanges beside 2.70mm wire channel
arm_height          = 2.6;
wire_chan_width     = 2.70;
wire_chan_depth     = 0.85;

// Duct & Finger-Safe Guard Parameters (for 40mm Props)
hoop_id             = 42.0;
hoop_wall           = 1.6;
hoop_od             = hoop_id + 2 * hoop_wall; // 45.2 mm
duct_height         = 10.0; // Full-height encloses prop plane completely
bridge_r            = m_rad / sqrt(2); // 26.5165 mm X/Y motor center coordinate

// Motor Mounts (0802 / 0803 / 1002: 3-hole 6.6mm bolt circle, M1.4 screws)
// Enlarged from 8.8mm (0.38mm wall -> blew open) to 12.4mm OD (>= 2.18mm solid wall)
motor_boss_dia      = 12.4;
motor_gusset_span   = 9.5;
motor_hole_circle   = 6.6;
motor_screw_dia     = 1.45;
motor_shaft_dia     = 2.3;

// Flight Controller Mount (25.5 x 25.5mm Whoop AIO Cardinal Diamond)
fc_mount_span       = 25.5;
fc_radius           = fc_mount_span / sqrt(2); // 18.0312 mm at 0, 90, 180, 270 deg
fc_hole_dia         = 2.05;
fc_air_gap          = 3.0;

// 1S 550mAh LiHV Battery Cradle (70.0 x 18.5 x 7.5mm internal slot)
batt_len            = 70.0;
batt_width          = 18.5;
batt_height         = 7.5;
cradle_wall         = 1.8;

// ============================================================================
// HELPER MODULES
// ============================================================================
module fc_hole_positions() {
    for (angle = [0, 90, 180, 270]) {
        rotate([0, 0, angle])
            translate([fc_radius, 0, 0])
                children();
    }
}

module fc_diamond_hub(thickness) {
    hull() {
        cylinder(d=24.0, h=thickness);
        fc_hole_positions() {
            cylinder(d=6.2, h=thickness);
        }
    }
}

// ============================================================================
// 1. CUB75_Frame_KidSafe_75mm.stl — 75mm Kid-Safe Ducted Frame + Finger Cage
// ============================================================================
module cub75_frame_kidsafe() {
    difference() {
        union() {
            // 1. Central Whoop AIO Diamond Hub
            fc_diamond_hub(arm_height);

            // 2. 4x Raised 3.0mm FC Standoffs (0, 90, 180, 270 deg)
            fc_hole_positions() {
                cylinder(d=5.2, h=arm_height + fc_air_gap);
            }

            // 3. 4x Diagonal Arms + Motor Bosses + Full-Height 360 Ducts + Finger Cage
            for (angle = [45, 135, 225, 315]) {
                rotate([0, 0, angle]) {
                    // Main Diagonal Arm + Smooth Teardrop Motor-Pad Gusset
                    translate([0, -arm_width/2, 0])
                        cube([m_rad, arm_width, arm_height]);
                    hull() {
                        translate([m_rad, 0, 0])
                            cylinder(d=motor_boss_dia, h=arm_height);
                        translate([m_rad - motor_gusset_span, -arm_width/2, 0])
                            cube([0.6, arm_width, arm_height]);
                    }

                    // Duct Assembly centered on Motor
                    translate([m_rad, 0, 0]) {
                        // Full 360° Base Ring (3.2mm tall for inboard FC clearance)
                        difference() {
                            cylinder(d=hoop_od, h=3.2);
                            translate([0, 0, -0.1])
                                cylinder(d=hoop_id, h=3.4);
                        }
                        // Raised 10.0mm Outer 250° Kid-Safe Duct Wall
                        intersection() {
                            difference() {
                                cylinder(d=hoop_od, h=duct_height);
                                translate([0, 0, -0.1])
                                    cylinder(d=hoop_id, h=duct_height + 0.2);
                            }
                            translate([-4.0, -hoop_od/2 - 1, 0])
                                cube([hoop_od, hoop_od + 2, duct_height + 0.2]);
                        }
                        // 4x Bottom Radial Finger-Guard Struts (flush with Z=0.000mm PEI plate)
                        for (s_ang = [-65, -20, 20, 65]) {
                            rotate([0, 0, s_ang])
                                translate([motor_boss_dia/2 - 0.8, -1.4, 0])
                                    cube([hoop_id/2 - motor_boss_dia/2 + 1.4, 2.8, arm_height]);
                        }
                        // 3x Upper Arched Kid-Safe Finger Guard Ribs oriented INWARD toward (0,0)
                        for (t_ang = [135, 180, 225]) {
                            rotate([0, 0, t_ang]) {
                                for (i = [0:4]) {
                                    r1 = 4.0 + i * (hoop_id/2 - 3.2)/5.0;
                                    r2 = 4.0 + (i + 1) * (hoop_id/2 - 3.2)/5.0;
                                    z_arch = (i == 2) ? 0.35 : ((i == 1 || i == 3) ? 0.20 : 0.0);
                                    hull() {
                                        translate([r1, -1.1, duct_height - 1.55 + z_arch])
                                            cube([0.1, 2.2, 1.55]);
                                        translate([r2, -1.1, duct_height - 1.55 + z_arch])
                                            cube([0.1, 2.2, 1.55]);
                                    }
                                }
                            }
                        }
                        // Upper Central Finger-Guard Ring above Motor Nut (OD 10.4mm, ID 6.4mm)
                        translate([0, 0, duct_height - 1.55])
                            difference() {
                                cylinder(d=10.4, h=1.55);
                                translate([0, 0, -0.1])
                                    cylinder(d=6.4, h=1.75);
                            }
                        // Twin-Pillar Straddle Gate anchoring central 180° rib while leaving a 2.80mm
                        // unobstructed motor-wire tunnel straight through the inboard duct wall!
                        rotate([0, 0, 180]) {
                            for (sy_g = [-1, 1]) {
                                translate([hoop_id/2 - 0.1, sy_g * 2.25 - 0.85, 2.5])
                                    cube([1.8, 1.7, duct_height - 1.55 - 2.4]);
                            }
                            hull() {
                                translate([hoop_id/2 - 0.1, -3.10, duct_height - 3.20])
                                    cube([1.8, 6.20, 0.30]);
                                translate([hoop_id/2 - 0.1, -1.20, duct_height - 1.65])
                                    cube([1.8, 2.40, 0.30]);
                            }
                        }
                    }
                }
            }

            // 4. 4x Cardinal Tangential Truss Bridges + Bumper Latch Tabs (0, 90, 180, 270 deg)
            for (c_ang = [0, 90, 180, 270]) {
                rotate([0, 0, c_ang]) {
                    hull() {
                        translate([fc_radius, 0, 0])
                            cylinder(d=5.4, h=3.2);
                        translate([bridge_r, -5.5, 0])
                            cube([4.0, 11.0, 3.2]);
                    }
                    // Outer Bridge Wall uniting adjacent ducts (W=11.0mm, guaranteeing 1.0165mm clearance)
                    translate([bridge_r - 0.8, -5.5, 0])
                        cube([4.8, 11.0, duct_height]);
                }
            }
        }

        // --- BOOLEAN SUBTRACTIONS ---
        // A. Subtract Swept Interior of All 4 Propellers (d=41.2mm starting at arm_height - 0.05, stopping at 8.45mm)
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle])
                translate([m_rad, 0, arm_height - 0.05])
                    cylinder(d=41.2, h=duct_height - arm_height - 1.50);
        }

        // B. Center Weight-Reduction & Cooling Cutout
        translate([0, 0, -0.1])
            cylinder(d=14.0, h=arm_height + 0.2);

        // C. 4x Cardinal Diamond M2 Flight Controller Through-Holes
        fc_hole_positions() {
            translate([0, 0, -0.1])
                cylinder(d=fc_hole_dia, h=duct_height + 2.0);
        }

        // D. Motor Center Shaft Relief (2.3mm) + 3x M1.4 Screw Holes (6.6mm circle)
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle])
                translate([m_rad, 0, -0.1]) {
                    cylinder(d=motor_shaft_dia, h=arm_height + 0.2);
                    for (m_ang = [0, 120, 240]) {
                        rotate([0, 0, m_ang])
                            translate([motor_hole_circle/2, 0, 0])
                                cylinder(d=motor_screw_dia, h=arm_height + 0.2);
                    }
                }
        }

        // E. Top Recessed Stator Solder-Tab & Motor-Wire U-Channel + FC Waist Wire-Riser Pocket
        // Preserves 100% flat Z = 0.000mm Textured PEI bottom across all arms and motor pads!
        translate([0, 0, arm_height - wire_chan_depth])
            linear_extrude(height=(3.2 - (arm_height - wire_chan_depth)) + 0.65) {
                r_f = 0.45;
                y_o = (wire_chan_width / 2.0) - r_f;
                y_fl = 2.30 - r_f;
                x_in = 11.00 + r_f;
                x_wa = 14.80 + r_f;
                x_en = m_rad - (4.05 + r_f);
                for (angle = [45, 135, 225, 315]) {
                    rotate([0, 0, angle]) {
                        hull() {
                            for (sy = [-1, 1]) {
                                translate([x_wa, sy * y_o]) circle(r=r_f);
                                translate([x_en, sy * y_o]) circle(r=r_f);
                            }
                        }
                        hull() {
                            for (sy = [-1, 1]) {
                                translate([x_in, sy * y_fl]) circle(r=r_f);
                                translate([x_wa, sy * y_o])  circle(r=r_f);
                            }
                        }
                    }
                }
            }
    }
}

// ============================================================================
// 2. CUB75_TPU_Bumper_Ring.stl — Slip-On 360° TPU 95A Classroom Wall Bumper
// ============================================================================
module cub75_tpu_bumper_ring() {
    bumper_thick = 2.4;
    bumper_h     = 6.0;
    lip_w        = 1.2;

    union() {
        // 4x Outer Arc Cushions wrapping around the 45.2mm OD ducts
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle])
                translate([m_rad, 0, 0]) {
                    intersection() {
                        difference() {
                            cylinder(d=hoop_od + 2*bumper_thick, h=bumper_h);
                            translate([0, 0, -0.1])
                                cylinder(d=hoop_od - 0.2, h=bumper_h + 0.2);
                        }
                        translate([-14.5, -hoop_od, 0])
                            cube([hoop_od + 14.5, 2*hoop_od, bumper_h]);
                    }
                    // Inner Top/Bottom Retaining Lips that snap over the duct rim
                    intersection() {
                        difference() {
                            cylinder(d=hoop_od + 0.2, h=bumper_h);
                            translate([0, 0, 1.2])
                                cylinder(d=hoop_od + 0.6, h=bumper_h - 2.4);
                            translate([0, 0, -0.1])
                                cylinder(d=hoop_od - 2*lip_w, h=bumper_h + 0.2);
                        }
                        translate([2.0, -hoop_od, 0])
                            cube([hoop_od, 2*hoop_od, bumper_h]);
                    }
                }
        }
        // 4x Cardinal Flex Straps uniting the 4 corner bumpers into a 1-piece belt
        for (c_ang = [0, 90, 180, 270]) {
            rotate([0, 0, c_ang])
                translate([bridge_r + 3.0, -7.5, 0])
                    cube([3.2, 15.0, bumper_h]);
        }
    }
}

// ============================================================================
// 3. CUB75_550mAh_Trainer_Skids.stl — 1S 550mAh Cradle + Wide Training Skids
// ============================================================================
module cub75_550_trainer_skids() {
    outer_l = batt_len + 2*cradle_wall;   // 73.6 mm
    outer_w = batt_width + 2*cradle_wall; // 22.1 mm
    outer_h = batt_height + 2*cradle_wall;// 11.1 mm
    skid_span_y = 26.0;                   // 52mm total stance width for stable landings!

    difference() {
        union() {
            // Central 1S 550mAh Battery Sleeve
            translate([-outer_l/2, -outer_w/2, -outer_h])
                cube([outer_l, outer_w, outer_h]);

            // Outboard Left & Right M2 Stack Mounting Wings at (0, +/-18.031mm)
            for (y_sign = [-1, 1]) {
                hull() {
                    translate([0, y_sign * (outer_w/2 - 1.0), -3.0])
                        cylinder(d=9.0, h=3.0);
                    translate([0, y_sign * fc_radius, -3.0])
                        cylinder(d=6.8, h=3.0);
                }
                // Wide-Stance Angled Training Skid Legs (Front & Rear)
                for (x_leg = [-20.0, 20.0]) {
                    hull() {
                        translate([x_leg, y_sign * (outer_w/2 - 1.0), -outer_h + 2.5])
                            sphere(d=3.6);
                        translate([x_leg, y_sign * skid_span_y, -outer_h - 3.5])
                            sphere(d=3.6);
                    }
                }
                // Left & Right Parallel Floor Runner Skids (52mm long)
                hull() {
                    translate([-24.0, y_sign * skid_span_y, -outer_h - 3.5])
                        sphere(d=3.8);
                    translate([24.0, y_sign * skid_span_y, -outer_h - 3.5])
                        sphere(d=3.8);
                }
            }
        }

        // Unobstructed 70.0 x 18.5 x 7.5mm 1S 550mAh Battery Tunnel
        translate([-outer_l/2 - 0.1, -batt_width/2, -cradle_wall - batt_height])
            cube([outer_l + 0.2, batt_width, batt_height]);

        // Side Finger-Push & Cooling Windows
        for (x_win = [-22, 0, 22]) {
            translate([x_win - 5.5, -outer_w/2 - 0.1, -cradle_wall - batt_height + 1.5])
                cube([11.0, outer_w + 0.2, batt_height - 3.0]);
        }

        // Bottom Weight-Saving Window
        translate([-24.0, -6.0, -outer_h - 0.1])
            cube([48.0, 12.0, cradle_wall + 0.2]);

        // Left & Right M2 Stack Mounting Holes
        for (y_sign = [-1, 1]) {
            translate([0, y_sign * fc_radius, -outer_h - 0.1])
                cylinder(d=fc_hole_dia, h=outer_h + 0.2);
        }
    }
}

// ============================================================================
// SHARED CARDINAL M2 VAULTED PILLAR HELPER (100% OSITO_KODIAK_FC_v1 Connector-Clear)
// ============================================================================
module cub75_fc_clear_pillar_2d() {
    hull() {
        translate([fc_radius, 0])        circle(d=4.00);
        translate([fc_radius + 1.35, 0]) circle(d=5.00);
    }
}

// ============================================================================
// 4. CUB75_Canopy_LOS_CubDome.stl — Vaulted Directional Arrow + Bear-Ear LOS Canopy
// ============================================================================
module cub75_canopy_los() {
    difference() {
        union() {
            // 4x Low-Profile Cardinal M2 Standoff Feet (Z = 0 .. 2.60mm -> open M2 screw access!)
            linear_extrude(height=2.60) {
                for (c_ang = [0, 90, 180, 270]) {
                    rotate([0, 0, c_ang])
                        cub75_fc_clear_pillar_2d();
                }
            }
            // 4x Steep Riser Legs + Vaulted Arch Ribs above Z=5.80mm (clears mated J_M1..J_M4 plugs!)
            for (c_ang = [0, 90, 180, 270]) {
                rotate([0, 0, c_ang]) {
                    hull() {
                        translate([16.10, -1.30, 1.80])
                            cube([1.55, 2.60, 0.80]);
                        translate([14.60, -1.30, 5.80])
                            cube([1.60, 2.60, 1.50]);
                    }
                    hull() {
                        translate([14.60, -1.30, 5.80])
                            cube([1.60, 2.60, 1.50]);
                        translate([0, 0, 14.20])
                            cylinder(d=6.80, h=2.00, $fn=48);
                    }
                }
            }
            // Forward Pointer Nose Arrow (+X = Front of Drone) extending outboard of Front Foot
            hull() {
                translate([19.20, -2.10, 0.00]) cube([1.80, 4.20, 2.60]);
                translate([23.60, 0, 0.00])     cylinder(d=2.40, h=2.60, $fn=36);
            }
            // "Osito Cub" Round Bear-Ear Roll Cage Lobes on Left & Right Arch Crowns
            for (y_sign = [-1, 1]) {
                hull() {
                    translate([0, y_sign * 4.80, 13.60])
                        sphere(d=4.80, $fn=36);
                    translate([0, y_sign * 7.20, 16.40])
                        sphere(d=5.40, $fn=36);
                }
            }
        }
        // 4x M2 Mounting Through-Holes
        fc_hole_positions() {
            translate([0, 0, -0.10])
                cylinder(d=fc_hole_dia, h=4.00);
        }
    }
}

// ============================================================================
// 5. CUB75_Canopy_FPV_Pod.stl — Vaulted 14x14mm Nano FPV Camera Pod (10° Kid Tilt)
// ============================================================================
module cub75_canopy_fpv() {
    difference() {
        union() {
            // 4x Low-Profile Cardinal M2 Standoff Feet (Z = 0 .. 2.60mm -> open M2 screw access!)
            linear_extrude(height=2.60) {
                for (c_ang = [0, 90, 180, 270]) {
                    rotate([0, 0, c_ang])
                        cub75_fc_clear_pillar_2d();
                }
            }
            for (c_ang = [0, 90, 180, 270]) {
                rotate([0, 0, c_ang])
                    hull() {
                        translate([16.10, -1.30, 1.80])
                            cube([1.55, 2.60, 0.80]);
                        translate([14.60, -1.30, 5.80])
                            cube([1.60, 2.60, 1.50]);
                    }
            }
            // Port (+Y) & Starboard (-Y) Arch Struts rising from Z=5.80mm into 14.3mm-gap Camera Cheeks
            for (sy = [-1, 1]) {
                hull() {
                    translate([-1.30, sy * 14.60 + (sy < 0 ? -1.60 : 0.0), 5.80])
                        cube([2.60, 1.60, 1.50]);
                    translate([-3.80, sy * 7.15 + (sy < 0 ? -1.85 : 0.0), 11.80])
                        cube([9.40, 1.85, 8.20]);
                }
                hull() {
                    translate([-3.40, sy * 7.15 + (sy < 0 ? -1.85 : 0.0), 18.20])
                        cube([8.60, 1.85, 1.80]);
                    translate([1.00, 0, 22.40])
                        cylinder(d=7.20, h=1.80, $fn=48);
                }
            }
            // Front (+X) Centerline Chin Strut + V-Yoke
            hull() {
                translate([14.60, -1.30, 5.80]) cube([1.60, 2.60, 1.50]);
                translate([10.00, -1.30, 9.40]) cube([1.80, 2.60, 1.80]);
            }
            for (sy = [-1, 1]) {
                hull() {
                    translate([10.00, -1.30, 9.40]) cube([1.80, 2.60, 1.80]);
                    translate([3.60, sy * 7.15 + (sy < 0 ? -1.85 : 0.0), 13.80]) cube([2.00, 1.85, 2.00]);
                }
            }
            // Rear (-X) Centerline Spine + Pre-Hollowed Whip Antenna Sleeve
            hull() {
                translate([-16.20, -1.30, 5.80]) cube([1.60, 2.60, 1.50]);
                translate([-8.80, -1.60, 11.20])  cube([2.40, 3.20, 2.40]);
            }
            for (sy = [-1, 1]) {
                hull() {
                    translate([-8.80, -1.60, 11.20]) cube([2.40, 3.20, 2.40]);
                    translate([-3.80, sy * 7.15 + (sy < 0 ? -1.85 : 0.0), 15.60]) cube([2.00, 1.85, 3.60]);
                }
            }
            translate([-7.80, 0, 12.40])
                rotate([0, -25, 0])
                    difference() {
                        cylinder(d=3.80, h=9.50, $fn=32);
                        translate([0, 0, -0.20]) cylinder(d=1.80, h=9.90, $fn=32);
                    }
        }
        // 4x M2 Stack Mounting Holes
        fc_hole_positions() {
            translate([0, 0, -0.10])
                cylinder(d=fc_hole_dia, h=4.00);
        }
        // M2 Nano FPV Camera Side-Mount Pivot Bore (10-deg beginner horizon tilt ready)
        translate([0.90, 0, 16.00])
            rotate([90, 0, 0])
                cylinder(d=2.05, h=24.0, center=true, $fn=32);
    }
}

// ============================================================================
// 6. CUB75_Motor_Prop_Press_Jig.stl — Bench Tool for Safe Prop Installation
// ============================================================================
module cub75_prop_jig() {
    difference() {
        union() {
            // Ergonomic Bench Base
            cylinder(d=28.0, h=4.0);
            // Motor Bell Cradle Tower (Supports 0802/1002 motor base while pressing prop)
            cylinder(d=16.0, h=14.0);
        }
        // Top Recess for 10.5mm-12.0mm Motor Bell (12.4mm ID)
        translate([0, 0, 6.0])
            cylinder(d=12.4, h=9.0);
        // Center Relief for Motor C-Clip & Bottom Shaft (4.5mm ID)
        translate([0, 0, -0.1])
            cylinder(d=4.5, h=15.0);
        // Side Slot for Motor Phase Wires
        translate([0, -2.5, 2.0])
            cube([16.0, 5.0, 13.0]);
    }
}

// ============================================================================
// RENDER DISPATCHER
// ============================================================================
if (PART_ID == 1) {
    cub75_frame_kidsafe();
} else if (PART_ID == 2) {
    cub75_tpu_bumper_ring();
} else if (PART_ID == 3) {
    rotate([180, 0, 0]) cub75_550_trainer_skids();
} else if (PART_ID == 4) {
    cub75_canopy_los();
} else if (PART_ID == 5) {
    cub75_canopy_fpv();
} else if (PART_ID == 6) {
    cub75_prop_jig();
} else {
    color("DarkSlateGray") cub75_frame_kidsafe();
    color("DarkOrange")    translate([0, 0, 2.0]) cub75_tpu_bumper_ring();
    color("DodgerBlue")    translate([0, 0, -2.0]) cub75_550_trainer_skids();
    color("Gold")          translate([0, 0, 10.0]) cub75_canopy_los();
}
