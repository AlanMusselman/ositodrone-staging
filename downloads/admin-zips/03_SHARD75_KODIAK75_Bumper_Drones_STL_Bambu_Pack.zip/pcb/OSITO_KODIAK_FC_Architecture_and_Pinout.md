# OSITO-KODIAK-G473 (`OSITO_KODIAK_FC_v1` Rev 1.0): 1S 12A 5-in-1 Brushless Flight Controller

**Organization:** Osito Drone LLC (`ositodrone.com`)  
**Board Codename:** `OSITO_KODIAK_FC_v1` (Betaflight `BETAFPVG473` + Bluejay `O-H-5 48kHz` Drop-In Compatible)  
**Supported Fleet:** **CUB-75** (`39.5g` STEM Academy Trainer) & **SHARD-75 / KODIAK-75** (`45.5g` Combat/Bumper Drone)  
**Manufacturing Target:** **JLCPCB Turnkey 2-Sided SMT Assembly** (4-Layer `1.0mm` FR4, ENIG Finish, `107` SMD Components: `45` Top / `62` Bottom)  
**Estimated Turnkey Cost (at 20–50 pcs):** **`~$15.80` / assembled board** (replacing `$44.99` retail COTS 5-in-1 AIO)

---

## 1. Key Engineering Highlights

1. **100% Zero-Solder Fleet Maintenance (All 8 Plug-and-Play Sockets on Top Side `F.Cu`)**:
   - **4× `JST-1.25mm` 3-Pin Vertical Motor Sockets (`J_M1`–`J_M4`)** along the four 45° diagonal motor edges for 30-second classroom motor swaps.
   - **Right-Angle SMD `BT2.0 / A30` High-Current 1S Battery Connector (`J_BAT`)** at the rear-right tail edge—zero heavy battery pigtail soldering.
   - **5-Pin `JST-SH` FPV Camera + VTX + SmartAudio Port (`J_CAM`)**, **4-Pin `JST-SH` USB-C Dongle Port (`J_USB`)**, and **3-Pin `JST-SH` External LED Halo Port (`J_LED_EXT`)**.
2. **10× Factory-Mounted `WS2812B-2020` Addressable RGB LEDs (`LED1`–`LED10` on `F.Cu`)**:
   - `LED1, LED2` (Front-Left `M4`), `LED3, LED4` (Front-Right `M2`), `LED5, LED6` (Rear-Right `M1`), `LED7, LED8` (Rear-Left `M3`), and `LED9, LED10` (Front Canopy Glow), driven from `PB2` (`LED_STRIP`) with daisy-chain output to `J_LED_EXT`.
3. **Contoured `28.4 × 28.4 mm` Whoop Cardinal Diamond (`25.5 × 25.5 mm` M2 Pattern)**:
   - Clears `KODIAK-75`'s `R = 14.90 mm` inboard prop hoops (`14.20 mm` waist half-width) while preserving standard `25.5 × 25.5 mm` Whoop M2 silicone-grommet mounting ears at `(0, ±18.031 mm)` and `(±18.031, 0 mm)`.
   - Ultra-low-profile bottom side (`B.Cu <= 1.10 mm` max component height, zero through-hole pins) sits safely above the 1S LiHV battery bay.
4. **Upstream Firmware Compatibility (Zero Custom C++ Forks)**:
   - **Flight Controller (`U1: STM32G473CEU6`)**: Flashes standard Betaflight 4.5+ **`BETAFPVG473`** (`set gyro_1_sensor_align = CW45` / diamond alignment preset).
   - **4-in-1 12A ESC (`U4_M1..4: EFM8BB21F16G` + `Q1..Q12: FDMA1032CZ` Dual N+P)**: Flashes standard **Bluejay `O-H-5 48kHz`** for Bidirectional DShot300 RPM filtering and Turtle Mode.
   - **Integrated ELRS 2.4GHz RX (`U5: ESP8285H16` + `U7: SX1281IMLTRT` + `ANT1` Ceramic Chip Antenna)**: Wired internally to `UART3` (`PB10/PB11`) with an all-layer copper keepout window under `ANT1`.

---

## 2. 4-Layer Stackup & Subsystem Pin Map (`1.0 mm` FR4)

- **`L1 (F.Cu)`**: MCU (`U1`), SPI1 Gyro (`U2`) + dedicated LDO (`U6_GYRO`), Hall Armor Hit Sensor (`U8`), ELRS 2.4GHz (`U5`, `U7`, `Y2`, `ANT1`), `10× WS2812B-2020` (`LED1..10`), and all `8` top-entry connectors.
- **`L2 (In1.Cu)`**: Solid `GND` copper pour (`ZONE_CONNECTION_FULL`, `0.10 mm` clearance, `100%` unbroken beneath the 2.4 GHz ELRS RF feedline) + horizontal inner signal routing.
- **`L3 (In2.Cu)`**: Solid `GND` copper pour (`ZONE_CONNECTION_FULL`, `0.10 mm` clearance) + vertical inner signal & power routing.
- **`L4 (B.Cu)`**: 4× `EFM8BB21` ESC MCUs (`U4_M1..4`), 12× `FDMA1032CZ` Complementary N+P MOSFET half-bridges (`Q1..12`), `TPS63020DSJR` `5V/2A` Buck-Boost BEC (`U3` + `L1`), `3.3V` Digital LDO (`U6_MCU`), `0.5mΩ` Shunt (`R_SHUNT`) + `INA199A1` (`U10`), USB ESD/OR-ing (`D1`, `D_USB`), and `AT7456E` Analog OSD (`U9` + `27MHz Y3`).

| Subsystem | Designators | `STM32G473CEU6` (`U1`) Pins | Notes |
| :--- | :--- | :--- | :--- |
| **Flight MCU & Clock** | `U1`, `Y1` (`8MHz`), `C_Y1A/B`, `R_BOOT`, `C_NRST` | `PF0/PF1 (5/6)`, `NRST (7)`, `PB8-BOOT0 (46)` | `170 MHz` Cortex-M4F, `10k` pull-down on `BOOT0`. |
| **6-Axis IMU & LDO** | `U2` (`ICM-42688-P`), `U6_GYRO` (`RT9013-33GB`) | `PA4 (CS)`, `PA5 (SCK)`, `PA6 (MISO)`, `PA7 (MOSI)`, `PC4 (EXTI)` | Dedicated low-noise `+3V3_GYRO` rail (`10uF + 100nF` X7R). |
| **12A 4-in-1 Bluejay ESC** | `U4_M1..4`, `Q1..Q12`, `R_DS1..4`, `R_M1A..4C` | `M1=PB0 (17)`, `M2=PB1 (18)`, `M3=PB6 (44)`, `M4=PC13 (2)` | Complementary N+P FETs + `10k` BEMF virtual-neutral stars. |
| **ELRS 2.4GHz Receiver** | `U5` (`ESP8285`), `U7` (`SX1281`), `Y2` (`52MHz`), `ANT1` | `PB10 (UART3_TX -> RX)`, `PB11 (UART3_RX <- TX)` | Prop-safe SMD `2450AT18B100` chip antenna + `100pF C0G` DC block. |
| **Analog FPV OSD & Pod** | `U9` (`AT7456E`), `Y3` (`27MHz`), `C_VIN`, `C_VOUT`, `J_CAM` | `PB12 (OSD_CS)`, `PB13..15 (SPI2)`, `PA2 (UART2_TX)` | `5-Pin JST-SH`: `+5V_BEC, GND, CAM_RAW, VTX_VIDEO, UART2_TX`. |
| **5V 2A Buck-Boost BEC** | `U3` (`TPS63020DSJR`), `L1` (`1.5uH`), `R_FB1/2` | Feeds `+5V_BEC` -> `U6_MCU` (`+3V3_MCU`) & `U6_GYRO` | `910k / 100k` divider (`5.05V`), maintains `5V` down to `2.5V` sag. |
| **Battery & Current Sense** | `J_BAT`, `R_SHUNT` (`0.5mΩ`), `U10` (`INA199A1`), `R_VBAT1/2` | `PA0 (ADC_VBAT)`, `PA1 (ADC_CURR)` | `2× 22uF 10V X7S` bulk caps + `50V/V` shunt telemetry. |
| **Armor Hit Sensor** | `U8` (`DRV5032FADBZR`), `C_HALL` | `PC6 (29)` | Omnipolar Hall sensor under nose N52 magnetic armor crown. |
| **10× RGB LEDs + Halo** | `LED1..10` (`WS2812B-2020`), `R_LED` (`330Ω`), `J_LED_EXT` | `PB2 (19)` | `10` onboard LEDs daisy-chained out to 3-pin `J_LED_EXT`. |
| **Bench USB Dongle Port** | `J_USB` (`4-Pin JST-SH`), `D1` (`USBLC6-2SC6`), `D_USB` | `PA11 (USB_DM)`, `PA12 (USB_DP)` | Schottky `MBR0520` powers FC/ELRS on bench without energizing ESCs. |

---

## 3. Turnkey Fabrication Package (`fab/` & Root CSVs)

1. **Gerber + Excellon Archive**: [`OSITO_KODIAK_FC_v1_JLCPCB_GERBERS.zip`](./fab/OSITO_KODIAK_FC_v1_JLCPCB_GERBERS.zip) (4-Layer Gerbers + PTH/NPTH metric Excellon drills + drill map PDF).
2. **Bill of Materials (BOM)**: [`OSITO_KODIAK_FC_JLCPCB_BOM.csv`](./OSITO_KODIAK_FC_JLCPCB_BOM.csv) (`107` SMD parts, `100%` `X7R`/`X7S`/`C0G` capacitors, verified `LCSC Part #`).
3. **Component Placement List (CPL)**: [`OSITO_KODIAK_FC_JLCPCB_CPL.csv`](./OSITO_KODIAK_FC_JLCPCB_CPL.csv) (metric `mm`, Top + Bottom SMD centroids exported natively via `kicad-cli`).
4. **3D Mechanical CAD Assembly**: [`OSITO_KODIAK_FC_v1.step`](./fab/OSITO_KODIAK_FC_v1.step) (ready for CAD fitment checks in `CUB-75` and `KODIAK-75`).
