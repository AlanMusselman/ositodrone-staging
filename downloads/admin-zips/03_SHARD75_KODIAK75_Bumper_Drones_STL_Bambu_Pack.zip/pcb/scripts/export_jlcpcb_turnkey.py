#!/usr/bin/env python3
"""Turnkey KiCad 10 fabrication exporter, 3D raytracer, and JLCPCB gate verifier
for OSITO_KODIAK_FC_v1.

Executes 100% via native kicad-cli.exe:
  1. 4-Layer Gerbers + Excellon PTH/NPTH Drills + Drill Map PDF -> fab/OSITO_KODIAK_FC_v1_JLCPCB_GERBERS.zip
  2. Native SMD Centroid POS/CPL (--units mm --format csv --smd-only --exclude-dnp) -> OSITO_KODIAK_FC_JLCPCB_CPL.csv
  3. Native Schematic BOM + Grouped JLCPCB Turnkey BOM (100% X7R/X7S/C0G) -> OSITO_KODIAK_FC_JLCPCB_BOM.csv
  4. Native 3D Mechanical Assembly STEP (--subst-models) -> fab/OSITO_KODIAK_FC_v1.step
  5. High-Quality Raytraced 3D Inspection Renders -> build/render_top.png, render_bottom.png, render_iso.png
  6. Runs verify_jlcpcb_turnkey_package.py gate (0 ERC, 0 DRC, 0 unrouted, 100% BOM<->CPL parity)
"""

from __future__ import annotations

import csv
import subprocess
import sys
import zipfile
from collections import defaultdict
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PCB_DIR = SCRIPT_DIR.parent
sys.path.insert(0, str(SCRIPT_DIR))

from kodiak_netlist_and_layout import build_components  # noqa: E402

KICAD_CLI = r"C:\Program Files\KiCad\10.0\bin\kicad-cli.exe"
GATE_SCRIPT = Path(r"C:\Users\Alan Musselman\.gemini\config\skills\kicad-pcb-workflow\scripts\verify_jlcpcb_turnkey_package.py")
PROJECT_NAME = "OSITO_KODIAK_FC_v1"


def run_cmd(cmd: list[str], cwd: Path, allow_codes: tuple[int, ...] = (0,)) -> None:
    print(">>", " ".join(f'"{c}"' if " " in c else c for c in cmd))
    res = subprocess.run(cmd, cwd=str(cwd), check=False)
    if res.returncode not in allow_codes:
        raise RuntimeError(f"Command failed with exit code {res.returncode}: {cmd}")


def main() -> int:
    sch_file = PCB_DIR / f"{PROJECT_NAME}.kicad_sch"
    pcb_file = PCB_DIR / f"{PROJECT_NAME}.kicad_pcb"
    build_dir = PCB_DIR / "build"
    fab_dir = PCB_DIR / "fab"
    gerber_dir = fab_dir / "gerbers"

    build_dir.mkdir(parents=True, exist_ok=True)
    gerber_dir.mkdir(parents=True, exist_ok=True)

    # Clear stale gerber files
    for old in gerber_dir.glob("*"):
        if old.is_file():
            old.unlink()

    # 1. Native 4-Layer Gerbers + Excellon Drills + Map PDF
    run_cmd([
        KICAD_CLI, "pcb", "export", "gerbers",
        "--layers", "F.Cu,In1.Cu,In2.Cu,B.Cu,F.Paste,B.Paste,F.SilkS,B.SilkS,F.Mask,B.Mask,Edge.Cuts",
        "--subtract-soldermask",
        "--use-drill-file-origin",
        "-o", str(gerber_dir) + "\\",
        str(pcb_file),
    ], PCB_DIR)

    run_cmd([
        KICAD_CLI, "pcb", "export", "drill",
        "--format", "excellon",
        "--excellon-units", "mm",
        "--excellon-separate-th",
        "--generate-map",
        "--map-format", "pdf",
        "-o", str(gerber_dir) + "\\",
        str(pcb_file),
    ], PCB_DIR)

    gerber_zip = fab_dir / f"{PROJECT_NAME}_JLCPCB_GERBERS.zip"
    with zipfile.ZipFile(gerber_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for gf in sorted(gerber_dir.iterdir()):
            if gf.is_file():
                zf.write(gf, arcname=gf.name)
    print(f"Created {gerber_zip.name} ({gerber_zip.stat().st_size:,} bytes)")

    # 2. Native Metric SMD CPL / POS CSV
    cpl_csv = PCB_DIR / "OSITO_KODIAK_FC_JLCPCB_CPL.csv"
    run_cmd([
        KICAD_CLI, "pcb", "export", "pos",
        "--format", "csv",
        "--units", "mm",
        "--side", "both",
        "--smd-only",
        "--exclude-dnp",
        "-o", str(cpl_csv),
        str(pcb_file),
    ], PCB_DIR)

    # 3. Native Schematic BOM + JLCPCB Grouped Turnkey BOM CSV
    sch_bom_csv = fab_dir / f"{PROJECT_NAME}_SCH_BOM.csv"
    run_cmd([
        KICAD_CLI, "sch", "export", "bom",
        "--fields", "Reference,Value,Footprint,LCSC,Description,${QUANTITY},${DNP}",
        "--labels", "Designator,Comment,Footprint,LCSC Part #,Description,Qty,DNP",
        "--group-by", "Value,Footprint,LCSC",
        "--exclude-dnp",
        "-o", str(sch_bom_csv),
        str(sch_file),
    ], PCB_DIR)

    comps = build_components()
    grouped: dict[tuple[str, str, str, str, str], list[str]] = defaultdict(list)
    for c in comps:
        grouped[(c.value, c.fp_name, c.lcsc, c.desc, c.subsystem)].append(c.ref)

    bom_csv = PCB_DIR / "OSITO_KODIAK_FC_JLCPCB_BOM.csv"
    with bom_csv.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Comment", "Designator", "Footprint", "LCSC Part #", "Qty", "Subsystem", "Description"])
        for (val, fp_name, lcsc, desc, subsys), refs in sorted(grouped.items(), key=lambda kv: (kv[0][4], kv[1][0])):
            refs_sorted = sorted(refs)
            writer.writerow([val, ",".join(refs_sorted), fp_name, lcsc, len(refs_sorted), subsys, desc])
    print(f"Wrote {bom_csv.name} ({len(comps)} total SMD parts across {len(grouped)} unique BOM lines)")

    # 4. Native 3D STEP Export (exit code 2 in KiCad 10 indicates non-fatal missing VRML/3D models while STEP is written)
    step_out = fab_dir / f"{PROJECT_NAME}.step"
    run_cmd([
        KICAD_CLI, "pcb", "export", "step",
        "--subst-models",
        "--force",
        "-o", str(step_out),
        str(pcb_file),
    ], PCB_DIR, allow_codes=(0, 2))
    if not step_out.exists() or step_out.stat().st_size < 10_000:
        raise RuntimeError(f"STEP export did not produce a valid file: {step_out}")

    # 5. High-Quality Raytraced 3D Inspection PNGs
    renders = [
        (build_dir / "render_top.png", ["--side", "top", "--quality", "high", "-w", "1600", "-h", "1200"]),
        (build_dir / "render_bottom.png", ["--side", "bottom", "--quality", "high", "-w", "1600", "-h", "1200"]),
        (build_dir / "render_iso.png", ["--side", "top", "--perspective", "--rotate", "-45,0,45", "--quality", "high", "-w", "1600", "-h", "1200"]),
    ]
    for out_png, extra_args in renders:
        run_cmd([KICAD_CLI, "pcb", "render", *extra_args, "-o", str(out_png), str(pcb_file)], PCB_DIR)

    # 6. Run Turnkey JLCPCB Gate Verifier
    run_cmd([
        sys.executable, "-B", str(GATE_SCRIPT),
        "--erc", str(build_dir / "erc.json"),
        "--drc", str(build_dir / "drc.json"),
        "--bom", str(bom_csv),
        "--cpl", str(cpl_csv),
    ], PCB_DIR)

    return 0


if __name__ == "__main__":
    sys.exit(main())
