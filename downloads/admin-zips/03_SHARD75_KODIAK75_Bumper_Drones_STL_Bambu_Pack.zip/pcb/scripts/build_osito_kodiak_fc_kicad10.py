#!/usr/bin/env python3
"""End-to-end KiCad 10 repository builder & Gauss-Seidel PathFinder 4-Layer Router
for OSITO_KODIAK_FC_v1 (OSITO-KODIAK-G473 1S 12A 5-in-1 Brushless AIO).

Generates:
  1. OSITO_KODIAK_FC_v1.kicad_pro  (KiCad 10 JSON project + JLCPCB 4-layer rules)
  2. OSITO_KODIAK.kicad_sym + sym-lib-table + OSITO_KODIAK_FC_v1.kicad_sch (0 ERC violations)
  3. OSITO_KODIAK_FC_v1.kicad_pcb  (KiCad 10 4-layer routed PCB, 0 DRC / 0 unrouted / 0 parity)

Run with KiCad 10's bundled Python:
  & "C:\\Program Files\\KiCad\\10.0\\bin\\python.exe" -u -B scripts/build_osito_kodiak_fc_kicad10.py
"""

from __future__ import annotations

import heapq
import json
import math
import sys
import time
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

import pcbnew

SCRIPT_DIR = Path(__file__).resolve().parent
PCB_DIR = SCRIPT_DIR.parent
sys.path.insert(0, str(SCRIPT_DIR))

from kodiak_netlist_and_layout import (  # noqa: E402
    CompSpec,
    M2_EAR_RADIUS_MM,
    M2_HOLE_DIA_MM,
    M2_SPAN_HALF_MM,
    SQRT2,
    WAIST_HALF_MM,
    build_components,
    det_uuid,
    uv_to_xy,
    write_custom_footprints_and_3d,
    xy_to_uv,
)

PROJECT_NAME = "OSITO_KODIAK_FC_v1"
FP_SYS_DIR = Path(r"C:\Program Files\KiCad\10.0\share\kicad\footprints")
PRO_TEMPLATE = Path(r"C:\Program Files\KiCad\10.0\share\kicad\template\kicad.kicad_pro")


# =============================================================================
# 1. KiCad 10 Project File (.kicad_pro)
# =============================================================================

def write_kicad_pro(pcb_dir: Path) -> None:
    pro = json.loads(PRO_TEMPLATE.read_text(encoding="utf-8"))
    pro["meta"]["filename"] = f"{PROJECT_NAME}.kicad_pro"

    rules = pro["board"]["design_settings"]["rules"]
    rules.update({
        "min_clearance": 0.10,
        "min_track_width": 0.10,
        "min_via_diameter": 0.35,
        "min_via_annular_width": 0.10,
        "min_through_hole_diameter": 0.15,
        "min_copper_edge_clearance": 0.45,
        "min_hole_clearance": 0.20,
        "min_hole_to_hole": 0.25,
        "min_silk_clearance": 0.10,
        "min_text_height": 0.50,
        "min_text_thickness": 0.08,
    })

    defaults = pro["board"]["design_settings"]["defaults"]
    defaults["board_outline_line_width"] = 0.10

    pro["net_settings"]["classes"] = [
        {
            "bus_width": 12,
            "clearance": 0.10,
            "diff_pair_gap": 0.15,
            "diff_pair_via_gap": 0.25,
            "diff_pair_width": 0.15,
            "line_style": 0,
            "microvia_diameter": 0.30,
            "microvia_drill": 0.10,
            "name": "Default",
            "pcb_color": "rgba(0, 0, 0, 0.000)",
            "priority": 2147483647,
            "schematic_color": "rgba(0, 0, 0, 0.000)",
            "track_width": 0.11,
            "via_diameter": 0.35,
            "via_drill": 0.15,
            "wire_width": 6,
        },
        {
            "bus_width": 12,
            "clearance": 0.10,
            "diff_pair_gap": 0.20,
            "diff_pair_via_gap": 0.25,
            "diff_pair_width": 0.20,
            "line_style": 0,
            "microvia_diameter": 0.30,
            "microvia_drill": 0.10,
            "name": "Power",
            "pcb_color": "rgba(0, 0, 0, 0.000)",
            "priority": 1,
            "schematic_color": "rgba(0, 0, 0, 0.000)",
            "track_width": 0.18,
            "via_diameter": 0.35,
            "via_drill": 0.15,
            "wire_width": 10,
        },
    ]

    (pcb_dir / f"{PROJECT_NAME}.kicad_pro").write_text(
        json.dumps(pro, indent=2) + "\n", encoding="utf-8"
    )


# =============================================================================
# 2. KiCad 10 Symbol Library + Schematic File (.kicad_sch, version 20260306)
# =============================================================================

def _pin_sort_key(pnum: str) -> tuple[int, int | str]:
    return (0, int(pnum)) if pnum.isdigit() else (1, pnum)


def write_kicad_sch(pcb_dir: Path, comps: list[CompSpec]) -> dict[str, str]:
    root_uuid = det_uuid("SCH_ROOT")
    sym_uuids: dict[str, str] = {}

    lib_sym_blocks: list[str] = []
    standalone_lib_blocks: list[str] = []
    inst_blocks: list[str] = []
    wire_blocks: list[str] = []
    label_blocks: list[str] = []
    nc_blocks: list[str] = []

    GRID = 2.54

    def snap(val: float) -> float:
        return round(round(val / GRID) * GRID, 2)

    col_x = 60.96
    cur_y = 50.80
    MAX_Y = 780.0

    for c in comps:
        sym_name = f"SYM_{c.ref}"
        full_lib_id = f"OSITO_KODIAK:{sym_name}"
        pins_sorted = sorted(c.pins.keys(), key=_pin_sort_key)
        n_pins = len(pins_sorted)
        n_left = (n_pins + 1) // 2
        n_right = n_pins - n_left
        rows = max(n_left, n_right, 1)

        half_w = 10.16
        pin_len = 2.54
        top_ext = snap(((rows - 1) / 2.0) * GRID)
        box_half_h = top_ext + 2.54

        needed_h = 2.0 * box_half_h + 15.24
        if cur_y + needed_h > MAX_Y:
            col_x = snap(col_x + 76.20)
            cur_y = 50.80

        cx = snap(col_x)
        cy = snap(cur_y + box_half_h + 5.08)
        cur_y = snap(cy + box_half_h + 10.16)

        pin_defs: list[str] = []
        pin_world_pts: list[tuple[str, str, float, float, str]] = []

        for idx, pnum in enumerate(pins_sorted):
            net = c.pins[pnum]
            pname = net if net else "NC"
            if idx < n_left:
                sy = round(top_ext - idx * GRID, 2)
                sx = round(-(half_w + pin_len), 2)
                p_angle = 0
                side = "L"
            else:
                r_idx = idx - n_left
                sy = round(top_ext - r_idx * GRID, 2)
                sx = round(half_w + pin_len, 2)
                p_angle = 180
                side = "R"

            pin_defs.append(
                f'        (pin passive line (at {sx:.2f} {sy:.2f} {p_angle}) (length {pin_len:.2f})\n'
                f'          (name "{pname}" (effects (font (size 1.0 1.0))))\n'
                f'          (number "{pnum}" (effects (font (size 1.0 1.0))))\n'
                f'        )'
            )
            wx = round(cx + sx, 2)
            wy = round(cy - sy, 2)
            pin_world_pts.append((pnum, net, wx, wy, side))

        body_inner = (
            f'      (pin_names (offset 0.8))\n'
            f'      (exclude_from_sim no)\n'
            f'      (in_bom yes)\n'
            f'      (on_board yes)\n'
            f'      (in_pos_files yes)\n'
            f'      (duplicate_pin_numbers_are_jumpers no)\n'
            f'      (property "Reference" "{c.ref[0]}" (at 0 {box_half_h + 1.27:.2f} 0) (effects (font (size 1.27 1.27))))\n'
            f'      (property "Value" "{c.value}" (at 0 {-box_half_h - 1.27:.2f} 0) (effects (font (size 1.27 1.27))))\n'
            f'      (property "Footprint" "{c.full_fp}" (at 0 0 0) (effects (font (size 1.27 1.27)) (hide yes)))\n'
            f'      (property "Datasheet" "~" (at 0 0 0) (effects (font (size 1.27 1.27)) (hide yes)))\n'
            f'      (symbol "{sym_name}_0_1"\n'
            f'        (rectangle (start {-half_w:.2f} {box_half_h:.2f}) (end {half_w:.2f} {-box_half_h:.2f})\n'
            f'          (stroke (width 0.254) (type default))\n'
            f'          (fill (type background))\n'
            f'        )\n'
            f'      )\n'
            f'      (symbol "{sym_name}_1_1"\n'
            + "\n".join(pin_defs) + "\n"
            f'      )\n'
        )
        lib_sym_blocks.append(f'    (symbol "{full_lib_id}"\n{body_inner}    )')
        standalone_lib_blocks.append(f'  (symbol "{sym_name}"\n{body_inner}  )')

        inst_uuid = det_uuid(f"SYM_INST_{c.ref}")
        sym_uuids[c.ref] = inst_uuid

        pin_uuid_lines = "\n".join(
            f'    (pin "{pnum}" (uuid "{det_uuid(f"PIN_{c.ref}_{pnum}")}"))'
            for pnum in pins_sorted
        )

        inst_blocks.append(
            f'  (symbol\n'
            f'    (lib_id "{full_lib_id}")\n'
            f'    (at {cx:.2f} {cy:.2f} 0)\n'
            f'    (unit 1)\n'
            f'    (exclude_from_sim no)\n'
            f'    (in_bom yes)\n'
            f'    (on_board yes)\n'
            f'    (dnp no)\n'
            f'    (uuid "{inst_uuid}")\n'
            f'    (property "Reference" "{c.ref}" (at {cx:.2f} {cy - box_half_h - 1.5:.2f} 0)\n'
            f'      (effects (font (size 1.27 1.27)))\n'
            f'    )\n'
            f'    (property "Value" "{c.value}" (at {cx:.2f} {cy + box_half_h + 1.5:.2f} 0)\n'
            f'      (effects (font (size 1.1 1.1)))\n'
            f'    )\n'
            f'    (property "Footprint" "{c.full_fp}" (at {cx:.2f} {cy:.2f} 0)\n'
            f'      (effects (font (size 1.0 1.0)) (hide yes))\n'
            f'    )\n'
            f'    (property "Datasheet" "~" (at {cx:.2f} {cy:.2f} 0)\n'
            f'      (effects (font (size 1.0 1.0)) (hide yes))\n'
            f'    )\n'
            f'    (property "LCSC" "{c.lcsc}" (at {cx:.2f} {cy:.2f} 0)\n'
            f'      (effects (font (size 1.0 1.0)) (hide yes))\n'
            f'    )\n'
            f'    (property "Description" "{c.desc}" (at {cx:.2f} {cy:.2f} 0)\n'
            f'      (effects (font (size 1.0 1.0)) (hide yes))\n'
            f'    )\n'
            f'    (property "Subsystem" "{c.subsystem}" (at {cx:.2f} {cy:.2f} 0)\n'
            f'      (effects (font (size 1.0 1.0)) (hide yes))\n'
            f'    )\n'
            f'{pin_uuid_lines}\n'
            f'    (instances\n'
            f'      (project "{PROJECT_NAME}"\n'
            f'        (path "/{root_uuid}"\n'
            f'          (reference "{c.ref}")\n'
            f'          (unit 1)\n'
            f'        )\n'
            f'      )\n'
            f'    )\n'
            f'  )'
        )

        for pnum, net, wx, wy, side in pin_world_pts:
            if not net:
                nc_blocks.append(
                    f'  (no_connect (at {wx:.2f} {wy:.2f}) (uuid "{det_uuid(f"NC_{c.ref}_{pnum}")}"))'
                )
            else:
                ex = round(wx - 5.08, 2) if side == "L" else round(wx + 5.08, 2)
                lbl_ang = 180 if side == "L" else 0
                just = "right" if side == "L" else "left"
                wire_blocks.append(
                    f'  (wire (pts (xy {wx:.2f} {wy:.2f}) (xy {ex:.2f} {wy:.2f}))\n'
                    f'    (stroke (width 0) (type default))\n'
                    f'    (uuid "{det_uuid(f"WIRE_{c.ref}_{pnum}")}")\n'
                    f'  )'
                )
                label_blocks.append(
                    f'  (global_label "{net}"\n'
                    f'    (shape bidirectional)\n'
                    f'    (at {ex:.2f} {wy:.2f} {lbl_ang})\n'
                    f'    (effects (font (size 1.0 1.0)) (justify {just}))\n'
                    f'    (uuid "{det_uuid(f"GLBL_{c.ref}_{pnum}")}")\n'
                    f'    (property "Intersheetrefs" "${{INTERSHEET_REFS}}" (at {ex:.2f} {wy:.2f} 0)\n'
                    f'      (effects (font (size 1.0 1.0)) (hide yes))\n'
                    f'    )\n'
                    f'  )'
                )

    (pcb_dir / "sym-lib-table").write_text(
        '(sym_lib_table\n'
        '  (version 7)\n'
        '  (lib (name "OSITO_KODIAK")(type "KiCad")(uri "${KIPRJMOD}/OSITO_KODIAK.kicad_sym")(options "")(descr "Osito Kodiak Schematic Symbols"))\n'
        ')\n',
        encoding="utf-8",
    )
    (pcb_dir / "OSITO_KODIAK.kicad_sym").write_text(
        '(kicad_symbol_lib\n'
        '  (version 20251024)\n'
        '  (generator "kicad_symbol_editor")\n'
        '  (generator_version "10.0")\n'
        + "\n".join(standalone_lib_blocks) + "\n"
        ')\n',
        encoding="utf-8",
    )

    sch_text = (
        f'(kicad_sch\n'
        f'  (version 20260306)\n'
        f'  (generator "eeschema")\n'
        f'  (generator_version "10.0")\n'
        f'  (uuid "{root_uuid}")\n'
        f'  (paper "A0")\n'
        f'  (title_block\n'
        f'    (title "OSITO-KODIAK-G473 (1S 12A 5-in-1 Brushless Flight Controller)")\n'
        f'    (date "2026-11-11")\n'
        f'    (rev "1.0")\n'
        f'    (company "Osito Drone LLC")\n'
        f'    (comment 1 "Target: BETAFPVG473 + Bluejay O-H-5 48kHz + Integrated ELRS 2.4GHz + AT7456E OSD")\n'
        f'    (comment 2 "Fits CUB-75 Trainer & KODIAK-75 / SHARD-75 Combat Drone")\n'
        f'  )\n'
        f'  (lib_symbols\n'
        + "\n".join(lib_sym_blocks) + "\n"
        f'  )\n'
        + "\n".join(nc_blocks) + "\n"
        + "\n".join(wire_blocks) + "\n"
        + "\n".join(label_blocks) + "\n"
        + "\n".join(inst_blocks) + "\n"
        f'  (sheet_instances\n'
        f'    (path "/"\n'
        f'      (page "1")\n'
        f'    )\n'
        f'  )\n'
        f')\n'
    )
    (pcb_dir / f"{PROJECT_NAME}.kicad_sch").write_text(sch_text, encoding="utf-8")
    return sym_uuids


# =============================================================================
# 3. Static Pad Geometry + Ultra-Fast O(1) Gauss-Seidel PathFinder Router
# =============================================================================

def pt_seg_dist2(px: float, py: float, ax: float, ay: float, bx: float, by: float) -> float:
    dx, dy = bx - ax, by - ay
    l2 = dx * dx + dy * dy
    if l2 <= 1e-12:
        return (px - ax) ** 2 + (py - ay) ** 2
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / l2))
    qx, qy = ax + t * dx, ay + t * dy
    return (px - qx) ** 2 + (py - qy) ** 2


def _orient(ax: float, ay: float, bx: float, by: float, cx: float, cy: float) -> float:
    return (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)


def _segs_intersect(ax: float, ay: float, bx: float, by: float, cx: float, cy: float, dx: float, dy: float) -> bool:
    o1 = _orient(ax, ay, bx, by, cx, cy)
    o2 = _orient(ax, ay, bx, by, dx, dy)
    o3 = _orient(cx, cy, dx, dy, ax, ay)
    o4 = _orient(cx, cy, dx, dy, bx, by)
    return (o1 * o2 < 0.0) and (o3 * o4 < 0.0)


def seg_seg_dist(ax: float, ay: float, bx: float, by: float, cx: float, cy: float, dx: float, dy: float) -> float:
    if _segs_intersect(ax, ay, bx, by, cx, cy, dx, dy):
        return 0.0
    return math.sqrt(min(
        pt_seg_dist2(ax, ay, cx, cy, dx, dy),
        pt_seg_dist2(bx, by, cx, cy, dx, dy),
        pt_seg_dist2(cx, cy, ax, ay, bx, by),
        pt_seg_dist2(dx, dy, ax, ay, bx, by),
    ))


def pt_rect_dist(px: float, py: float, x0: float, y0: float, x1: float, y1: float) -> float:
    dx = max(x0 - px, 0.0, px - x1)
    dy = max(y0 - py, 0.0, py - y1)
    return math.hypot(dx, dy)


def seg_rect_dist(ax: float, ay: float, bx: float, by: float, x0: float, y0: float, x1: float, y1: float) -> float:
    if (x0 <= ax <= x1 and y0 <= ay <= y1) or (x0 <= bx <= x1 and y0 <= by <= y1):
        return 0.0
    return min(
        seg_seg_dist(ax, ay, bx, by, x0, y0, x1, y0),
        seg_seg_dist(ax, ay, bx, by, x1, y0, x1, y1),
        seg_seg_dist(ax, ay, bx, by, x1, y1, x0, y1),
        seg_seg_dist(ax, ay, bx, by, x0, y1, x0, y0),
    )


class StaticBoard:
    """Immutable static obstacles (SMD pads, EPs, M2 cutouts, Edge.Cuts, ANT1 keepout,
    EP center thermal vias, and <=0.70mm adjacent intra-IC bridges) with memoization."""

    CLR = 0.115
    VIA_R = 0.175
    M2_UV = [
        (-M2_SPAN_HALF_MM, -M2_SPAN_HALF_MM),
        (M2_SPAN_HALF_MM, -M2_SPAN_HALF_MM),
        (M2_SPAN_HALF_MM, M2_SPAN_HALF_MM),
        (-M2_SPAN_HALF_MM, M2_SPAN_HALF_MM),
    ]
    ANT_KO = (-14.30, 6.95, -11.30, 8.05)

    def __init__(self) -> None:
        self.pad_grid: dict[tuple[int, int, int], list[tuple[float, float, float, float, str, bool]]] = defaultdict(list)
        self.fixed_segs: dict[tuple[int, int, int], list[tuple[float, float, float, float, float, str]]] = defaultdict(list)
        self.fixed_vias: list[tuple[float, float, float, str]] = []
        self._seg_cache: dict[tuple, bool] = {}
        self._via_cache: dict[tuple, bool] = {}

    @staticmethod
    def _cells(u0: float, v0: float, u1: float, v1: float, margin: float = 0.55):
        ix0, ix1 = int(math.floor((u0 - margin) / 2.0)), int(math.floor((u1 + margin) / 2.0))
        iy0, iy1 = int(math.floor((v0 - margin) / 2.0)), int(math.floor((v1 + margin) / 2.0))
        for ix in range(ix0, ix1 + 1):
            for iy in range(iy0, iy1 + 1):
                yield ix, iy

    def add_pad(self, lyr: int, u0: float, v0: float, u1: float, v1: float, net: str, is_ep: bool) -> None:
        item = (u0, v0, u1, v1, net, is_ep)
        for ix, iy in self._cells(u0, v0, u1, v1):
            self.pad_grid[(lyr, ix, iy)].append(item)
        self._seg_cache.clear()
        self._via_cache.clear()

    def add_fixed_seg(self, lyr: int, u0: float, v0: float, u1: float, v1: float, hw: float, net: str) -> None:
        item = (u0, v0, u1, v1, hw, net)
        bu0, bu1 = min(u0, u1), max(u0, u1)
        bv0, bv1 = min(v0, v1), max(v0, v1)
        for ix, iy in self._cells(bu0, bv0, bu1, bv1, hw + 0.45):
            self.fixed_segs[(lyr, ix, iy)].append(item)
        self._seg_cache.clear()
        self._via_cache.clear()

    def add_fixed_via(self, u: float, v: float, net: str, r_cu: float = 0.175) -> None:
        self.fixed_vias.append((u, v, r_cu, net))
        self._seg_cache.clear()
        self._via_cache.clear()

    def in_bounds_pt(self, u: float, v: float, r_cu: float, allow_ant: bool = False) -> bool:
        if abs(u) + r_cu > WAIST_HALF_MM - 0.52 or abs(v) + r_cu > WAIST_HALF_MM - 0.52:
            return False
        for mu, mv in self.M2_UV:
            if math.hypot(u - mu, v - mv) < (M2_HOLE_DIA_MM * 0.5 + 0.52 + r_cu):
                return False
        if not allow_ant:
            ku0, kv0, ku1, kv1 = self.ANT_KO
            if pt_rect_dist(u, v, ku0, kv0, ku1, kv1) < r_cu + 0.05:
                return False
        return True

    def can_place_via(self, u: float, v: float, net: str, allow_in_same_ep: bool = False) -> bool:
        key = (round(u * 400), round(v * 400), net, allow_in_same_ep)
        cached = self._via_cache.get(key)
        if cached is not None:
            return cached

        r = self.VIA_R
        if not self.in_bounds_pt(u, v, r):
            self._via_cache[key] = False
            return False

        for vu, vv, vr, vnet in self.fixed_vias:
            d = math.hypot(u - vu, v - vv)
            if vnet == net:
                if 1e-4 < d < 0.48:
                    self._via_cache[key] = False
                    return False
            else:
                if d < r + vr + self.CLR:
                    self._via_cache[key] = False
                    return False

        for lyr in (0, 3):
            seen = set()
            for ix, iy in self._cells(u, v, u, v, r + 0.25):
                for item in self.pad_grid.get((lyr, ix, iy), ()):
                    if id(item) in seen:
                        continue
                    seen.add(id(item))
                    pu0, pv0, pu1, pv1, pnet, pis_ep = item
                    if u < pu0 - r - 0.25 or u > pu1 + r + 0.25 or v < pv0 - r - 0.25 or v > pv1 + r + 0.25:
                        continue
                    d = pt_rect_dist(u, v, pu0, pv0, pu1, pv1)
                    if pnet == net:
                        if not (allow_in_same_ep and pis_ep) and d < 0.05:
                            self._via_cache[key] = False
                            return False
                    else:
                        if d < r + self.CLR:
                            self._via_cache[key] = False
                            return False

        for lyr in (0, 1, 2, 3):
            seen_s = set()
            for ix, iy in self._cells(u, v, u, v, r + 0.25):
                for item in self.fixed_segs.get((lyr, ix, iy), ()):
                    if id(item) in seen_s:
                        continue
                    seen_s.add(id(item))
                    su0, sv0, su1, sv1, shw, snet = item
                    if snet == net:
                        continue
                    if math.sqrt(pt_seg_dist2(u, v, su0, sv0, su1, sv1)) < r + shw + self.CLR:
                        self._via_cache[key] = False
                        return False

        self._via_cache[key] = True
        return True

    def can_place_seg(self, lyr: int, u0: float, v0: float, u1: float, v1: float, hw: float, net: str) -> bool:
        if lyr == 1:
            # Keep solid unbroken In1.Cu GND reference directly under 2.4GHz ELRS RF feedline (U7.11 -> C_RF -> ANT1)
            if min(u0, u1) < -7.75 and 5.50 < max(v0, v1) and min(v0, v1) < 7.60:
                return False

        key = (lyr, round(u0 * 400), round(v0 * 400), round(u1 * 400), round(v1 * 400), round(hw * 400), net)
        cached = self._seg_cache.get(key)
        if cached is not None:
            return cached

        allow_ant = net in ("ELRS_ANT_FEED", "ELRS_RFIO")
        if not self.in_bounds_pt(u0, v0, hw, allow_ant) or not self.in_bounds_pt(u1, v1, hw, allow_ant):
            self._seg_cache[key] = False
            return False
        for mu, mv in self.M2_UV:
            if math.sqrt(pt_seg_dist2(mu, mv, u0, v0, u1, v1)) < (M2_HOLE_DIA_MM * 0.5 + 0.52 + hw):
                self._seg_cache[key] = False
                return False
        if not allow_ant:
            ku0, kv0, ku1, kv1 = self.ANT_KO
            if seg_rect_dist(u0, v0, u1, v1, ku0, kv0, ku1, kv1) < hw + 0.05:
                self._seg_cache[key] = False
                return False

        bu0, bu1 = min(u0, u1), max(u0, u1)
        bv0, bv1 = min(v0, v1), max(v0, v1)
        req_pad = hw + self.CLR

        seen_p = set()
        for ix, iy in self._cells(bu0, bv0, bu1, bv1, req_pad + 0.1):
            for item in self.pad_grid.get((lyr, ix, iy), ()):
                if id(item) in seen_p:
                    continue
                seen_p.add(id(item))
                pu0, pv0, pu1, pv1, pnet, _ = item
                if pnet == net:
                    continue
                if bu1 + req_pad < pu0 or bu0 - req_pad > pu1 or bv1 + req_pad < pv0 or bv0 - req_pad > pv1:
                    continue
                if seg_rect_dist(u0, v0, u1, v1, pu0, pv0, pu1, pv1) < req_pad:
                    self._seg_cache[key] = False
                    return False

        for vu, vv, vr, vnet in self.fixed_vias:
            if vnet == net:
                continue
            if vu < bu0 - 0.6 or vu > bu1 + 0.6 or vv < bv0 - 0.6 or vv > bv1 + 0.6:
                continue
            if math.sqrt(pt_seg_dist2(vu, vv, u0, v0, u1, v1)) < hw + vr + self.CLR:
                self._seg_cache[key] = False
                return False

        seen_s = set()
        for ix, iy in self._cells(bu0, bv0, bu1, bv1, hw + 0.35):
            for item in self.fixed_segs.get((lyr, ix, iy), ()):
                if id(item) in seen_s:
                    continue
                seen_s.add(id(item))
                su0, sv0, su1, sv1, shw, snet = item
                if snet == net:
                    continue
                if seg_seg_dist(u0, v0, u1, v1, su0, sv0, su1, sv1) < hw + shw + self.CLR:
                    self._seg_cache[key] = False
                    return False

        self._seg_cache[key] = True
        return True


# Precomputed relative offsets for 0.35/0.15mm via 5-cell track halo & 3x3 via-to-via halo
# At (+/-1, +/-1) = 0.3536 mm: Cu-Cu = 0.3536 - 0.175 - 0.055 = 0.1236 mm >= 0.10 mm,
# and Drill-Cu = 0.3536 - 0.075 - 0.055 = 0.2236 mm >= 0.20 mm!
VIA_PLUS = [(0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)]
VIA_EXCL = [(dx, dy) for dx in (-1, 0, 1) for dy in (-1, 0, 1)]


class GridOccupancy:
    """Exact O(1) discrete cell & via halo tracker for Gauss-Seidel PathFinder."""

    def __init__(self) -> None:
        self.cell_nets: dict[tuple[int, int, int], dict[str, int]] = defaultdict(dict)
        self.cell_tids: dict[tuple[int, int, int], set[int]] = defaultdict(set)

        self.via_sites: dict[tuple[int, int], dict[str, int]] = defaultdict(dict)
        self.via_site_tids: dict[tuple[int, int], set[int]] = defaultdict(set)

        self.stub_via_block: dict[tuple[int, int], dict[str, int]] = defaultdict(dict)
        self.stub_via_tids: dict[tuple[int, int], set[int]] = defaultdict(set)

        self.hist_cell: dict[tuple[int, int, int], float] = defaultdict(float)
        self.hist_via: dict[tuple[int, int], float] = defaultdict(float)

        self.task_cells: dict[int, tuple[str, set[tuple[int, int, int]], set[tuple[int, int]], set[tuple[int, int]]]] = {}
        self.task_geom: dict[int, tuple[list[tuple[int, float, float, float, float]], list[tuple[int, int]]]] = {}
        self.undo_log: list[tuple] | None = None

    def enable_undo(self) -> None:
        self.undo_log = []

    def checkpoint(self) -> int:
        return len(self.undo_log) if self.undo_log is not None else 0

    def rollback(self, mark: int) -> None:
        if self.undo_log is None:
            return
        log = self.undo_log
        self.undo_log = None
        try:
            while len(log) > mark:
                op = log.pop()
                if op[0] == "RIP":
                    self.rip_up(op[1])
                else:
                    _, tid, net, ac, vs, sv, sg = op
                    self.commit(tid, net, ac, vs, sv, sg)
        finally:
            self.undo_log = log

    def _inc_net(self, d: dict[str, int], net: str) -> None:
        d[net] = d.get(net, 0) + 1

    def _dec_net(self, d: dict[str, int], net: str) -> None:
        v = d.get(net, 0) - 1
        if v <= 0:
            d.pop(net, None)
        else:
            d[net] = v

    def commit(
        self,
        tid: int,
        net: str,
        claimed_cells: set[tuple[int, int, int]],
        placed_vias: list[tuple[int, int]],
        stub_vblock: set[tuple[int, int]],
        segs: list[tuple[int, float, float, float, float]],
    ) -> None:
        if tid >= 0 and tid in self.task_cells:
            self.rip_up(tid)
        if self.undo_log is not None and tid >= 0:
            self.undo_log.append(("RIP", tid))
        all_cells = set(claimed_cells)
        via_set = set(placed_vias)
        for iu, iv in via_set:
            for lyr in (0, 1, 2, 3):
                for dx, dy in VIA_PLUS:
                    all_cells.add((lyr, iu + dx, iv + dy))
            self._inc_net(self.via_sites[(iu, iv)], net)
            if tid >= 0:
                self.via_site_tids[(iu, iv)].add(tid)

        for c in all_cells:
            self._inc_net(self.cell_nets[c], net)
            if tid >= 0:
                self.cell_tids[c].add(tid)

        for vb in stub_vblock:
            self._inc_net(self.stub_via_block[vb], net)
            if tid >= 0:
                self.stub_via_tids[vb].add(tid)

        if tid >= 0:
            self.task_cells[tid] = (net, all_cells, via_set, set(stub_vblock))
            self.task_geom[tid] = (segs, list(via_set))

    def rip_up(self, tid: int) -> None:
        rec = self.task_cells.pop(tid, None)
        geom = self.task_geom.pop(tid, None)
        if rec is None:
            return
        net, all_cells, via_set, stub_vblock = rec
        if self.undo_log is not None and tid >= 0 and geom is not None:
            self.undo_log.append(("RESTORE", tid, net, set(all_cells), list(via_set), set(stub_vblock), list(geom[0])))
        for c in all_cells:
            self._dec_net(self.cell_nets[c], net)
            s = self.cell_tids.get(c)
            if s:
                s.discard(tid)
        for iu, iv in via_set:
            self._dec_net(self.via_sites[(iu, iv)], net)
            s = self.via_site_tids.get((iu, iv))
            if s:
                s.discard(tid)
        for vb in stub_vblock:
            self._dec_net(self.stub_via_block[vb], net)
            s = self.stub_via_tids.get(vb)
            if s:
                s.discard(tid)

    def has_cell_conflict(self, c: tuple[int, int, int], net: str) -> bool:
        cn = self.cell_nets.get(c)
        return bool(cn and (len(cn) > 1 or net not in cn))

    def cell_step_penalty(self, c: tuple[int, int, int], net: str, pres_fac: float) -> float:
        cn = self.cell_nets.get(c)
        foreign = (len(cn) - (1 if net in cn else 0)) if cn else 0
        h = self.hist_cell.get(c, 0.0)
        if foreign == 0:
            return h
        return h + (0.35 + h) * foreign * pres_fac

    def has_via_conflict(self, iu: int, iv: int, net: str) -> bool:
        for lyr in (0, 1, 2, 3):
            for dx, dy in VIA_PLUS:
                if self.has_cell_conflict((lyr, iu + dx, iv + dy), net):
                    return True
        vb = self.stub_via_block.get((iu, iv))
        if vb and (len(vb) > 1 or net not in vb):
            return True
        for dx, dy in VIA_EXCL:
            vs = self.via_sites.get((iu + dx, iv + dy))
            if not vs:
                continue
            if dx == 0 and dy == 0:
                if len(vs) > 1 or net not in vs:
                    return True
            else:
                return True
        return False

    def via_step_penalty(self, iu: int, iv: int, net: str, pres_fac: float) -> float:
        cell_pen = 0.0
        for lyr in (0, 1, 2, 3):
            for dx, dy in VIA_PLUS:
                c = (lyr, iu + dx, iv + dy)
                hc = self.hist_cell.get(c, 0.0)
                if hc > 0.0:
                    cell_pen += 0.30 * hc
                cn = self.cell_nets.get(c)
                if cn:
                    foreign = len(cn) - (1 if net in cn else 0)
                    if foreign > 0:
                        cell_pen += (0.35 + hc) * foreign * pres_fac

        bad_v: set[str] = set()
        vb = self.stub_via_block.get((iu, iv))
        if vb:
            for k in vb:
                if k != net:
                    bad_v.add(k)

        same_net_drill_clash = 0
        for dx, dy in VIA_EXCL:
            vs = self.via_sites.get((iu + dx, iv + dy))
            if not vs:
                continue
            if dx == 0 and dy == 0:
                for k in vs:
                    if k != net:
                        bad_v.add(k)
            else:
                for k in vs:
                    if k != net:
                        bad_v.add(k)
                    else:
                        same_net_drill_clash = 1

        v_conflicts = len(bad_v) + same_net_drill_clash
        hv = self.hist_via.get((iu, iv), 0.0)
        return cell_pen + hv + ((0.60 + hv) * v_conflicts * pres_fac if v_conflicts else 0.0)

    def find_conflicts_and_bump_history(self, hist_inc: float = 0.5) -> set[int]:
        bad: set[int] = set()

        for c, cn in self.cell_nets.items():
            if len(cn) > 1:
                bad.update(self.cell_tids[c])
                self.hist_cell[c] += (hist_inc * 0.25) if c[0] >= 10 else hist_inc

        active_vias = [k for k, v in self.via_sites.items() if v]
        for iu, iv in active_vias:
            vs = self.via_sites[(iu, iv)]
            for lyr in (0, 1, 2, 3):
                for dx, dy in VIA_PLUS:
                    if len(self.cell_nets.get((lyr, iu + dx, iv + dy), ())) > 1:
                        self.hist_via[(iu, iv)] += hist_inc * 0.5
                        break
            vb = self.stub_via_block.get((iu, iv))
            if vb:
                for vnet in vs:
                    if any(snet != vnet for snet in vb):
                        bad.update(self.via_site_tids[(iu, iv)])
                        bad.update(self.stub_via_tids[(iu, iv)])
                        self.hist_via[(iu, iv)] += hist_inc

            for dx, dy in VIA_EXCL:
                if (dx, dy) <= (0, 0):
                    if dx == 0 and dy == 0 and len(vs) > 1:
                        bad.update(self.via_site_tids[(iu, iv)])
                        self.hist_via[(iu, iv)] += hist_inc
                    continue
                vs2 = self.via_sites.get((iu + dx, iv + dy))
                if vs2:
                    bad.update(self.via_site_tids[(iu, iv)])
                    bad.update(self.via_site_tids[(iu + dx, iv + dy)])
                    self.hist_via[(iu, iv)] += hist_inc
                    self.hist_via[(iu + dx, iv + dy)] += hist_inc

        return bad


@dataclass
class EscapeInfo:
    node: tuple[int, int, int]
    wpts: list[tuple[float, float]]
    cells: list[tuple[int, int, int]]
    vblock: list[tuple[int, int]]


@dataclass
class ConnectionTask:
    tid: int
    kind: str  # "NET_EDGE" or "GND_VIA"
    net: str
    src_escapes: list[EscapeInfo]
    dst_escapes: list[EscapeInfo]


# =============================================================================
# 4. Programmatic PCB Construction & Complete Routing via pcbnew
# =============================================================================

def vec_mm(x: float, y: float) -> pcbnew.VECTOR2I:
    return pcbnew.VECTOR2I(pcbnew.FromMM(x), pcbnew.FromMM(y))


def add_board_outline_and_cutouts(board: pcbnew.BOARD) -> None:
    du = WAIST_HALF_MM - M2_SPAN_HALF_MM
    dv_cut = math.sqrt(M2_EAR_RADIUS_MM ** 2 - du ** 2)
    t_waist = M2_SPAN_HALF_MM - dv_cut

    W = WAIST_HALF_MM
    lines_uv = [
        ((-t_waist, -W), (t_waist, -W)),
        ((W, -t_waist), (W, t_waist)),
        ((t_waist, W), (-t_waist, W)),
        ((-W, t_waist), (-W, -t_waist)),
    ]
    for (u0, v0), (u1, v1) in lines_uv:
        s = pcbnew.PCB_SHAPE(board)
        s.SetShape(pcbnew.SHAPE_T_SEGMENT)
        s.SetLayer(pcbnew.Edge_Cuts)
        s.SetWidth(pcbnew.FromMM(0.10))
        s.SetStart(vec_mm(*uv_to_xy(u0, v0)))
        s.SetEnd(vec_mm(*uv_to_xy(u1, v1)))
        board.Add(s)

    ears = [
        ((t_waist, -W), (M2_SPAN_HALF_MM + M2_EAR_RADIUS_MM / SQRT2, -M2_SPAN_HALF_MM - M2_EAR_RADIUS_MM / SQRT2), (W, -t_waist)),
        ((W, t_waist), (M2_SPAN_HALF_MM + M2_EAR_RADIUS_MM / SQRT2, M2_SPAN_HALF_MM + M2_EAR_RADIUS_MM / SQRT2), (t_waist, W)),
        ((-t_waist, W), (-M2_SPAN_HALF_MM - M2_EAR_RADIUS_MM / SQRT2, M2_SPAN_HALF_MM + M2_EAR_RADIUS_MM / SQRT2), (-W, t_waist)),
        ((-W, -t_waist), (-M2_SPAN_HALF_MM - M2_EAR_RADIUS_MM / SQRT2, -M2_SPAN_HALF_MM - M2_EAR_RADIUS_MM / SQRT2), (-t_waist, -W)),
    ]
    for p_start, p_mid, p_end in ears:
        arc = pcbnew.PCB_SHAPE(board)
        arc.SetShape(pcbnew.SHAPE_T_ARC)
        arc.SetLayer(pcbnew.Edge_Cuts)
        arc.SetWidth(pcbnew.FromMM(0.10))
        arc.SetArcGeometry(
            vec_mm(*uv_to_xy(*p_start)),
            vec_mm(*uv_to_xy(*p_mid)),
            vec_mm(*uv_to_xy(*p_end)),
        )
        board.Add(arc)

    for mu, mv in StaticBoard.M2_UV:
        cx, cy = uv_to_xy(mu, mv)
        c_shape = pcbnew.PCB_SHAPE(board)
        c_shape.SetShape(pcbnew.SHAPE_T_CIRCLE)
        c_shape.SetLayer(pcbnew.Edge_Cuts)
        c_shape.SetWidth(pcbnew.FromMM(0.10))
        c_shape.SetCenter(vec_mm(cx, cy))
        c_shape.SetEnd(vec_mm(cx + M2_HOLE_DIA_MM * 0.5, cy))
        board.Add(c_shape)


def emit_track_uv(board: pcbnew.BOARD, lyr_pcb: int, u0: float, v0: float, u1: float, v1: float, width_mm: float, netinfo: pcbnew.NETINFO_ITEM) -> None:
    if math.hypot(u1 - u0, v1 - v0) < 1e-4:
        return
    t = pcbnew.PCB_TRACK(board)
    t.SetLayer(lyr_pcb)
    t.SetStart(vec_mm(*uv_to_xy(u0, v0)))
    t.SetEnd(vec_mm(*uv_to_xy(u1, v1)))
    t.SetWidth(pcbnew.FromMM(width_mm))
    t.SetNet(netinfo)
    board.Add(t)


def emit_via_uv(board: pcbnew.BOARD, u: float, v: float, netinfo: pcbnew.NETINFO_ITEM) -> None:
    via = pcbnew.PCB_VIA(board)
    via.SetPosition(vec_mm(*uv_to_xy(u, v)))
    via.SetWidth(pcbnew.FromMM(0.35))
    via.SetDrill(pcbnew.FromMM(0.15))
    via.SetLayerPair(pcbnew.F_Cu, pcbnew.B_Cu)
    via.SetNet(netinfo)
    board.Add(via)


def build_and_route_pcb(pcb_dir: Path, comps: list[CompSpec], sym_uuids: dict[str, str]) -> None:
    t0 = time.time()
    board = pcbnew.BOARD()
    board.SetCopperLayerCount(4)
    ds = board.GetDesignSettings()
    ds.SetBoardThickness(pcbnew.FromMM(1.0))

    all_nets: set[str] = set()
    for c in comps:
        for pnum, net in c.pins.items():
            if net:
                all_nets.add(net)
            else:
                all_nets.add(f"unconnected-({c.ref}-NC-Pad{pnum})")

    net_items: dict[str, pcbnew.NETINFO_ITEM] = {}
    for idx, nname in enumerate(sorted(all_nets), start=1):
        ni = pcbnew.NETINFO_ITEM(board, nname, idx)
        board.Add(ni)
        net_items[nname] = ni

    add_board_outline_and_cutouts(board)

    io = pcbnew.PCB_IO_KICAD_SEXPR()
    static = StaticBoard()
    LYR_MAP = {0: pcbnew.F_Cu, 1: pcbnew.In1_Cu, 2: pcbnew.In2_Cu, 3: pcbnew.B_Cu}

    net_pads: dict[str, list[tuple[int, float, float, bool, str, str]]] = defaultdict(list)

    for c in comps:
        lib_dir = (pcb_dir / "OSITO_KODIAK.pretty") if c.lib == "OSITO_KODIAK" else (FP_SYS_DIR / f"{c.lib}.pretty")
        fp = io.FootprintLoad(str(lib_dir), c.fp_name)
        board.Add(fp)

        x, y = c.xy
        fp.SetPosition(vec_mm(x, y))
        if c.side == "B":
            fp.Flip(vec_mm(x, y), False)
        fp.SetOrientationDegrees(c.rot_deg)

        fp.SetReference(c.ref)
        fp.SetValue(c.value)
        fp.SetFPIDAsString(c.full_fp)
        fp.SetPath(pcbnew.KIID_PATH(f"/{sym_uuids[c.ref]}"))
        fp.SetSheetfile(f"{PROJECT_NAME}.kicad_sch")
        fp.SetSheetname("/")

        for fname, fval in (("LCSC", c.lcsc), ("Description", c.desc), ("Subsystem", c.subsystem)):
            fp.SetField(fname, fval)
            fld = fp.GetField(fname)
            if fld is not None:
                fld.SetVisible(False)

        ref_field = fp.Reference()
        val_field = fp.Value()
        val_field.SetVisible(False)
        if c.ref.startswith(("U", "J_")):
            ref_field.SetVisible(True)
            ref_field.SetLayer(pcbnew.B_Fab if c.side == "B" else pcbnew.F_Fab)
            if c.side == "B":
                ref_field.SetMirrored(True)
            ref_field.SetTextSize(vec_mm(0.60, 0.60))
            ref_field.SetTextThickness(pcbnew.FromMM(0.10))
        else:
            ref_field.SetVisible(False)

        lyr_idx = 3 if c.side == "B" else 0
        pcb_cu_lyr = pcbnew.B_Cu if c.side == "B" else pcbnew.F_Cu

        for pad in fp.Pads():
            if not pad.IsOnLayer(pcb_cu_lyr):
                continue
            pnum = pad.GetNumber()
            raw_net = c.pins.get(pnum, "")
            eff_net = raw_net if raw_net else f"unconnected-({c.ref}-NC-Pad{pnum})"
            pad.SetNet(net_items[eff_net])

            px, py = pcbnew.ToMM(pad.GetPosition().x), pcbnew.ToMM(pad.GetPosition().y)
            pu, pv = xy_to_uv(px, py)

            eff = pad.GetEffectivePolygon(pcb_cu_lyr)
            verts_uv: list[tuple[float, float]] = []
            for oi in range(eff.OutlineCount()):
                ol = eff.Outline(oi)
                for pi in range(ol.PointCount()):
                    pt = ol.CPoint(pi)
                    verts_uv.append(xy_to_uv(pcbnew.ToMM(pt.x), pcbnew.ToMM(pt.y)))

            u0 = min(pt[0] for pt in verts_uv)
            u1 = max(pt[0] for pt in verts_uv)
            v0 = min(pt[1] for pt in verts_uv)
            v1 = max(pt[1] for pt in verts_uv)
            is_ep = min(u1 - u0, v1 - v0) >= 1.45

            static.add_pad(lyr_idx, u0, v0, u1, v1, eff_net, is_ep)
            if raw_net:
                net_pads[raw_net].append((lyr_idx, pu, pv, is_ep, c.ref, pnum))

    for txt_str, lyr, (tu, tv), sz, mirrored in [
        ("NOSE ^", pcbnew.F_SilkS, (1.5, -12.4), 0.50, False),
        ("OSITO KODIAK G473", pcbnew.F_Fab, (0.0, -0.5), 0.55, False),
        ("OSITO DRONE SF 1S-12A", pcbnew.B_Fab, (0.0, -1.2), 0.55, True),
    ]:
        tb = pcbnew.PCB_TEXT(board)
        tb.SetText(txt_str)
        tb.SetLayer(lyr)
        tb.SetPosition(vec_mm(*uv_to_xy(tu, tv)))
        tb.SetTextAngleDegrees(45.0)
        tb.SetMirrored(mirrored)
        tb.SetTextSize(vec_mm(sz, sz))
        tb.SetTextThickness(pcbnew.FromMM(0.09))
        board.Add(tb)

    # -------------------------------------------------------------------------
    # Step A: Bridge ONLY strictly adjacent same-IC sibling pads (<= 0.72 mm,
    #         same component ref!) so ZERO neighbor pin throats get crossed!
    # -------------------------------------------------------------------------
    STEP = 0.25
    G_MIN = -54
    G_MAX = 54
    W_TRK = 0.11
    HW_TRK = W_TRK * 0.5

    net_clusters: dict[str, list[list[tuple[int, float, float, bool]]]] = {}
    bridged_count = 0

    for net, plist in sorted(net_pads.items()):
        n = len(plist)
        parent_uf = list(range(n))

        def find_uf(x: int) -> int:
            while parent_uf[x] != x:
                parent_uf[x] = parent_uf[parent_uf[x]]
                x = parent_uf[x]
            return x

        pairs = []
        for i in range(n):
            l1, u1, v1, ie1, ref1, _ = plist[i]
            for j in range(i + 1, n):
                l2, u2, v2, ie2, ref2, _ = plist[j]
                if l1 == l2 and ref1 == ref2 and not ie1 and not ie2:
                    d = math.hypot(u2 - u1, v2 - v1)
                    if d <= 0.72:
                        pairs.append((d, i, j))
        pairs.sort()

        for _, i, j in pairs:
            ri, rj = find_uf(i), find_uf(j)
            if ri == rj:
                continue
            l1, u1, v1, _, _, _ = plist[i]
            _, u2, v2, _, _, _ = plist[j]
            if static.can_place_seg(l1, u1, v1, u2, v2, 0.08, net):
                emit_track_uv(board, LYR_MAP[l1], u1, v1, u2, v2, 0.16, net_items[net])
                static.add_fixed_seg(l1, u1, v1, u2, v2, 0.08, net)
                parent_uf[rj] = ri
                bridged_count += 1

        groups: dict[int, list[tuple[int, float, float, bool]]] = defaultdict(list)
        for i, (l, u, v, is_ep, _, _) in enumerate(plist):
            groups[find_uf(i)].append((l, u, v, is_ep))
        net_clusters[net] = list(groups.values())

    # Center thermal GND vias inside all 9 Exposed Pads (snapped to 0.25mm grid!)
    gnd_ni = net_items["GND"]
    ep_vias_placed = 0
    remaining_gnd_clusters: list[list[tuple[int, float, float, bool]]] = []
    static_gnd_via_grid: set[tuple[int, int]] = set()

    for clust in net_clusters.get("GND", []):
        ep_pads = [p for p in clust if p[3]]
        if not ep_pads:
            remaining_gnd_clusters.append(clust)
            continue
        l_ep, pu, pv, _ = ep_pads[0]
        iu0, iv0 = int(round(pu / STEP)), int(round(pv / STEP))
        placed = False
        for diu in range(0, 5):
            for sgn_u in ([0] if diu == 0 else [-diu, diu]):
                for div in range(-4, 5):
                    giu, giv = iu0 + sgn_u, iv0 + div
                    vu, vv = giu * STEP, giv * STEP
                    if static.can_place_via(vu, vv, "GND", allow_in_same_ep=True):
                        if math.hypot(vu - pu, vv - pv) > 1e-4:
                            emit_track_uv(board, LYR_MAP[l_ep], pu, pv, vu, vv, 0.20, gnd_ni)
                            static.add_fixed_seg(l_ep, pu, pv, vu, vv, 0.10, "GND")
                        if (giu, giv) not in static_gnd_via_grid:
                            emit_via_uv(board, vu, vv, gnd_ni)
                            static.add_fixed_via(vu, vv, "GND")
                            static_gnd_via_grid.add((giu, giv))
                            ep_vias_placed += 1
                        placed = True
                        break
                if placed:
                    break
            if placed:
                break
        if not placed:
            remaining_gnd_clusters.append(clust)

    print(f"Pre-bridged {bridged_count} adjacent intra-IC pads; placed {ep_vias_placed} EP center GND vias.")

    # -------------------------------------------------------------------------
    # Step B: Precompute Pad Escape Stubs & Exact Grid Halo Cells ONCE
    # -------------------------------------------------------------------------
    def idx_to_uv(iu: int, iv: int) -> tuple[float, float]:
        return (iu * STEP, iv * STEP)

    def compute_stub_halos(lyr: int, wpts: list[tuple[float, float]]) -> tuple[list[tuple[int, int, int]], list[tuple[int, int]]]:
        cells: set[tuple[int, int, int]] = set()
        vblk: set[tuple[int, int]] = set()
        iu_end = int(round(wpts[-1][0] / STEP))
        iv_end = int(round(wpts[-1][1] / STEP))
        cells.add((lyr, iu_end, iv_end))
        STEP2 = 0.125
        for k in range(len(wpts) - 1):
            ax, ay = wpts[k]
            bx, by = wpts[k + 1]
            iu_a = int(math.floor((min(ax, bx) - 0.42) / STEP))
            iu_b = int(math.ceil((max(ax, bx) + 0.42) / STEP))
            iv_a = int(math.floor((min(ay, by) - 0.42) / STEP))
            iv_b = int(math.ceil((max(ay, by) + 0.42) / STEP))
            for iu in range(max(G_MIN, iu_a), min(G_MAX, iu_b) + 1):
                for iv in range(max(G_MIN, iv_a), min(G_MAX, iv_b) + 1):
                    d = math.sqrt(pt_seg_dist2(iu * STEP, iv * STEP, ax, ay, bx, by))
                    if d < 0.247:
                        cells.add((lyr, iu, iv))
                    if d < 0.340:
                        vblk.add((iu, iv))
            # Fine 0.125mm sub-grid cells catch 100% of off-grid stub-to-stub clearances (<0.105mm Cu-Cu)
            i2u_a = int(math.floor((min(ax, bx) - 0.22) / STEP2))
            i2u_b = int(math.ceil((max(ax, bx) + 0.22) / STEP2))
            i2v_a = int(math.floor((min(ay, by) - 0.22) / STEP2))
            i2v_b = int(math.ceil((max(ay, by) + 0.22) / STEP2))
            for i2u in range(i2u_a, i2u_b + 1):
                for i2v in range(i2v_a, i2v_b + 1):
                    if math.sqrt(pt_seg_dist2(i2u * STEP2, i2v * STEP2, ax, ay, bx, by)) < 0.198:
                        cells.add((lyr + 10, i2u, i2v))
        return list(cells), list(vblk)

    def build_pad_escapes(lyr: int, pu: float, pv: float, net: str) -> list[EscapeInfo]:
        iu0 = int(round(pu / STEP))
        iv0 = int(round(pv / STEP))
        escapes: list[EscapeInfo] = []
        for rad in range(0, 7):
            for diu in range(-rad, rad + 1):
                for div in range(-rad, rad + 1):
                    if max(abs(diu), abs(div)) != rad:
                        continue
                    iu, iv = iu0 + diu, iv0 + div
                    if not (G_MIN <= iu <= G_MAX and G_MIN <= iv <= G_MAX):
                        continue
                    gu, gv = idx_to_uv(iu, iv)
                    node = (lyr, iu, iv)
                    wpts: list[tuple[float, float]] | None = None
                    if math.hypot(gu - pu, gv - pv) < 1e-4:
                        wpts = [(pu, pv)]
                    elif rad <= 1 and static.can_place_seg(lyr, pu, pv, gu, gv, HW_TRK, net):
                        wpts = [(pu, pv), (gu, gv)]
                    elif static.can_place_seg(lyr, pu, pv, pu, gv, HW_TRK, net) and static.can_place_seg(lyr, pu, gv, gu, gv, HW_TRK, net):
                        wpts = [(pu, pv), (pu, gv), (gu, gv)]
                    elif static.can_place_seg(lyr, pu, pv, gu, pv, HW_TRK, net) and static.can_place_seg(lyr, gu, pv, gu, gv, HW_TRK, net):
                        wpts = [(pu, pv), (gu, pv), (gu, gv)]
                    if wpts is not None:
                        cells, vblk = compute_stub_halos(lyr, wpts)
                        escapes.append(EscapeInfo(node=node, wpts=wpts, cells=cells, vblock=vblk))
            if len(escapes) >= 22 and rad >= 2:
                break
        return escapes

    def cluster_escapes(clust: list[tuple[int, float, float, bool]], net: str) -> list[EscapeInfo]:
        by_node: dict[tuple[int, int, int], EscapeInfo] = {}
        for l, u, v, _ in clust:
            for esc in build_pad_escapes(l, u, v, net):
                if esc.node not in by_node or len(esc.wpts) < len(by_node[esc.node].wpts):
                    by_node[esc.node] = esc
        return list(by_node.values())

    # Build MST tasks for all signals/power + GND-to-plane tasks
    tasks: list[ConnectionTask] = []
    tid_seq = 0

    for net in sorted(net_clusters.keys()):
        if net == "GND":
            continue
        clusts = net_clusters[net]
        k = len(clusts)
        if k < 2:
            continue
        esc_per_c = [cluster_escapes(c, net) for c in clusts]
        in_mst = [False] * k
        in_mst[0] = True
        for _ in range(k - 1):
            best_d = 1e9
            best_pair = (0, 1)
            for i in range(k):
                if not in_mst[i]:
                    continue
                for j in range(k):
                    if in_mst[j]:
                        continue
                    for l1, u1, v1, _ in clusts[i]:
                        for l2, u2, v2, _ in clusts[j]:
                            d = math.hypot(u2 - u1, v2 - v1) + (0.6 if l1 != l2 else 0.0)
                            if d < best_d:
                                best_d = d
                                best_pair = (i, j)
            ci, cj = best_pair
            in_mst[cj] = True
            tasks.append(ConnectionTask(
                tid=tid_seq,
                kind="NET_EDGE",
                net=net,
                src_escapes=esc_per_c[ci],
                dst_escapes=esc_per_c[cj],
            ))
            tid_seq += 1

    for clust in remaining_gnd_clusters:
        tasks.append(ConnectionTask(
            tid=tid_seq,
            kind="GND_VIA",
            net="GND",
            src_escapes=cluster_escapes(clust, "GND"),
            dst_escapes=[],
        ))
        tid_seq += 1

    zero_src = [t.tid for t in tasks if not t.src_escapes or (t.kind == "NET_EDGE" and not t.dst_escapes)]
    print(f"Total tasks: {len(tasks)} ({sum(t.kind=='NET_EDGE' for t in tasks)} net edges + {sum(t.kind=='GND_VIA' for t in tasks)} GND vias); zero-escape tasks={len(zero_src)}")

    # -------------------------------------------------------------------------
    # Step C: Gauss-Seidel One-Net-At-A-Time PathFinder on Pure Orthogonal Grid
    # -------------------------------------------------------------------------
    occ = GridOccupancy()
    # Register permanent EP center GND vias and intra-IC bridges so dynamic tasks never graze them!
    for idx_v, (giu, giv) in enumerate(static_gnd_via_grid, start=1):
        occ.commit(-idx_v, "GND", set(), [(giu, giv)], set(), [])
    seen_fids: set[int] = set()
    for (lyr, _, _), fitems in static.fixed_segs.items():
        for fitem in fitems:
            if id(fitem) in seen_fids:
                continue
            seen_fids.add(id(fitem))
            u0, v0, u1, v1, _, snet = fitem
            fc, fv = compute_stub_halos(lyr, [(u0, v0), (u1, v1)])
            occ.commit(-1000, snet, set(fc), [], set(fv), [])

    ORTHO_DIRS = [(1, 0), (-1, 0), (0, 1), (0, -1)]

    # Precompute exact O(1) static grid edge & via legality once (eliminates 95,000*113 float checks)
    t_pre = time.time()
    via_rule: dict[tuple[int, int], bool | str | frozenset[str]] = {}
    vr_cu = static.VIA_R
    for iu in range(G_MIN, G_MAX + 1):
        u = iu * STEP
        for iv in range(G_MIN, G_MAX + 1):
            v = iv * STEP
            if not static.in_bounds_pt(u, v, vr_cu, False):
                via_rule[(iu, iv)] = False
                continue
            blk_nets: set[str] = set()
            same_blk: set[str] = set()
            for vu, vv, vr, vnet in static.fixed_vias:
                d = math.hypot(u - vu, v - vv)
                if d < vr_cu + vr + static.CLR:
                    blk_nets.add(vnet)
                if 1e-4 < d < 0.48:
                    same_blk.add(vnet)
            if len(blk_nets) >= 2:
                via_rule[(iu, iv)] = False
                continue
            for lyr in (0, 3):
                seen_vp: set[int] = set()
                for ix, iy in static._cells(u, v, u, v, vr_cu + 0.25):
                    for item in static.pad_grid.get((lyr, ix, iy), ()):
                        if id(item) in seen_vp:
                            continue
                        seen_vp.add(id(item))
                        pu0, pv0, pu1, pv1, pnet, _ = item
                        if u < pu0 - vr_cu - 0.25 or u > pu1 + vr_cu + 0.25 or v < pv0 - vr_cu - 0.25 or v > pv1 + vr_cu + 0.25:
                            continue
                        d = pt_rect_dist(u, v, pu0, pv0, pu1, pv1)
                        if d < vr_cu + static.CLR:
                            blk_nets.add(pnet)
                        if d < 0.05:
                            same_blk.add(pnet)
            if len(blk_nets) >= 2:
                via_rule[(iu, iv)] = False
                continue
            for lyr in (0, 1, 2, 3):
                seen_vs: set[int] = set()
                for ix, iy in static._cells(u, v, u, v, vr_cu + 0.25):
                    for item in static.fixed_segs.get((lyr, ix, iy), ()):
                        if id(item) in seen_vs:
                            continue
                        seen_vs.add(id(item))
                        su0, sv0, su1, sv1, shw, snet = item
                        if math.sqrt(pt_seg_dist2(u, v, su0, sv0, su1, sv1)) < vr_cu + shw + static.CLR:
                            blk_nets.add(snet)
            if len(blk_nets) == 0:
                via_rule[(iu, iv)] = frozenset(same_blk) if same_blk else True
            elif len(blk_nets) == 1:
                only_n = next(iter(blk_nets))
                via_rule[(iu, iv)] = False if only_n in same_blk else only_n
            else:
                via_rule[(iu, iv)] = False

    # Undirected orthogonal edges: key (lyr, min_iu, min_iv, is_vert) -> True | False | only_net_str
    edge_rule: dict[tuple[int, int, int, int], bool | str] = {}
    req_pad_g = HW_TRK + static.CLR
    ku0_a, kv0_a, ku1_a, kv1_a = static.ANT_KO
    for lyr in (0, 1, 2, 3):
        for iu in range(G_MIN, G_MAX + 1):
            u0 = iu * STEP
            for iv in range(G_MIN, G_MAX + 1):
                v0 = iv * STEP
                for is_vert, (diu, div) in ((0, (1, 0)), (1, (0, 1))):
                    niu, niv = iu + diu, iv + div
                    if niu > G_MAX or niv > G_MAX:
                        continue
                    u1, v1 = niu * STEP, niv * STEP
                    ekey = (lyr, iu, iv, is_vert)
                    if lyr == 1 and min(u0, u1) < -7.75 and 5.50 < max(v0, v1) and min(v0, v1) < 7.60:
                        edge_rule[ekey] = False
                        continue
                    if not static.in_bounds_pt(u0, v0, HW_TRK, False) or not static.in_bounds_pt(u1, v1, HW_TRK, False):
                        edge_rule[ekey] = False
                        continue
                    m2_bad = False
                    for mu, mv in static.M2_UV:
                        if math.sqrt(pt_seg_dist2(mu, mv, u0, v0, u1, v1)) < (M2_HOLE_DIA_MM * 0.5 + 0.52 + HW_TRK):
                            m2_bad = True
                            break
                    if m2_bad or seg_rect_dist(u0, v0, u1, v1, ku0_a, kv0_a, ku1_a, kv1_a) < HW_TRK + 0.05:
                        edge_rule[ekey] = False
                        continue
                    eblk: set[str] = set()
                    seen_ep: set[int] = set()
                    for ix, iy in static._cells(u0, v0, u1, v1, req_pad_g + 0.1):
                        for item in static.pad_grid.get((lyr, ix, iy), ()):
                            if id(item) in seen_ep:
                                continue
                            seen_ep.add(id(item))
                            pu0, pv0, pu1, pv1, pnet, _ = item
                            if u1 + req_pad_g < pu0 or u0 - req_pad_g > pu1 or v1 + req_pad_g < pv0 or v0 - req_pad_g > pv1:
                                continue
                            if seg_rect_dist(u0, v0, u1, v1, pu0, pv0, pu1, pv1) < req_pad_g:
                                eblk.add(pnet)
                    if len(eblk) < 2:
                        for vu, vv, vr, vnet in static.fixed_vias:
                            if vu < u0 - 0.6 or vu > u1 + 0.6 or vv < v0 - 0.6 or vv > v1 + 0.6:
                                continue
                            if math.sqrt(pt_seg_dist2(vu, vv, u0, v0, u1, v1)) < HW_TRK + vr + static.CLR:
                                eblk.add(vnet)
                    if len(eblk) < 2:
                        seen_es: set[int] = set()
                        for ix, iy in static._cells(u0, v0, u1, v1, HW_TRK + 0.35):
                            for item in static.fixed_segs.get((lyr, ix, iy), ()):
                                if id(item) in seen_es:
                                    continue
                                seen_es.add(id(item))
                                su0, sv0, su1, sv1, shw, snet = item
                                if seg_seg_dist(u0, v0, u1, v1, su0, sv0, su1, sv1) < HW_TRK + shw + static.CLR:
                                    eblk.add(snet)
                    if len(eblk) == 0:
                        edge_rule[ekey] = True
                    elif len(eblk) == 1:
                        edge_rule[ekey] = next(iter(eblk))
                    else:
                        edge_rule[ekey] = False
    print(f"Precomputed O(1) static grid legality ({len(edge_rule)} edges, {len(via_rule)} via sites) in {time.time() - t_pre:.2f}s")

    def can_via_grid(iu: int, iv: int, net: str) -> bool:
        vr = via_rule.get((iu, iv), False)
        if vr is True or vr == net:
            return True
        if isinstance(vr, frozenset):
            return net not in vr
        return False

    def has_stub_conflict(esc: EscapeInfo, net: str) -> bool:
        for c in esc.cells:
            if occ.has_cell_conflict(c, net):
                return True
        for iu, iv in esc.vblock:
            vs = occ.via_sites.get((iu, iv))
            if vs and (len(vs) > 1 or net not in vs):
                return True
        return False

    def stub_penalty(esc: EscapeInfo, net: str, pres_fac: float) -> float:
        pen = 0.0
        for c in esc.cells:
            pen += occ.cell_step_penalty(c, net, pres_fac)
        for iu, iv in esc.vblock:
            hv = occ.hist_via.get((iu, iv), 0.0)
            if hv > 0.0:
                pen += 0.25 * hv
            vs = occ.via_sites.get((iu, iv))
            if vs:
                foreign_v = len(vs) - (1 if net in vs else 0)
                if foreign_v > 0:
                    pen += (0.60 + hv) * foreign_v * pres_fac
        return pen

    fixed_cell_nets: dict[tuple[int, int, int], set[str]] = {c: set(cn.keys()) for c, cn in occ.cell_nets.items() if cn}
    fixed_via_nets: dict[tuple[int, int], set[str]] = {v: set(vs.keys()) for v, vs in occ.via_sites.items() if vs}
    fixed_vblk_nets: dict[tuple[int, int], set[str]] = {v: set(vb.keys()) for v, vb in occ.stub_via_block.items() if vb}

    def has_forbid_cell(c: tuple[int, int, int], net: str, forbid_tids: set[int]) -> bool:
        fn = fixed_cell_nets.get(c)
        if fn and (len(fn) > 1 or net not in fn):
            return True
        ct = occ.cell_tids.get(c)
        if ct:
            for ft in ct:
                if ft in forbid_tids and occ.task_cells[ft][0] != net:
                    return True
        return False

    def has_forbid_via(iu: int, iv: int, net: str, forbid_tids: set[int]) -> bool:
        for lyr in (0, 1, 2, 3):
            for dx, dy in VIA_PLUS:
                if has_forbid_cell((lyr, iu + dx, iv + dy), net, forbid_tids):
                    return True
        fb = fixed_vblk_nets.get((iu, iv))
        if fb and (len(fb) > 1 or net not in fb):
            return True
        st = occ.stub_via_tids.get((iu, iv))
        if st:
            for ft in st:
                if ft in forbid_tids and occ.task_cells[ft][0] != net:
                    return True
        for dx, dy in VIA_EXCL:
            fv = fixed_via_nets.get((iu + dx, iv + dy))
            if fv:
                if dx != 0 or dy != 0 or len(fv) > 1 or net not in fv:
                    return True
            vt = occ.via_site_tids.get((iu + dx, iv + dy))
            if vt:
                for ft in vt:
                    if ft in forbid_tids:
                        if dx != 0 or dy != 0 or occ.task_cells[ft][0] != net:
                            return True
        return False

    def has_forbid_stub(esc: EscapeInfo, net: str, forbid_tids: set[int]) -> bool:
        for c in esc.cells:
            if has_forbid_cell(c, net, forbid_tids):
                return True
        for iu, iv in esc.vblock:
            fv = fixed_via_nets.get((iu, iv))
            if fv and (len(fv) > 1 or net not in fv):
                return True
            vt = occ.via_site_tids.get((iu, iv))
            if vt:
                for ft in vt:
                    if ft in forbid_tids and occ.task_cells[ft][0] != net:
                        return True
        return False

    EMPTY_FORBID: set[int] = set()

    def route_task(
        task: ConnectionTask,
        pres_fac: float,
        max_exp: int = 75000,
        strict: bool = False,
        forbid_tids: set[int] | None = None,
    ) -> bool:
        if forbid_tids is None:
            forbid_tids = EMPTY_FORBID
        net = task.net
        is_rf_ant = net in ("ELRS_ANT_FEED", "ELRS_RFIO")
        if not task.src_escapes:
            return False

        dst_by_node: dict[tuple[int, int, int], tuple[EscapeInfo, float]] = {}
        du_lo, du_hi, dv_lo, dv_hi = 0, 0, 0, 0
        dst_lyrs: set[int] = set()
        if task.kind == "NET_EDGE":
            if not task.dst_escapes:
                return False
            for desc in task.dst_escapes:
                if strict and has_stub_conflict(desc, net):
                    continue
                if forbid_tids is not None and has_forbid_stub(desc, net, forbid_tids):
                    continue
                dpen = stub_penalty(desc, net, pres_fac)
                dst_by_node[desc.node] = (desc, dpen)
            if not dst_by_node:
                return False
            du_lo = min(k[1] for k in dst_by_node)
            du_hi = max(k[1] for k in dst_by_node)
            dv_lo = min(k[2] for k in dst_by_node)
            dv_hi = max(k[2] for k in dst_by_node)
            dst_lyrs = {k[0] for k in dst_by_node}

        def h_est(l: int, iu: int, iv: int) -> float:
            if task.kind == "GND_VIA":
                return 0.0
            dx = du_lo - iu if iu < du_lo else (iu - du_hi if iu > du_hi else 0)
            dy = dv_lo - iv if iv < dv_lo else (iv - dv_hi if iv > dv_hi else 0)
            return (dx + dy) * STEP + (0.0 if l in dst_lyrs else 0.45)

        pq: list[tuple[float, float, tuple[int, int, int]]] = []
        g_cost: dict[tuple[int, int, int], float] = {}
        parent: dict[tuple[int, int, int], tuple[int, int, int] | None] = {}
        start_esc: dict[tuple[int, int, int], EscapeInfo] = {}

        for sesc in task.src_escapes:
            if strict and has_stub_conflict(sesc, net):
                continue
            if forbid_tids is not None and has_forbid_stub(sesc, net, forbid_tids):
                continue
            sc = 0.04 * len(sesc.wpts) + stub_penalty(sesc, net, pres_fac)
            if sc < g_cost.get(sesc.node, 1e9):
                g_cost[sesc.node] = sc
                parent[sesc.node] = None
                start_esc[sesc.node] = sesc
                heapq.heappush(pq, (sc + h_est(*sesc.node), sc, sesc.node))

        if not pq:
            return False

        GOAL_SENTINEL = (-1, 0, 0)
        goal_pred: tuple[int, int, int] | None = None
        goal_drops_via = False
        expansions = 0

        while pq and expansions < max_exp:
            _, gc, cur = heapq.heappop(pq)
            if cur == GOAL_SENTINEL:
                break
            if gc > g_cost.get(cur, 1e9) + 1e-6:
                continue

            cl, ciu, civ = cur

            if task.kind == "NET_EDGE" and cur in dst_by_node:
                _, dpen = dst_by_node[cur]
                tot = gc + dpen
                if tot < g_cost.get(GOAL_SENTINEL, 1e9):
                    g_cost[GOAL_SENTINEL] = tot
                    goal_pred = cur
                    heapq.heappush(pq, (tot, tot, GOAL_SENTINEL))

            if task.kind == "GND_VIA":
                if (ciu, civ) in static_gnd_via_grid:
                    tot = gc + 0.05
                    if tot < g_cost.get(GOAL_SENTINEL, 1e9):
                        g_cost[GOAL_SENTINEL] = tot
                        goal_pred = cur
                        goal_drops_via = False
                        heapq.heappush(pq, (tot, tot, GOAL_SENTINEL))
                elif (
                    can_via_grid(ciu, civ, "GND")
                    and not (strict and occ.has_via_conflict(ciu, civ, "GND"))
                    and not (forbid_tids is not None and has_forbid_via(ciu, civ, "GND", forbid_tids))
                ):
                    vpen = occ.via_step_penalty(ciu, civ, "GND", pres_fac)
                    reuse_bonus = 0.05 if "GND" in occ.via_sites.get((ciu, civ), {}) else 0.30
                    tot = gc + reuse_bonus + vpen
                    if tot < g_cost.get(GOAL_SENTINEL, 1e9):
                        g_cost[GOAL_SENTINEL] = tot
                        goal_pred = cur
                        goal_drops_via = True
                        heapq.heappush(pq, (tot, tot, GOAL_SENTINEL))

            expansions += 1

            for diu, div in ORTHO_DIRS:
                niu, niv = ciu + diu, civ + div
                if not (G_MIN <= niu <= G_MAX and G_MIN <= niv <= G_MAX):
                    continue
                nxt = (cl, niu, niv)
                if strict and occ.has_cell_conflict(nxt, net):
                    continue
                if forbid_tids is not None and has_forbid_cell(nxt, net, forbid_tids):
                    continue
                if is_rf_ant:
                    if not static.can_place_seg(cl, ciu * STEP, civ * STEP, niu * STEP, niv * STEP, HW_TRK, net):
                        continue
                else:
                    ekey = (cl, ciu if diu >= 0 else niu, civ if div >= 0 else niv, 0 if div == 0 else 1)
                    er = edge_rule.get(ekey, False)
                    if er is not True and er != net:
                        continue
                if cl == 1:
                    dir_cost = 0.25 if div == 0 else 0.35
                elif cl == 2:
                    dir_cost = 0.25 if diu == 0 else 0.35
                else:
                    dir_cost = 0.28
                cpen = occ.cell_step_penalty(nxt, net, pres_fac)
                ng = gc + dir_cost + cpen
                if ng + 1e-6 < g_cost.get(nxt, 1e9):
                    g_cost[nxt] = ng
                    parent[nxt] = cur
                    heapq.heappush(pq, (ng + h_est(cl, niu, niv), ng, nxt))

            if (
                can_via_grid(ciu, civ, net)
                and not (strict and occ.has_via_conflict(ciu, civ, net))
                and not (forbid_tids is not None and has_forbid_via(ciu, civ, net, forbid_tids))
            ):
                vpen = occ.via_step_penalty(ciu, civ, net, pres_fac)
                for nl in (0, 1, 2, 3):
                    if nl == cl:
                        continue
                    nxt = (nl, ciu, civ)
                    if strict and occ.has_cell_conflict(nxt, net):
                        continue
                    if forbid_tids is not None and has_forbid_cell(nxt, net, forbid_tids):
                        continue
                    ng = gc + 0.55 + vpen + occ.cell_step_penalty(nxt, net, pres_fac)
                    if ng + 1e-6 < g_cost.get(nxt, 1e9):
                        g_cost[nxt] = ng
                        parent[nxt] = cur
                        heapq.heappush(pq, (ng + h_est(nl, ciu, civ), ng, nxt))

        if goal_pred is None:
            return False

        path: list[tuple[int, int, int]] = []
        curr: tuple[int, int, int] | None = goal_pred
        while curr is not None:
            path.append(curr)
            curr = parent[curr]
        path.reverse()

        sesc = start_esc[path[0]]
        claimed_cells: set[tuple[int, int, int]] = set(sesc.cells)
        stub_vblock: set[tuple[int, int]] = set(sesc.vblock)
        placed_vias: list[tuple[int, int]] = []
        segs: list[tuple[int, float, float, float, float]] = []

        sl = sesc.node[0]
        for k in range(len(sesc.wpts) - 1):
            ax, ay = sesc.wpts[k]
            bx, by = sesc.wpts[k + 1]
            if math.hypot(bx - ax, by - ay) > 1e-4:
                segs.append((sl, ax, ay, bx, by))

        for node in path:
            claimed_cells.add(node)

        i = 0
        while i < len(path) - 1:
            l0, iu0, iv0 = path[i]
            l1, iu1, iv1 = path[i + 1]
            if l0 != l1:
                if (iu0, iv0) not in placed_vias:
                    placed_vias.append((iu0, iv0))
                i += 1
            else:
                diu, div = iu1 - iu0, iv1 - iv0
                j = i + 1
                while j + 1 < len(path) and path[j + 1][0] == l0:
                    if (path[j + 1][1] - path[j][1], path[j + 1][2] - path[j][2]) == (diu, div):
                        j += 1
                    else:
                        break
                ax, ay = idx_to_uv(iu0, iv0)
                bx, by = idx_to_uv(path[j][1], path[j][2])
                segs.append((l0, ax, ay, bx, by))
                i = j

        if task.kind == "NET_EDGE":
            desc, _ = dst_by_node[goal_pred]
            claimed_cells.update(desc.cells)
            stub_vblock.update(desc.vblock)
            dl = desc.node[0]
            for k in range(len(desc.wpts) - 1, 0, -1):
                ax, ay = desc.wpts[k]
                bx, by = desc.wpts[k - 1]
                if math.hypot(bx - ax, by - ay) > 1e-4:
                    segs.append((dl, ax, ay, bx, by))
        elif goal_drops_via:
            giu, giv = goal_pred[1], goal_pred[2]
            if (giu, giv) not in placed_vias:
                placed_vias.append((giu, giv))

        occ.commit(task.tid, net, claimed_cells, placed_vias, stub_vblock, segs)
        return True

    task_by_id = {t.tid: t for t in tasks}
    task_min_esc = {
        t.tid: min(len(t.src_escapes), len(t.dst_escapes) if t.kind == "NET_EDGE" else 999)
        for t in tasks
    }

    # Phase 1: Fast One-At-A-Time Gauss-Seidel (converges 335 -> ~22 tasks in ~68s with 0 unrouted!)
    pres_fac = 0.80
    MAX_ITERS = 46

    unrouted_tids: set[int] = set()
    for t in tasks:
        if not route_task(t, pres_fac):
            unrouted_tids.add(t.tid)

    for it in range(MAX_ITERS):
        bad_tids = occ.find_conflicts_and_bump_history(hist_inc=0.50)
        todo = sorted(bad_tids | unrouted_tids)
        if it % 5 == 0 or len(todo) <= 25:
            print(f"  [Gauss-Seidel iter {it:02d}] conflicting_tasks={len(bad_tids)} unrouted={len(unrouted_tids)} pres={pres_fac:.2f} elapsed={time.time() - t0:.2f}s")
        if not todo:
            break

        pres_fac = min(pres_fac * 1.18, 600.0)
        todo.sort(key=lambda tid: (((tid * 73 + it * 37) % 997), tid))

        unrouted_tids.clear()
        for tid in todo:
            occ.rip_up(tid)
            if not route_task(task_by_id[tid], pres_fac, max_exp=75000):
                unrouted_tids.add(tid)

    # Phase 2: Exact Transactional Push-and-Shove + Pair/Knot Untangle Solver
    occ.enable_undo()

    def get_tid_conflicts(tid: int) -> set[int]:
        rec = occ.task_cells.get(tid)
        if rec is None:
            return set()
        net, all_cells, via_set, stub_vblock = rec
        victims: set[int] = set()
        for c in all_cells:
            if len(occ.cell_nets.get(c, ())) > 1:
                for t2 in occ.cell_tids.get(c, ()):
                    if t2 != tid and occ.task_cells[t2][0] != net:
                        victims.add(t2)
        for iu, iv in via_set:
            for t2 in occ.stub_via_tids.get((iu, iv), ()):
                if t2 != tid and occ.task_cells[t2][0] != net:
                    victims.add(t2)
            for dx, dy in VIA_EXCL:
                for t2 in occ.via_site_tids.get((iu + dx, iv + dy), ()):
                    if t2 != tid:
                        if dx != 0 or dy != 0 or occ.task_cells[t2][0] != net:
                            victims.add(t2)
        for iu, iv in stub_vblock:
            for t2 in occ.via_site_tids.get((iu, iv), ()):
                if t2 != tid and occ.task_cells[t2][0] != net:
                    victims.add(t2)
        return victims

    def try_shove(tid: int, locked_tids: set[int], depth_left: int) -> bool:
        mark0 = occ.checkpoint()
        occ.rip_up(tid)
        if route_task(task_by_id[tid], 80.0, max_exp=16000, strict=True):
            return True
        if depth_left <= 0:
            occ.rollback(mark0)
            return False

        local_avoid = set(locked_tids)
        max_tries = 3 if depth_left >= 2 else 2
        for _ in range(max_tries):
            mark_try = occ.checkpoint()
            occ.rip_up(tid)
            if not route_task(task_by_id[tid], 200.0, max_exp=14000, strict=False, forbid_tids=local_avoid):
                occ.rollback(mark_try)
                break
            victims = sorted(
                get_tid_conflicts(tid),
                key=lambda x: (0 if task_by_id[x].kind == "NET_EDGE" else 1, task_min_esc[x], x),
            )
            if not victims:
                return True
            if len(victims) > 3:
                local_avoid.add(victims[0])
                occ.rollback(mark_try)
                continue

            for v in victims:
                occ.rip_up(v)

            cur_locked = set(locked_tids) | {tid}
            all_ok = True
            for v in victims:
                if not try_shove(v, cur_locked, depth_left - 1):
                    all_ok = False
                    local_avoid.add(v)
                    break
                cur_locked.add(v)

            if all_ok:
                return True

            occ.rollback(mark_try)

        occ.rollback(mark0)
        return False

    for s_pass in range(3):
        bad_tids = occ.find_conflicts_and_bump_history(hist_inc=0.30)
        todo_shove = sorted(
            bad_tids | unrouted_tids,
            key=lambda x: (0 if task_by_id[x].kind == "NET_EDGE" else 1, task_min_esc[x], ((x * 53 + s_pass * 19) % 991)),
        )
        print(f"  [Push-and-Shove pass {s_pass}] bad={len(bad_tids)} unrouted={len(unrouted_tids)} elapsed={time.time() - t0:.2f}s", flush=True)
        if not todo_shove:
            break
        depth_lim = 1 if s_pass == 0 else 2
        for tid in todo_shove:
            if tid in unrouted_tids or get_tid_conflicts(tid):
                if try_shove(tid, set(), depth_lim):
                    unrouted_tids.discard(tid)

        # Pairwise / knot untangle pass for topological X-crossings
        rem_bad = sorted(occ.find_conflicts_and_bump_history(hist_inc=0.20))
        for t1 in rem_bad:
            confs = sorted(get_tid_conflicts(t1))
            if not confs or len(confs) > 2:
                continue
            knot = [t1] + confs
            for order in (knot, list(reversed(knot))):
                mark_k = occ.checkpoint()
                for kt in order:
                    occ.rip_up(kt)
                locked_k: set[int] = set()
                ok_k = True
                for kt in order:
                    if not try_shove(kt, locked_k, 1):
                        ok_k = False
                        break
                    locked_k.add(kt)
                if ok_k:
                    for kt in order:
                        unrouted_tids.discard(kt)
                    break
                occ.rollback(mark_k)

    # Phase 3: Verify every EP static GND via AND dynamic GND_VIA is flood-connected to main outer GND pour!
    def is_foreign_gnd(lyr: int, iu: int, iv: int) -> bool:
        cn = occ.cell_nets.get((lyr, iu, iv))
        return bool(cn and (len(cn) > 1 or "GND" not in cn))

    pour_safe: set[tuple[int, int, int]] = set()
    for lyr in (1, 2):
        for iu in range(-50, 51):
            for iv in range(-50, 51):
                if lyr == 1 and iu * STEP < -11.0 and 6.5 < iv * STEP < 8.5:
                    continue
                ok = True
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        if is_foreign_gnd(lyr, iu + dx, iv + dy):
                            ok = False
                            break
                    if not ok:
                        break
                if ok:
                    pour_safe.add((lyr, iu, iv))

    all_gnd_vias: set[tuple[int, int]] = set(static_gnd_via_grid)
    for (iu, iv), vs in occ.via_sites.items():
        if "GND" in vs and len(vs) == 1:
            all_gnd_vias.add((iu, iv))

    main_pour: set[tuple[int, int, int]] = set()
    bfs_q: list[tuple[int, int, int]] = [
        c for c in pour_safe if abs(c[1]) >= 46 or abs(c[2]) >= 46
    ]
    main_pour.update(bfs_q)
    q_idx = 0
    while q_idx < len(bfs_q):
        cl, ciu, civ = bfs_q[q_idx]
        q_idx += 1
        for diu, div in ORTHO_DIRS:
            nxt = (cl, ciu + diu, civ + div)
            if nxt in pour_safe and nxt not in main_pour:
                main_pour.add(nxt)
                bfs_q.append(nxt)
        if (ciu, civ) in all_gnd_vias:
            other = (3 - cl, ciu, civ)
            if other in pour_safe and other not in main_pour:
                main_pour.add(other)
                bfs_q.append(other)

    connected_gnd_vias: set[tuple[int, int]] = set()
    for giu, giv in all_gnd_vias:
        for lyr in (1, 2):
            if not is_foreign_gnd(lyr, giu, giv):
                if (lyr, giu, giv) in main_pour or any((lyr, giu + dx, giv + dy) in main_pour for dx, dy in ORTHO_DIRS):
                    connected_gnd_vias.add((giu, giv))
                    break

    def build_main_gnd_targets() -> list[EscapeInfo]:
        res: list[EscapeInfo] = []
        for giu, giv in sorted(connected_gnd_vias):
            for lyr in (0, 1, 2, 3):
                if not is_foreign_gnd(lyr, giu, giv):
                    res.append(EscapeInfo(node=(lyr, giu, giv), wpts=[idx_to_uv(giu, giv)], cells=[(lyr, giu, giv)], vblock=[]))
        return res

    main_gnd_targets = build_main_gnd_targets()
    stitched_gnd = 0

    # 3A: Stitch any pinched-off Exposed Pad static GND center via first!
    ep_tid_seq = 10000
    for giu, giv in sorted(static_gnd_via_grid):
        if (giu, giv) in connected_gnd_vias or not main_gnd_targets:
            continue
        ep_srcs = [
            EscapeInfo(node=(lyr, giu, giv), wpts=[idx_to_uv(giu, giv)], cells=[(lyr, giu, giv)], vblock=[])
            for lyr in (0, 1, 2, 3)
            if not is_foreign_gnd(lyr, giu, giv)
        ]
        if not ep_srcs:
            continue
        ep_task = ConnectionTask(tid=ep_tid_seq, kind="NET_EDGE", net="GND", src_escapes=ep_srcs, dst_escapes=main_gnd_targets)
        task_by_id[ep_tid_seq] = ep_task
        task_min_esc[ep_tid_seq] = len(ep_srcs)
        if try_shove(ep_tid_seq, set(), 1):
            connected_gnd_vias.add((giu, giv))
            main_gnd_targets = build_main_gnd_targets()
            stitched_gnd += 1
            ep_tid_seq += 1
        else:
            task_by_id.pop(ep_tid_seq, None)

    # 3B: Stitch any pinched-off dynamic GND_VIA task!
    for t in tasks:
        if t.kind != "GND_VIA":
            continue
        rec = occ.task_cells.get(t.tid)
        if rec is None:
            continue
        _, _, tvias, _ = rec
        end_ok = any(v in connected_gnd_vias for v in tvias)
        if not end_ok and not tvias:
            segs_t, _ = occ.task_geom[t.tid]
            if segs_t:
                end_uv = (int(round(segs_t[-1][3] / STEP)), int(round(segs_t[-1][4] / STEP)))
                end_ok = end_uv in connected_gnd_vias
            elif t.src_escapes:
                n0 = t.src_escapes[0].node
                end_ok = (n0[1], n0[2]) in connected_gnd_vias
        if not end_ok and main_gnd_targets:
            mark_g = occ.checkpoint()
            stitch_task = ConnectionTask(tid=t.tid, kind="NET_EDGE", net="GND", src_escapes=t.src_escapes, dst_escapes=main_gnd_targets)
            task_by_id[t.tid] = stitch_task
            task_min_esc[t.tid] = len(t.src_escapes)
            if try_shove(t.tid, set(), 1):
                stitched_gnd += 1
            else:
                task_by_id[t.tid] = t
                occ.rollback(mark_g)

    final_bad = occ.find_conflicts_and_bump_history(hist_inc=0.0)
    print(f"Final router status: conflicting_tasks={len(final_bad)}, unrouted={len(unrouted_tids)}, stitched_gnd={stitched_gnd}")

    # Emit all routed copper tracks and deduplicated vias into pcbnew.BOARD
    emitted_via_grid: set[tuple[int, int, str]] = {
        (int(round(vu / STEP)), int(round(vv / STEP)), vn) for (vu, vv, _, vn) in static.fixed_vias
    }
    total_segs = 0
    total_vias = 0
    for tid in sorted(occ.task_geom.keys()):
        net = task_by_id[tid].net
        ni = net_items[net]
        segs, vias = occ.task_geom[tid]
        for lyr, ax, ay, bx, by in segs:
            emit_track_uv(board, LYR_MAP[lyr], ax, ay, bx, by, W_TRK, ni)
            total_segs += 1
        for iu, iv in vias:
            if (iu, iv, net) in emitted_via_grid:
                continue
            emit_via_uv(board, iu * STEP, iv * STEP, ni)
            emitted_via_grid.add((iu, iv, net))
            total_vias += 1

    print(f"Emitted {total_segs} copper segments and {total_vias} routed vias (+ {ep_vias_placed} EP vias) in {time.time() - t0:.2f}s")

    # -------------------------------------------------------------------------
    # Step D: Add ANT1 All-Layer Keepout Rule Area + Dual Inner In1.Cu/In2.Cu GND Pours
    # -------------------------------------------------------------------------
    ku0, kv0, ku1, kv1 = StaticBoard.ANT_KO
    ko = pcbnew.ZONE(board)
    ko.SetIsRuleArea(True)
    ko_lset = pcbnew.LSET()
    for lyr in (pcbnew.F_Cu, pcbnew.In1_Cu, pcbnew.In2_Cu, pcbnew.B_Cu):
        ko_lset.addLayer(lyr)
    ko.SetLayerSet(ko_lset)
    ko.SetDoNotAllowZoneFills(True)
    ko.SetDoNotAllowTracks(False)
    ko.SetDoNotAllowVias(True)
    ko.SetDoNotAllowPads(False)
    ko.SetDoNotAllowFootprints(False)
    ko_ol = ko.Outline()
    ko_ol.NewOutline()
    for cu, cv in [(ku0, kv0), (ku1, kv0), (ku1, kv1), (ku0, kv1)]:
        ko_ol.Append(*vec_mm(*uv_to_xy(cu, cv)))
    board.Add(ko)

    Z_HALF = WAIST_HALF_MM - 0.50
    for gnd_lyr in (pcbnew.In1_Cu, pcbnew.In2_Cu):
        z_gnd = pcbnew.ZONE(board)
        z_gnd.SetLayer(gnd_lyr)
        z_gnd.SetNet(gnd_ni)
        z_gnd.SetLocalClearance(pcbnew.FromMM(0.10))
        z_gnd.SetMinThickness(pcbnew.FromMM(0.10))
        z_gnd.SetPadConnection(pcbnew.ZONE_CONNECTION_FULL)
        zol = z_gnd.Outline()
        zol.NewOutline()
        for cu, cv in [(-Z_HALF, -Z_HALF), (Z_HALF, -Z_HALF), (Z_HALF, Z_HALF), (-Z_HALF, Z_HALF)]:
            zol.Append(*vec_mm(*uv_to_xy(cu, cv)))
        board.Add(z_gnd)

    pcbnew.ZONE_FILLER(board).Fill(board.Zones())
    conn = board.GetConnectivity()
    conn.Build(board)
    print(f"pcbnew post-zone unconnected count: {conn.GetUnconnectedCount(False)}")

    out_pcb = pcb_dir / f"{PROJECT_NAME}.kicad_pcb"
    pcbnew.SaveBoard(str(out_pcb), board)
    print(f"Saved {out_pcb.name} ({out_pcb.stat().st_size:,} bytes)")


def main() -> int:
    write_custom_footprints_and_3d(PCB_DIR)
    comps = build_components()
    write_kicad_pro(PCB_DIR)
    sym_uuids = write_kicad_sch(PCB_DIR, comps)
    build_and_route_pcb(PCB_DIR, comps, sym_uuids)
    return 0


if __name__ == "__main__":
    sys.exit(main())
