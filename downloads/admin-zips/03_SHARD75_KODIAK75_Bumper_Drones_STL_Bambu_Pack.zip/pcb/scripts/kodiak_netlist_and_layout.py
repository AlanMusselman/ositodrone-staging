#!/usr/bin/env python3
"""Datasheet-verified netlist, custom Whoop footprints, and (u, v) diamond layout
for OSITO_KODIAK_FC_v1 (KiCad 10 native 4-Layer 1S 5-in-1 Brushless AIO).

Coordinate transform (Cardinal Diamond aligned):
  Board M2 holes sit at (0, -18.031), (+18.031, 0), (0, +18.031), (-18.031, 0).
  Let (u, v) in [-14.20, +14.20]^2 be the 45-deg rotated frame (28.4 x 28.4 mm waist,
  clearing KODIAK-75's R = 14.90 mm inboard prop hoops cleanly):
    x = (u - v) / sqrt(2)
    y = (u + v) / sqrt(2)
  - North (Nose) M2: (u=-12.75, v=-12.75) -> (0.000, -18.031)
  - East (Right) M2: (u=+12.75, v=-12.75) -> (+18.031, 0.000)
  - South (Tail) M2: (u=+12.75, v=+12.75) -> (0.000, +18.031)
  - West (Left)  M2: (u=-12.75, v=+12.75) -> (-18.031, 0.000)
  - Edge v = -14.20: Front-Right (Motor 2) 45-deg waist
  - Edge u = +14.20: Rear-Right  (Motor 1) 45-deg waist
  - Edge v = +14.20: Rear-Left   (Motor 3) 45-deg waist
  - Edge u = -14.20: Front-Left  (Motor 4) 45-deg waist
"""

from __future__ import annotations

import math
import uuid
from dataclasses import dataclass
from pathlib import Path

SQRT2 = math.sqrt(2.0)
WAIST_HALF_MM = 14.20
M2_SPAN_HALF_MM = 12.75  # 25.50 / 2 -> hypot = 18.0312 mm
M2_EAR_RADIUS_MM = 2.45
M2_HOLE_DIA_MM = 2.10
NAMESPACE = uuid.UUID("7b84a45c-6c92-4f9e-9c31-051704731001")


def det_uuid(tag: str) -> str:
    return str(uuid.uuid5(NAMESPACE, tag))


def uv_to_xy(u: float, v: float) -> tuple[float, float]:
    return (round((u - v) / SQRT2, 4), round((u + v) / SQRT2, 4))


def xy_to_uv(x: float, y: float) -> tuple[float, float]:
    return ((x + y) / SQRT2, (y - x) / SQRT2)


@dataclass
class CompSpec:
    ref: str
    value: str
    lib: str
    fp_name: str
    lcsc: str
    desc: str
    subsystem: str
    side: str  # "F" or "B"
    u: float
    v: float
    rot_deg: float  # Orientation in KiCad degrees (CCW)
    pins: dict[str, str]

    @property
    def full_fp(self) -> str:
        return f"{self.lib}:{self.fp_name}"

    @property
    def xy(self) -> tuple[float, float]:
        return uv_to_xy(self.u, self.v)


def write_custom_footprints_and_3d(pcb_dir: Path) -> None:
    """Create project-local OSITO_KODIAK.pretty, 3D shapes, and fp-lib-table."""
    pretty = pcb_dir / "OSITO_KODIAK.pretty"
    shapes = pcb_dir / "OSITO_KODIAK.3dshapes"
    pretty.mkdir(parents=True, exist_ok=True)
    shapes.mkdir(parents=True, exist_ok=True)

    (pcb_dir / "fp-lib-table").write_text(
        '(fp_lib_table\n'
        '  (version 7)\n'
        '  (lib (name "OSITO_KODIAK")(type "KiCad")(uri "${KIPRJMOD}/OSITO_KODIAK.pretty")(options "")(descr "Osito Kodiak Whoop Connectors & Power Stages"))\n'
        ')\n',
        encoding="utf-8",
    )

    # VRML 2.0 3D body helper (1 unit in KiCad VRML = 2.54 mm / 0.1 inch)
    def make_box_wrl(w_mm: float, d_mm: float, h_mm: float, rgb: tuple[float, float, float], z0_mm: float = 0.0) -> str:
        sx, sy, sz = w_mm / 2.54, d_mm / 2.54, h_mm / 2.54
        cz = (z0_mm + h_mm / 2.0) / 2.54
        r, g, b = rgb
        return f"""#VRML V2.0 utf8
Transform {{
  translation 0 0 {cz:.4f}
  children [
    Shape {{
      appearance Appearance {{
        material Material {{
          diffuseColor {r:.3f} {g:.3f} {b:.3f}
          specularColor 0.25 0.25 0.25
          shininess 0.35
        }}
      }}
      geometry Box {{ size {sx:.4f} {sy:.4f} {sz:.4f} }}
    }}
  ]
}}
"""

    (shapes / "JST_1.25mm_1x03_Whoop.wrl").write_text(
        make_box_wrl(5.0, 2.8, 3.4, (0.94, 0.92, 0.86)), encoding="utf-8"
    )
    (shapes / "BT2.0_A30_RA.wrl").write_text(
        make_box_wrl(6.0, 4.2, 3.2, (0.16, 0.38, 0.78)), encoding="utf-8"
    )

    # 1. JST-1.25mm 3-Pin SMD Vertical Motor Socket (LCSC C393945)
    (pretty / "JST_1.25mm_1x03_SMD_Vertical_Whoop.kicad_mod").write_text(
        '''(footprint "JST_1.25mm_1x03_SMD_Vertical_Whoop"
  (version 20241229)
  (generator "pcbnew")
  (layer "F.Cu")
  (descr "3-Pin 1.25mm Pitch Tiny Whoop SMD Vertical Motor Connector (LCSC C393945)")
  (attr smd)
  (fp_text reference "REF**" (at 0 -2.3) (layer "F.SilkS") (effects (font (size 0.65 0.65) (thickness 0.12))))
  (fp_text value "JST-1.25-3P" (at 0 2.3) (layer "F.Fab") (effects (font (size 0.65 0.65) (thickness 0.12))))
  (fp_rect (start -2.6 -1.45) (end 2.6 1.45) (stroke (width 0.12) (type solid)) (fill none) (layer "F.Fab"))
  (fp_line (start -2.7 -1.55) (end -2.0 -1.55) (stroke (width 0.12) (type solid)) (layer "F.SilkS"))
  (fp_line (start 2.0 -1.55) (end 2.7 -1.55) (stroke (width 0.12) (type solid)) (layer "F.SilkS"))
  (fp_line (start -1.5 1.55) (end 1.5 1.55) (stroke (width 0.12) (type solid)) (layer "F.SilkS"))
  (fp_rect (start -3.00 -1.70) (end 3.00 1.70) (stroke (width 0.05) (type solid)) (fill none) (layer "F.CrtYd"))
  (pad "1" smd roundrect (at -1.25 -0.85) (size 0.70 1.30) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25))
  (pad "2" smd roundrect (at 0.0 -0.85) (size 0.70 1.30) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25))
  (pad "3" smd roundrect (at 1.25 -0.85) (size 0.70 1.30) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25))
  (pad "MP" smd roundrect (at -2.35 0.75) (size 0.90 1.40) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25))
  (pad "MP" smd roundrect (at 2.35 0.75) (size 0.90 1.40) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25))
  (model "${KIPRJMOD}/OSITO_KODIAK.3dshapes/JST_1.25mm_1x03_Whoop.wrl"
    (offset (xyz 0 0 0)) (scale (xyz 1 1 1)) (rotate (xyz 0 0 0))
  )
)
''',
        encoding="utf-8",
    )

    # 2. BT2.0 / A30 Right-Angle SMD Male Battery Connector (LCSC C2918210)
    (pretty / "BT2.0_A30_1x02_SMD_RightAngle.kicad_mod").write_text(
        '''(footprint "BT2.0_A30_1x02_SMD_RightAngle"
  (version 20241229)
  (generator "pcbnew")
  (layer "F.Cu")
  (descr "BT2.0 / A30 Right-Angle 1S High-Current SMD Battery Connector (LCSC C2918210)")
  (attr smd)
  (fp_text reference "REF**" (at 0 -2.3) (layer "F.SilkS") (effects (font (size 0.7 0.7) (thickness 0.12))))
  (fp_text value "BT2.0-SMD" (at 0 2.3) (layer "F.Fab") (effects (font (size 0.7 0.7) (thickness 0.12))))
  (fp_rect (start -3.1 -1.7) (end 3.1 1.9) (stroke (width 0.12) (type solid)) (fill none) (layer "F.Fab"))
  (fp_line (start -3.2 -1.8) (end 3.2 -1.8) (stroke (width 0.15) (type solid)) (layer "F.SilkS"))
  (fp_rect (start -3.65 -1.95) (end 3.65 1.95) (stroke (width 0.05) (type solid)) (fill none) (layer "F.CrtYd"))
  (pad "1" smd roundrect (at -1.45 -0.2) (size 1.40 2.50) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.20))
  (pad "2" smd roundrect (at 1.45 -0.2) (size 1.40 2.50) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.20))
  (pad "MP" smd roundrect (at -3.00 0.45) (size 0.90 1.90) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.20))
  (pad "MP" smd roundrect (at 3.00 0.45) (size 0.90 1.90) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.20))
  (model "${KIPRJMOD}/OSITO_KODIAK.3dshapes/BT2.0_A30_RA.wrl"
    (offset (xyz 0 0.3 0)) (scale (xyz 1 1 1)) (rotate (xyz 0 0 0))
  )
)
''',
        encoding="utf-8",
    )

    # 3. Dual N+P Complementary 30V MOSFET DFN-8 2x2mm (FDMA1032CZ / WSD3045DN, LCSC C460384)
    # 1=S1_N (GND), 2=G1_N (Pwm), 3=S2_P (+VBAT), 4=G2_P (Com), 5..8=Common Phase Drain
    (pretty / "DFN-8_DualNP_2x2mm_P0.5mm.kicad_mod").write_text(
        '''(footprint "DFN-8_DualNP_2x2mm_P0.5mm"
  (version 20241229)
  (generator "pcbnew")
  (layer "F.Cu")
  (descr "Dual Complementary N+P MOSFET 2x2mm P0.5mm")
  (attr smd)
  (fp_text reference "REF**" (at 0 -1.55) (layer "F.SilkS") (effects (font (size 0.55 0.55) (thickness 0.10))))
  (fp_text value "DualNP" (at 0 1.55) (layer "F.Fab") (effects (font (size 0.55 0.55) (thickness 0.10))))
  (fp_rect (start -1.0 -1.0) (end 1.0 1.0) (stroke (width 0.10) (type solid)) (fill none) (layer "F.Fab"))
  (fp_rect (start -1.45 -1.25) (end 1.45 1.25) (stroke (width 0.05) (type solid)) (fill none) (layer "F.CrtYd"))
  (pad "1" smd roundrect (at -0.95 -0.75) (size 0.65 0.28) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25))
  (pad "2" smd roundrect (at -0.95 -0.25) (size 0.65 0.28) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25))
  (pad "3" smd roundrect (at -0.95 0.25) (size 0.65 0.28) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25))
  (pad "4" smd roundrect (at -0.95 0.75) (size 0.65 0.28) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25))
  (pad "5" smd roundrect (at 0.95 0.75) (size 0.65 0.28) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25))
  (pad "6" smd roundrect (at 0.95 0.25) (size 0.65 0.28) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25))
  (pad "7" smd roundrect (at 0.95 -0.25) (size 0.65 0.28) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25))
  (pad "8" smd roundrect (at 0.95 -0.75) (size 0.65 0.28) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25))
  (model "${KICAD10_3DMODEL_DIR}/Package_DFN_QFN.3dshapes/DFN-8-1EP_2x2mm_P0.5mm_EP0.9x1.6mm.step"
    (offset (xyz 0 0 0)) (scale (xyz 1 1 1)) (rotate (xyz 0 0 0))
  )
)
''',
        encoding="utf-8",
    )


def build_components() -> list[CompSpec]:
    comps: list[CompSpec] = []

    # =========================================================================
    # TOP SIDE (F.Cu): MCU, Gyro, Hall Hit Sensor, ELRS 2.4GHz, 10x RGB LEDs,
    #                  and ALL 8 Plug-and-Play Connectors (Zero Bottom Pins!)
    # =========================================================================

    # U1: STM32G473CEU6 (UFQFPN-48, 7x7mm, BETAFPVG473 exact pin map)
    u1_pins = {str(i): "" for i in range(1, 50)}
    u1_pins.update({
        "1": "+3V3_MCU",       # VBAT
        "2": "M4_DSHOT_RAW",   # PC13 -> MOTOR 4
        "5": "HSE_IN",         # PF0
        "6": "HSE_OUT",        # PF1
        "7": "MCU_NRST",       # PG10-NRST
        "8": "ADC_VBAT",       # PA0 -> ADC_BATT
        "9": "ADC_CURR",       # PA1 -> ADC_CURR
        "10": "UART2_TX",      # PA2 -> SmartAudio VTX
        "11": "",              # PA3 (Unused)
        "12": "GYRO_CS",       # PA4 -> SPI1 CS
        "13": "SPI1_SCK",      # PA5
        "14": "SPI1_MISO",     # PA6
        "15": "SPI1_MOSI",     # PA7
        "16": "GYRO_EXTI",     # PC4 -> ICM-42688 INT1
        "17": "M1_DSHOT_RAW",  # PB0 -> MOTOR 1
        "18": "M2_DSHOT_RAW",  # PB1 -> MOTOR 2
        "19": "LED_PWM_RAW",   # PB2 -> LED_STRIP
        "20": "+3V3_MCU",      # VREF+
        "21": "+3V3_MCU",      # VDDA
        "22": "ELRS_RX_IN",    # PB10 -> UART3_TX -> ESP8285 RX
        "23": "+3V3_MCU",      # VDD
        "24": "ELRS_TX_OUT",   # PB11 -> UART3_RX <- ESP8285 TX
        "25": "OSD_CS",        # PB12 -> MAX7456_CS
        "26": "SPI2_SCK",      # PB13
        "27": "SPI2_MISO",     # PB14
        "28": "SPI2_MOSI",     # PB15
        "29": "HIT_DETECT",    # PC6 <- DRV5032FA OUT
        "33": "USB_DM",        # PA11
        "34": "USB_DP",        # PA12
        "35": "+3V3_MCU",      # VDD
        "44": "M3_DSHOT_RAW",  # PB6 -> MOTOR 3
        "46": "MCU_BOOT0",     # PB8-BOOT0 -> 10k to GND
        "48": "+3V3_MCU",      # VDD
        "49": "GND",           # VSS Exposed Pad
    })
    comps.append(CompSpec(
        "U1", "STM32G473CEU6", "Package_DFN_QFN", "QFN-48-1EP_7x7mm_P0.5mm_EP5.6x5.6mm",
        "C529326", "170MHz ARM Cortex-M4F 512KB Flash MCU (BETAFPVG473)", "Flight Controller MCU",
        "F", 0.0, -1.00, 45.0, u1_pins
    ))

    # Y1: 8.000MHz Crystal + C_Y1A, C_Y1B (15pF C0G) + R_BOOT + C_NRST + MCU Decoupling
    comps.append(CompSpec(
        "Y1", "8.000MHz", "Crystal", "Crystal_SMD_3225-4Pin_3.2x2.5mm",
        "C9002", "8.000MHz 10ppm SMD Crystal", "Flight Controller MCU",
        "F", -6.2, -1.2, 45.0, {"1": "HSE_IN", "2": "GND", "3": "HSE_OUT", "4": "GND"}
    ))
    comps.append(CompSpec(
        "C_Y1A", "15pF_50V_C0G", "Capacitor_SMD", "C_0402_1005Metric",
        "C1548", "15pF 50V C0G 0402 Crystal Load Capacitor", "Flight Controller MCU",
        "F", -6.2, -4.4, 45.0, {"1": "HSE_IN", "2": "GND"}
    ))
    comps.append(CompSpec(
        "C_Y1B", "15pF_50V_C0G", "Capacitor_SMD", "C_0402_1005Metric",
        "C1548", "15pF 50V C0G 0402 Crystal Load Capacitor", "Flight Controller MCU",
        "F", -4.8, -4.4, 45.0, {"1": "HSE_OUT", "2": "GND"}
    ))
    comps.append(CompSpec(
        "R_BOOT", "10k_1%", "Resistor_SMD", "R_0402_1005Metric",
        "C25744", "10kOhm 1% 0402 BOOT0 Pull-Down Resistor", "Flight Controller MCU",
        "F", -4.8, 2.0, 45.0, {"1": "MCU_BOOT0", "2": "GND"}
    ))
    comps.append(CompSpec(
        "C_NRST", "100nF_16V_X7R", "Capacitor_SMD", "C_0402_1005Metric",
        "C1525", "100nF 16V X7R 0402 NRST Filter Capacitor", "Flight Controller MCU",
        "F", -3.65, -6.10, 45.0, {"1": "MCU_NRST", "2": "GND"}
    ))
    for idx, (cu, cv) in enumerate([(4.8, -5.0), (4.8, -3.0), (4.8, -1.0), (-4.8, 4.2)], start=1):
        comps.append(CompSpec(
            f"C_MCU{idx}", "100nF_16V_X7R", "Capacitor_SMD", "C_0402_1005Metric",
            "C1525", "100nF 16V X7R 0402 MCU Decoupling Capacitor", "Decoupling",
            "F", cu, cv, 45.0, {"1": "+3V3_MCU", "2": "GND"}
        ))
    comps.append(CompSpec(
        "C_VDDA", "10uF_10V_X7R", "Capacitor_SMD", "C_0603_1608Metric",
        "C96446", "10uF 10V X7R 0603 MCU Analog VDDA Filter Capacitor", "Decoupling",
        "F", 5.0, 1.5, 45.0, {"1": "+3V3_MCU", "2": "GND"}
    ))

    # U2: ICM-42688-P (LGA-14 3x2.5mm, CW180 = 180 deg) + U6_GYRO (RT9013-33GB)
    u2_pins = {str(i): "" for i in range(1, 15)}
    u2_pins.update({
        "1": "SPI1_MISO", "4": "GYRO_CS", "5": "SPI1_SCK", "6": "SPI1_MOSI",
        "8": "GYRO_EXTI", "10": "GND", "11": "GND", "12": "GND",
        "13": "+3V3_GYRO", "14": "+3V3_GYRO",
    })
    comps.append(CompSpec(
        "U2", "ICM-42688-P", "Package_LGA", "Bosch_LGA-14_3x2.5mm_P0.5mm",
        "C2878339", "High-Precision 6-Axis SPI MEMS IMU", "Gyro & IMU",
        "F", -0.75, -8.25, 45.0, u2_pins
    ))
    comps.append(CompSpec(
        "U6_GYRO", "RT9013-33GB", "Package_TO_SOT_SMD", "SOT-23-5",
        "C47773", "3.3V 500mA Ultra-Low-Noise Dedicated Gyro LDO", "3.3V LDO Power",
        "F", 3.60, -8.20, 45.0,
        {"1": "+5V_BEC", "2": "GND", "3": "+5V_BEC", "4": "", "5": "+3V3_GYRO"}
    ))
    comps.append(CompSpec(
        "C_GYRO1", "10uF_10V_X7R", "Capacitor_SMD", "C_0603_1608Metric",
        "C96446", "10uF 10V X7R 0603 Gyro LDO Output Capacitor", "Gyro & IMU",
        "F", 6.8, -8.6, 45.0, {"1": "+3V3_GYRO", "2": "GND"}
    ))
    comps.append(CompSpec(
        "C_GYRO2", "100nF_16V_X7R", "Capacitor_SMD", "C_0402_1005Metric",
        "C1525", "100nF 16V X7R 0402 Gyro Local Bypass Capacitor", "Gyro & IMU",
        "F", -3.60, -8.20, 45.0, {"1": "+3V3_GYRO", "2": "GND"}
    ))

    # U8: DRV5032FADBZR Omnipolar Hall Armor Hit Sensor (Nose apex, near N52 crown magnet)
    comps.append(CompSpec(
        "U8", "DRV5032FADBZR", "Package_TO_SOT_SMD", "SOT-23",
        "C131144", "Omnipolar Digital Hall-Effect Magnetic Armor Hit Sensor", "Armor Hit Sensor",
        "F", -8.0, -9.2, 45.0, {"1": "+3V3_MCU", "2": "HIT_DETECT", "3": "GND"}
    ))
    comps.append(CompSpec(
        "C_HALL", "100nF_16V_X7R", "Capacitor_SMD", "C_0402_1005Metric",
        "C1525", "100nF 16V X7R 0402 Hall Sensor Bypass Capacitor", "Armor Hit Sensor",
        "F", -5.20, -8.60, 45.0, {"1": "+3V3_MCU", "2": "GND"}
    ))

    # ELRS 2.4GHz Subsystem: U5 (ESP8285H16 QFN-32) + U7 (SX1281IMLTRT QFN-24) + Y2 + ANT1
    u5_pins = {str(i): "" for i in range(1, 34)}
    u5_pins.update({
        "1": "+3V3_MCU", "3": "+3V3_MCU", "4": "+3V3_MCU", "7": "ELRS_EN",
        "9": "ELRS_SCK", "10": "ELRS_MISO", "11": "+3V3_MCU", "12": "ELRS_MOSI",
        "13": "ELRS_NSS", "14": "ELRS_NRST", "16": "ELRS_DIO1", "17": "+3V3_MCU",
        "24": "ELRS_BUSY", "25": "ELRS_RX_IN", "26": "ELRS_TX_OUT",
        "29": "+3V3_MCU", "30": "+3V3_MCU", "33": "GND",
    })
    comps.append(CompSpec(
        "U5", "ESP8285H16", "Package_DFN_QFN", "QFN-32-1EP_5x5mm_P0.5mm_EP3.45x3.45mm",
        "C119586", "ExpressLRS 2.4GHz Wi-Fi / CRSF Receiver SoC", "ELRS 2.4G Receiver",
        "F", 0.00, 7.25, 45.0, u5_pins
    ))

    u7_pins = {str(i): "" for i in range(1, 26)}
    u7_pins.update({
        "1": "ELRS_VR_PA", "2": "+3V3_MCU", "3": "ELRS_NRST", "4": "ELRS_XTA",
        "5": "GND", "6": "ELRS_XTB", "7": "ELRS_BUSY", "8": "ELRS_DIO1",
        "11": "+3V3_MCU", "12": "+3V3_MCU", "13": "GND", "14": "+3V3_MCU",
        "15": "+3V3_MCU", "16": "ELRS_MISO", "17": "ELRS_MOSI", "18": "ELRS_SCK",
        "19": "ELRS_NSS", "20": "GND", "21": "ELRS_RFIO", "22": "GND",
        "23": "GND", "24": "GND", "25": "GND",
    })
    comps.append(CompSpec(
        "U7", "SX1281IMLTRT", "Package_DFN_QFN", "QFN-24-1EP_4x4mm_P0.5mm_EP2.6x2.6mm",
        "C394238", "Semtech 2.4GHz LoRa / FLRC ExpressLRS RF Transceiver", "ELRS 2.4G Receiver",
        "F", -6.25, 7.75, 45.0, u7_pins
    ))
    comps.append(CompSpec(
        "Y2", "52.000MHz", "Crystal", "Crystal_SMD_2016-4Pin_2.0x1.6mm",
        "C2761957", "52.000MHz 10ppm SMD RF Crystal for SX1281", "ELRS 2.4G Receiver",
        "F", -6.8, 3.0, 45.0, {"1": "ELRS_XTA", "2": "GND", "3": "ELRS_XTB", "4": "GND"}
    ))
    comps.append(CompSpec(
        "C_RF", "100pF_50V_C0G", "Capacitor_SMD", "C_0402_1005Metric",
        "C1546", "100pF 50V C0G 0402 2.4GHz RF DC-Block Capacitor", "ELRS 2.4G Receiver",
        "F", -10.25, 6.00, 45.0, {"1": "ELRS_RFIO", "2": "ELRS_ANT_FEED"}
    ))
    comps.append(CompSpec(
        "ANT1", "2450AT18B100", "RF_Antenna", "Johanson_2450AT18x100",
        "C293768", "2.4GHz SMD Ceramic Chip Antenna (Internal Prop-Safe)", "ELRS 2.4G Receiver",
        "F", -12.3, 7.5, 45.0, {"1": "ELRS_ANT_FEED", "2": "GND"}
    ))
    comps.append(CompSpec(
        "C_VRPA", "100nF_16V_X7R", "Capacitor_SMD", "C_0402_1005Metric",
        "C1525", "100nF 16V X7R 0402 SX1281 VR_PA Capacitor", "ELRS 2.4G Receiver",
        "F", -10.25, 9.00, 45.0, {"1": "ELRS_VR_PA", "2": "GND"}
    ))
    comps.append(CompSpec(
        "C_ELRS1", "100nF_16V_X7R", "Capacitor_SMD", "C_0402_1005Metric",
        "C1525", "100nF 16V X7R 0402 ESP8285 Decoupling Capacitor", "ELRS 2.4G Receiver",
        "F", 5.00, 5.25, 45.0, {"1": "+3V3_MCU", "2": "GND"}
    ))
    comps.append(CompSpec(
        "R_ELRS_EN", "10k_1%", "Resistor_SMD", "R_0402_1005Metric",
        "C25744", "10kOhm 1% 0402 ESP8285 CHIP_EN Pull-Up", "ELRS 2.4G Receiver",
        "F", 4.75, 7.25, 45.0, {"1": "ELRS_EN", "2": "+3V3_MCU"}
    ))
    comps.append(CompSpec(
        "R_ELRS_CS", "10k_1%", "Resistor_SMD", "R_0402_1005Metric",
        "C25744", "10kOhm 1% 0402 ESP8285 GPIO15 Strapping Pull-Down", "ELRS 2.4G Receiver",
        "F", 6.25, 7.25, 45.0, {"1": "ELRS_NSS", "2": "GND"}
    ))

    # 10x Onboard WS2812B-2020 Addressable RGB LEDs (1=DOUT, 2=VSS, 3=DIN, 4=VDD)
    comps.append(CompSpec(
        "R_LED", "330R", "Resistor_SMD", "R_0402_1005Metric",
        "C25104", "330Ohm 0402 WS2812B Data Line Protection Resistor", "Onboard RGB LEDs",
        "F", -5.25, -6.50, 45.0, {"1": "LED_PWM_RAW", "2": "LED_D0"}
    ))
    led_coords = [
        # Front-Left (M4 Nose)
        ("LED1", -8.8, -5.4, 45.0),
        ("LED2", 6.65, -5.2, 45.0),
        # Center-Front Canopy Glow
        ("LED9", -4.8, -12.1, 45.0),
        ("LED10", -1.6, -12.1, 45.0),
        # Front-Right (M2 Nose)
        ("LED3", 9.6, -11.4, 45.0),
        ("LED4", 9.2, -5.2, 45.0),
        # Rear-Right (M1 Team Tail)
        ("LED5", 7.25, 3.25, 45.0),
        ("LED6", 8.50, 7.25, 45.0),
        # Rear-Left (M3 Team Tail)
        ("LED7", 1.20, 12.10, 45.0),
        ("LED8", -1.80, 12.10, 45.0),
    ]
    for idx, (lref, lu, lv, lrot) in enumerate(led_coords):
        din = f"LED_D{idx}"
        dout = f"LED_D{idx + 1}"
        comps.append(CompSpec(
            lref, "WS2812B-2020", "LED_SMD", "LED_WS2812B-2020_PLCC4_2.0x2.0mm",
            "C965555", "Addressable RGB Smart LED 2.0x2.0mm", "Onboard RGB LEDs",
            "F", lu, lv, lrot, {"1": dout, "2": "GND", "3": din, "4": "+5V_BEC"}
        ))

    # 4x Plug-and-Play 3-Pin Motor Sockets along the 4 Cardinal Diamond Motor Edges
    # Note: In KiCad CCW degrees, rot=+45/-135 aligns long axis along v (constant-u edge),
    # and rot=-45/+135 aligns long axis along u (constant-v edge).
    motor_headers = [
        ("J_M1", 12.2, -6.8, 45.0, "1"),    # Rear-Right  (u = +14.2)
        ("J_M2", 5.0, -12.1, 135.0, "2"),   # Front-Right (v = -14.2)
        ("J_M3", -6.6, 12.1, -45.0, "3"),   # Rear-Left   (v = +14.2)
        ("J_M4", -12.1, -6.8, -135.0, "4"), # Front-Left  (u = -14.2)
    ]
    for jref, ju, jv, jrot, mch in motor_headers:
        comps.append(CompSpec(
            jref, "JST-1.25-3P", "OSITO_KODIAK", "JST_1.25mm_1x03_SMD_Vertical_Whoop",
            "C393945", f"3-Pin 1.25mm SMD Vertical Motor {mch} Socket", "Motor Sockets",
            "F", ju, jv, jrot,
            {"1": f"M{mch}_PHA", "2": f"M{mch}_PHB", "3": f"M{mch}_PHC", "MP": "GND"}
        ))

    # Top-Entry Peripheral Connectors & Right-Angle BT2.0 Battery Socket
    comps.append(CompSpec(
        "J_USB", "JST-SH-4P-USB", "Connector_JST", "JST_SH_BM04B-SRSS-TB_1x04-1MP_P1.00mm_Vertical",
        "C160404", "4-Pin 1.0mm JST-SH Side/Top USB-C Dongle Port", "Peripheral Ports",
        "F", 9.8, -1.0, 135.0,
        {"1": "+5V_USB", "2": "USB_DM_EXT", "3": "USB_DP_EXT", "4": "GND", "MP": "GND"}
    ))
    comps.append(CompSpec(
        "J_CAM", "JST-SH-5P-FPV", "Connector_JST", "JST_SH_BM05B-SRSS-TB_1x05-1MP_P1.00mm_Vertical",
        "C160405", "5-Pin 1.0mm JST-SH FPV Camera + VTX + SmartAudio Pod Port", "Peripheral Ports",
        "F", -11.0, 0.7, 45.0,
        {"1": "+5V_BEC", "2": "GND", "3": "CAM_RAW", "4": "VTX_VIDEO", "5": "UART2_TX", "MP": "GND"}
    ))
    comps.append(CompSpec(
        "J_LED_EXT", "JST-SH-3P-LED", "Connector_JST", "JST_SH_BM03B-SRSS-TB_1x03-1MP_P1.00mm_Vertical",
        "C160403", "3-Pin 1.0mm JST-SH External LED Halo Port", "Plug-and-Play LED Port",
        "F", 6.6, 11.5, 135.0,
        {"1": "+5V_BEC", "2": "GND", "3": "LED_D10", "MP": "GND"}
    ))
    comps.append(CompSpec(
        "J_BAT", "BT2.0-A30-SMD", "OSITO_KODIAK", "BT2.0_A30_1x02_SMD_RightAngle",
        "C2918210", "Right-Angle SMD High-Current 1S Battery Connector (BT2.0/A30)", "Plug-and-Play Battery Port",
        "F", 12.0, 5.8, 45.0,
        {"1": "+VBAT_RAW", "2": "GND", "MP": "GND"}
    ))

    # =========================================================================
    # BOTTOM SIDE (B.Cu): Ultra-Low-Profile (<= 1.1mm) 12A 4-in-1 Bluejay ESC,
    #                     TPS63020 5V 2A BEC, Shunt Amp, USB ESD, & AT7456E OSD
    # =========================================================================

    # U9: AT7456E Analog OSD (HTSSOP-28-1EP 4.4x9.7mm, exact MAX7456/AT7456E pinout)
    u9_pins = {str(i): "" for i in range(1, 30)}
    u9_pins.update({
        "1": "OSD_VIN",        # VIN (AC-coupled via C_VIN 100nF from CAM_RAW)
        "3": "+5V_BEC",        # DVDD
        "4": "GND",            # DGND
        "5": "OSD_X1",         # CLKIN (27.000MHz Y3)
        "6": "OSD_X2",         # XFB   (27.000MHz Y3)
        "8": "OSD_CS",         # /CS
        "9": "SPI2_MOSI",      # SDIN
        "10": "SPI2_SCK",      # SCLK
        "11": "SPI2_MISO",     # SDOUT
        "16": "OSD_NRST",      # /RESET (Active-low, 10k pull-up to +5V_BEC)
        "17": "GND",           # DGND
        "18": "+5V_BEC",       # DVDD
        "19": "GND",           # AGND
        "20": "+5V_BEC",       # AVDD
        "21": "+5V_BEC",       # AVDD
        "22": "GND",           # AGND
        "23": "GND",           # PGND
        "24": "+5V_BEC",       # PVDD
        "25": "VTX_VIDEO",     # SAG (Sag-compensation sense after C_VOUT)
        "26": "OSD_VOUT",      # VOUT (AC-coupled via C_VOUT 22uF to VTX_VIDEO)
        "29": "GND",           # Exposed Thermal Pad
    })
    comps.append(CompSpec(
        "U9", "AT7456E", "Package_SO", "HTSSOP-28-1EP_4.4x9.7mm_P0.65mm_EP2.85x5.4mm",
        "C59394", "Analog MAX7456-Compatible Betaflight OSD Generator", "FPV OSD",
        "B", 0.0, -1.2, 45.0, u9_pins
    ))
    comps.append(CompSpec(
        "Y3", "27.000MHz", "Crystal", "Crystal_SMD_2016-4Pin_2.0x1.6mm",
        "C251566", "27.000MHz 10ppm SMD OSD Subcarrier Crystal", "FPV OSD",
        "B", -7.0, -1.2, 45.0, {"1": "OSD_X1", "2": "GND", "3": "OSD_X2", "4": "GND"}
    ))
    comps.append(CompSpec(
        "C_Y3A", "15pF_50V_C0G", "Capacitor_SMD", "C_0402_1005Metric",
        "C1548", "15pF 50V C0G 0402 OSD Crystal Load Capacitor", "FPV OSD",
        "B", -9.2, -2.0, 45.0, {"1": "OSD_X1", "2": "GND"}
    ))
    comps.append(CompSpec(
        "C_Y3B", "15pF_50V_C0G", "Capacitor_SMD", "C_0402_1005Metric",
        "C1548", "15pF 50V C0G 0402 OSD Crystal Load Capacitor", "FPV OSD",
        "B", -9.6, 0.2, 45.0, {"1": "OSD_X2", "2": "GND"}
    ))
    comps.append(CompSpec(
        "R_OSD_RST", "10k_1%", "Resistor_SMD", "R_0402_1005Metric",
        "C25744", "10kOhm 1% 0402 AT7456E /RESET Pull-Up Resistor", "FPV OSD",
        "B", 5.65, 3.0, 45.0, {"1": "OSD_NRST", "2": "+5V_BEC"}
    ))
    comps.append(CompSpec(
        "C_OSD", "100nF_16V_X7R", "Capacitor_SMD", "C_0402_1005Metric",
        "C1525", "100nF 16V X7R 0402 OSD Decoupling Capacitor", "FPV OSD",
        "B", 5.65, -1.2, 45.0, {"1": "+5V_BEC", "2": "GND"}
    ))
    comps.append(CompSpec(
        "C_VIN", "100nF_16V_X7R", "Capacitor_SMD", "C_0402_1005Metric",
        "C1525", "100nF 16V X7R 0402 Camera CVBS Input AC-Coupling Capacitor", "FPV OSD",
        "B", -5.9, 1.6, 45.0, {"1": "CAM_RAW", "2": "OSD_VIN"}
    ))
    comps.append(CompSpec(
        "C_VOUT", "22uF_10V_X7S", "Capacitor_SMD", "C_0805_2012Metric",
        "C342725", "22uF 10V X7S 0805 Sag-Compensated Video Output Coupling Capacitor", "FPV OSD",
        "B", -7.8, 2.0, 45.0, {"1": "OSD_VOUT", "2": "VTX_VIDEO"}
    ))

    # U3: TPS63020DSJR 5V 2A Buck-Boost (TI SLVS916I exact DSJ pinout)
    u3_pins = {
        "1": "+VBAT",      # VINA
        "2": "GND",        # GND
        "3": "BEC_FB",     # FB (0.5V ref)
        "4": "+5V_BEC",    # VOUT
        "5": "+5V_BEC",    # VOUT
        "6": "BEC_L2",     # L2
        "7": "BEC_L2",     # L2
        "8": "BEC_L1",     # L1
        "9": "BEC_L1",     # L1
        "10": "+VBAT",     # VIN
        "11": "+VBAT",     # VIN
        "12": "+VBAT",     # EN
        "13": "+VBAT",     # PS/SYNC (Forced PWM)
        "14": "",          # PG (Open-Drain NC)
        "15": "GND",       # Exposed Thermal Pad (PGND)
    }
    comps.append(CompSpec(
        "U3", "TPS63020DSJR", "Package_SON", "VSON-14-1EP_3x4.45mm_P0.65mm_EP1.6x4.2mm",
        "C15495", "1S Buck-Boost 5.0V 2.0A Regulator", "5V BEC Power",
        "B", 0.0, 5.4, 45.0, u3_pins
    ))
    comps.append(CompSpec(
        "L1", "1.5uH_4.2A", "Inductor_SMD", "L_1008_2520Metric",
        "C86066", "1.5uH 4.2A Shielded Power Inductor", "5V BEC Power",
        "B", -4.2, 5.4, 45.0, {"1": "BEC_L1", "2": "BEC_L2"}
    ))
    comps.append(CompSpec(
        "C_BEC_IN", "10uF_10V_X7R", "Capacitor_SMD", "C_0603_1608Metric",
        "C96446", "10uF 10V X7R 0603 BEC Input Capacitor", "5V BEC Power",
        "B", 3.6, 4.6, 45.0, {"1": "+VBAT", "2": "GND"}
    ))
    comps.append(CompSpec(
        "C_BEC_O1", "10uF_10V_X7R", "Capacitor_SMD", "C_0603_1608Metric",
        "C96446", "10uF 10V X7R 0603 BEC Output Capacitor 1", "5V BEC Power",
        "B", 3.6, 8.0, 45.0, {"1": "+5V_BEC", "2": "GND"}
    ))
    comps.append(CompSpec(
        "C_BEC_O2", "10uF_10V_X7R", "Capacitor_SMD", "C_0603_1608Metric",
        "C96446", "10uF 10V X7R 0603 BEC Output Capacitor 2", "5V BEC Power",
        "B", 5.4, 8.0, 45.0, {"1": "+5V_BEC", "2": "GND"}
    ))
    comps.append(CompSpec(
        "C_VINA", "100nF_16V_X7R", "Capacitor_SMD", "C_0402_1005Metric",
        "C1525", "100nF 16V X7R 0402 TPS63020 VINA Filter", "5V BEC Power",
        "B", 1.6, 8.8, 45.0, {"1": "+VBAT", "2": "GND"}
    ))
    comps.append(CompSpec(
        "R_FB1", "910k_1%", "Resistor_SMD", "R_0402_1005Metric",
        "C25798", "910kOhm 1% 0402 BEC Feedback Upper Resistor (5.05V)", "5V BEC Power",
        "B", 0.0, 8.8, 45.0, {"1": "+5V_BEC", "2": "BEC_FB"}
    ))
    comps.append(CompSpec(
        "R_FB2", "100k_1%", "Resistor_SMD", "R_0402_1005Metric",
        "C25741", "100kOhm 1% 0402 BEC Feedback Lower Resistor", "5V BEC Power",
        "B", -1.6, 8.8, 45.0, {"1": "BEC_FB", "2": "GND"}
    ))

    # U6_MCU: 3.3V Digital LDO + Output Cap
    comps.append(CompSpec(
        "U6_MCU", "RT9013-33GB", "Package_TO_SOT_SMD", "SOT-23-5",
        "C47773", "3.3V 500mA Digital & ESC MCU LDO Regulator", "3.3V LDO Power",
        "B", -0.6, 12.0, 135.0,
        {"1": "+5V_BEC", "2": "GND", "3": "+5V_BEC", "4": "", "5": "+3V3_MCU"}
    ))
    comps.append(CompSpec(
        "C_LDO_M", "10uF_10V_X7R", "Capacitor_SMD", "C_0603_1608Metric",
        "C96446", "10uF 10V X7R 0603 MCU LDO Output Capacitor", "3.3V LDO Power",
        "B", -3.8, 11.6, 45.0, {"1": "+3V3_MCU", "2": "GND"}
    ))

    # Shunt Telemetry & VBAT Bulk Filtering (X7S 105C)
    comps.append(CompSpec(
        "R_SHUNT", "0.5mR_1W", "Resistor_SMD", "R_1206_3216Metric",
        "C25152", "0.5mOhm 1W 1206 Current Sense Shunt Resistor", "Current Sensor",
        "B", 11.6, 5.8, 45.0, {"1": "+VBAT_RAW", "2": "+VBAT"}
    ))
    comps.append(CompSpec(
        "U10", "INA199A1DCKR", "Package_TO_SOT_SMD", "SOT-363_SC-70-6",
        "C132187", "50V/V Bidirectional Current-Shunt Monitor", "Current Sensor",
        "B", 6.8, 11.6, 45.0,
        {"1": "GND", "2": "GND", "3": "+3V3_MCU", "4": "+VBAT_RAW", "5": "+VBAT", "6": "ADC_CURR"}
    ))
    comps.append(CompSpec(
        "C_BULK1", "22uF_10V_X7S", "Capacitor_SMD", "C_0805_2012Metric",
        "C342725", "22uF 10V X7S 0805 High-Temp Bulk VBAT Capacitor", "Power Filtering",
        "B", 9.2, 5.0, 45.0, {"1": "+VBAT", "2": "GND"}
    ))
    comps.append(CompSpec(
        "C_BULK2", "22uF_10V_X7S", "Capacitor_SMD", "C_0805_2012Metric",
        "C342725", "22uF 10V X7S 0805 High-Temp Bulk VBAT Capacitor", "Power Filtering",
        "B", 9.2, 8.8, 45.0, {"1": "+VBAT", "2": "GND"}
    ))
    comps.append(CompSpec(
        "R_VBAT1", "10k_1%", "Resistor_SMD", "R_0402_1005Metric",
        "C25744", "10kOhm 1% 0402 VBAT Divider Upper", "Current Sensor",
        "B", 2.6, 11.6, 45.0, {"1": "+VBAT", "2": "ADC_VBAT"}
    ))
    comps.append(CompSpec(
        "R_VBAT2", "10k_1%", "Resistor_SMD", "R_0402_1005Metric",
        "C25744", "10kOhm 1% 0402 VBAT Divider Lower", "Current Sensor",
        "B", 4.0, 11.6, 45.0, {"1": "ADC_VBAT", "2": "GND"}
    ))

    # USB ESD Array (D1 USBLC6-2SC6) + USB Power Schottky (D_USB MBR0520)
    comps.append(CompSpec(
        "D1", "USBLC6-2SC6", "Package_TO_SOT_SMD", "SOT-23-6",
        "C7519", "USB 2.0 Low-Capacitance ESD Protection Array", "Peripheral Ports",
        "B", 7.9, 0.4, 45.0,
        {"1": "USB_DM_EXT", "2": "GND", "3": "USB_DP_EXT", "4": "USB_DP", "5": "+5V_USB", "6": "USB_DM"}
    ))
    comps.append(CompSpec(
        "D_USB", "MBR0520", "Diode_SMD", "D_SOD-323",
        "C8598", "20V 0.5A Schottky Barrier Diode (USB VBUS OR-ing)", "Peripheral Ports",
        "B", 7.2, 4.8, 45.0, {"1": "+5V_BEC", "2": "+5V_USB"}  # SOD-323: 1=Cathode(K), 2=Anode(A)
    ))

    # 4-Channel 12A Brushless Bluejay O-H-5 ESC Quadrants on B.Cu
    esc_quadrants = [
        # (ch, (u_mcu, v_mcu), [(qu, qv, qrot)*3], (rds_u, rds_v, rds_rot), (cesc_u, cesc_v, cesc_rot), [(rbu, rbv, rbrot)*3])
        (
            "1", (8.25, -5.25),
            [(12.25, -8.50, 45.0), (12.25, -5.25, 45.0), (12.25, -2.00, 45.0)],
            (5.8, -8.8, 45.0), (9.6, -8.8, 45.0),
            [(7.0, -8.8, 45.0), (8.2, -8.8, 45.0), (10.2, 0.2, 45.0)],
        ),
        (
            "2", (2.75, -8.25),
            [(8.50, -12.25, 135.0), (5.25, -12.25, 135.0), (2.00, -12.25, 135.0)],
            (-0.8, -7.0, 135.0), (-0.8, -8.4, 135.0),
            [(-0.8, -9.8, 135.0), (-0.8, -11.2, 135.0), (-0.8, -12.6, 135.0)],
        ),
        (
            "3", (-8.25, 8.75),
            [(-12.25, 2.25, 45.0), (-12.25, 5.50, 45.0), (-8.25, 12.50, 135.0)],
            (-6.2, 4.4, 45.0), (-9.8, 4.4, 45.0),
            [(-11.2, 8.8, 45.0), (-5.2, 11.4, 45.0), (-4.6, 8.8, 45.0)],
        ),
        (
            "4", (-8.00, -7.75),
            [(-12.25, -8.50, 45.0), (-12.25, -5.25, 45.0), (-12.25, -2.00, 45.0)],
            (-3.0, -7.8, 45.0), (-4.4, -7.8, 45.0),
            [(-9.4, -11.4, 45.0), (-8.0, -11.4, 45.0), (-6.6, -11.4, 45.0)],
        ),
    ]

    for ch, (um, vm), q_specs, (rdsu, rdsv, rdsrot), (cescu, cescv, cescrot), rb_specs in esc_quadrants:
        efm_pins = {str(i): "" for i in range(1, 22)}
        efm_pins.update({
            "1": f"M{ch}_PHC",       # P0.1 = C_Mux
            "2": f"M{ch}_PHB",       # P0.0 = B_Mux
            "3": "GND",
            "4": "+3V3_MCU",         # VDD
            "8": f"M{ch}_C_COM",     # P1.5 = C_Com (P-FET Gate)
            "9": f"M{ch}_C_PWM",     # P1.4 = C_Pwm (N-FET Gate)
            "10": f"M{ch}_B_COM",    # P1.3 = B_Com
            "11": f"M{ch}_B_PWM",    # P1.2 = B_Pwm
            "12": "GND",
            "13": f"M{ch}_A_COM",    # P1.1 = A_Com
            "14": f"M{ch}_A_PWM",    # P1.0 = A_Pwm
            "17": f"M{ch}_DSHOT",    # P0.5 = RTX_PIN
            "19": f"M{ch}_VMUX",     # P0.3 = V_Mux (Virtual Neutral Star)
            "20": f"M{ch}_PHA",      # P0.2 = A_Mux
            "21": "GND",             # Exposed Pad
        })
        comps.append(CompSpec(
            f"U4_M{ch}", "EFM8BB21F16G", "Package_DFN_QFN", "SiliconLabs_QFN-20-1EP_3x3mm_P0.5mm_EP1.8x1.8mm",
            "C94603", f"50MHz Bluejay O-H-5 48kHz Motor {ch} ESC MCU", "12A 4-in-1 ESC",
            "B", um, vm, 45.0, efm_pins
        ))
        comps.append(CompSpec(
            f"R_DS{ch}", "330R", "Resistor_SMD", "R_0402_1005Metric",
            "C25104", f"330Ohm 0402 Motor {ch} BiDir DShot Line Resistor", "12A 4-in-1 ESC",
            "B", rdsu, rdsv, rdsrot,
            {"1": f"M{ch}_DSHOT_RAW", "2": f"M{ch}_DSHOT"}
        ))
        comps.append(CompSpec(
            f"C_ESC{ch}", "100nF_16V_X7R", "Capacitor_SMD", "C_0402_1005Metric",
            "C1525", f"100nF 16V X7R 0402 ESC {ch} MCU Bypass Capacitor", "12A 4-in-1 ESC",
            "B", cescu, cescv, cescrot,
            {"1": "+3V3_MCU", "2": "GND"}
        ))

        base_q = (int(ch) - 1) * 3
        for pidx, ph_letter in enumerate(("A", "B", "C")):
            q_num = base_q + pidx + 1
            qu, qv, qrot = q_specs[pidx]
            comps.append(CompSpec(
                f"Q{q_num}", "FDMA1032CZ_DualNP", "OSITO_KODIAK", "DFN-8_DualNP_2x2mm_P0.5mm",
                "C460384", f"30V Complementary N+P Half-Bridge MOSFET (M{ch} Phase {ph_letter})", "12A 4-in-1 ESC",
                "B", qu, qv, qrot,
                {
                    "1": "GND",
                    "2": f"M{ch}_{ph_letter}_PWM",
                    "3": "+VBAT",
                    "4": f"M{ch}_{ph_letter}_COM",
                    "5": f"M{ch}_PH{ph_letter}",
                    "6": f"M{ch}_PH{ph_letter}",
                    "7": f"M{ch}_PH{ph_letter}",
                    "8": f"M{ch}_PH{ph_letter}",
                }
            ))
            rbu, rbv, rbrot = rb_specs[pidx]
            comps.append(CompSpec(
                f"R_M{ch}{ph_letter}", "10k_1%", "Resistor_SMD", "R_0402_1005Metric",
                "C25744", f"10kOhm 1% 0402 Motor {ch} Phase {ph_letter} Virtual-Neutral Star Sense", "12A 4-in-1 ESC",
                "B", rbu, rbv, rbrot,
                {"1": f"M{ch}_PH{ph_letter}", "2": f"M{ch}_VMUX"}
            ))

    return comps


if __name__ == "__main__":
    import sys
    import pcbnew

    pcb_dir = Path(__file__).resolve().parent.parent
    write_custom_footprints_and_3d(pcb_dir)
    comps = build_components()
    print(f"Total components: {len(comps)} (Top={sum(c.side=='F' for c in comps)}, Bot={sum(c.side=='B' for c in comps)})")

    fp_sys = Path(r"C:\Program Files\KiCad\10.0\share\kicad\footprints")
    io = pcbnew.PCB_IO_KICAD_SEXPR()
    board = pcbnew.BOARD()
    M2_UV = [
        (-M2_SPAN_HALF_MM, -M2_SPAN_HALF_MM),
        (M2_SPAN_HALF_MM, -M2_SPAN_HALF_MM),
        (M2_SPAN_HALF_MM, M2_SPAN_HALF_MM),
        (-M2_SPAN_HALF_MM, M2_SPAN_HALF_MM),
    ]

    uv_boxes: dict[str, list[tuple[str, float, float, float, float]]] = {"F": [], "B": []}
    errors = 0
    for c in comps:
        lib_dir = (pcb_dir / "OSITO_KODIAK.pretty") if c.lib == "OSITO_KODIAK" else (fp_sys / f"{c.lib}.pretty")
        fp = io.FootprintLoad(str(lib_dir), c.fp_name)
        board.Add(fp)
        x, y = c.xy
        fp.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(x), pcbnew.FromMM(y)))
        if c.side == "B":
            fp.Flip(pcbnew.VECTOR2I(pcbnew.FromMM(x), pcbnew.FromMM(y)), False)
        fp.SetOrientationDegrees(c.rot_deg)

        crtyd_layer = pcbnew.B_CrtYd if c.side == "B" else pcbnew.F_CrtYd
        poly = fp.GetCourtyard(crtyd_layer)
        us, vs = [], []
        for i in range(poly.OutlineCount()):
            ol = poly.Outline(i)
            for j in range(ol.PointCount()):
                pt = ol.CPoint(j)
                u, v = xy_to_uv(pcbnew.ToMM(pt.x), pcbnew.ToMM(pt.y))
                us.append(u)
                vs.append(v)
        u0, u1, v0, v1 = min(us), max(us), min(vs), max(vs)

        for p in fp.Pads():
            px, py = pcbnew.ToMM(p.GetPosition().x), pcbnew.ToMM(p.GetPosition().y)
            pu, pv = xy_to_uv(px, py)
            r_pad = 0.5 * max(pcbnew.ToMM(p.GetSize().x), pcbnew.ToMM(p.GetSize().y))
            for mu, mv in M2_UV:
                if math.hypot(pu - mu, pv - mv) - r_pad < 2.00:
                    print(f"  [{c.side} M2 PAD FAIL] {c.ref} pad {p.GetNumber()} at uv=({pu:.2f},{pv:.2f})")
                    errors += 1
            if max(abs(pu) + r_pad, abs(pv) + r_pad) > WAIST_HALF_MM - 0.50:
                print(f"  [{c.side} EDGE PAD FAIL] {c.ref} pad {p.GetNumber()} at uv=({pu:.2f},{pv:.2f}) r={r_pad:.2f}")
                errors += 1

        for prev_ref, pu0, pu1, pv0, pv1 in uv_boxes[c.side]:
            if u0 < pu1 - 0.01 and u1 > pu0 + 0.01 and v0 < pv1 - 0.01 and v1 > pv0 + 0.01:
                print(
                    f"  [{c.side} CRTYD OVERLAP] {c.ref} [{u0:.2f}..{u1:.2f}, {v0:.2f}..{v1:.2f}] "
                    f"<-> {prev_ref} [{pu0:.2f}..{pu1:.2f}, {pv0:.2f}..{pv1:.2f}]"
                )
                errors += 1
        uv_boxes[c.side].append((c.ref, u0, u1, v0, v1))

    net_counts: dict[str, list[str]] = {}
    for c in comps:
        for pnum, net in c.pins.items():
            if net:
                net_counts.setdefault(net, []).append(f"{c.ref}.{pnum}")
    for net, endpoints in sorted(net_counts.items()):
        if len(endpoints) < 2:
            print(f"  [SINGLE-PIN NET] {net}: {endpoints}")
            errors += 1

    print(f"Total active nets: {len(net_counts)}. Placement pre-flight complete: {errors} error(s).")
    sys.exit(0 if errors == 0 else 1)
