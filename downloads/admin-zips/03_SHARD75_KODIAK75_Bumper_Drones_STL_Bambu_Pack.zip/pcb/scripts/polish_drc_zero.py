#!/usr/bin/env python3
"""Exact 0.125mm Fine-Grid Continuous-Clearance DRC Polish & GND Stitch Pass
for OSITO_KODIAK_FC_v1.kicad_pcb.

Loads the routed 4-layer board, prunes any dangling track stubs, rips up only
nets involved in residual coarse-grid DRC violations, routes them sequentially
on a 0.125 mm 4-layer grid with exact Euclidean KiCad DRC clearances
(Cu-Cu >= 0.105 mm, Hole-Cu >= 0.205 mm, Hole-Hole >= 0.255 mm), stitches any
isolated GND sub-pockets, refills inner GND zones, and saves the board.
"""

from __future__ import annotations

import heapq
import json
import math
import sys
import time
from collections import defaultdict
from pathlib import Path

import pcbnew

SCRIPT_DIR = Path(__file__).resolve().parent
PCB_DIR = SCRIPT_DIR.parent
sys.path.insert(0, str(SCRIPT_DIR))

from kodiak_netlist_and_layout import (  # noqa: E402
    M2_HOLE_DIA_MM,
    M2_SPAN_HALF_MM,
    WAIST_HALF_MM,
    uv_to_xy,
    xy_to_uv,
)

PROJECT_NAME = "OSITO_KODIAK_FC_v1"
ANT_KO = (-14.30, 6.95, -11.30, 8.05)
M2_UV = [
    (M2_SPAN_HALF_MM, -M2_SPAN_HALF_MM),
    (M2_SPAN_HALF_MM, M2_SPAN_HALF_MM),
    (-M2_SPAN_HALF_MM, -M2_SPAN_HALF_MM),
    (-M2_SPAN_HALF_MM, M2_SPAN_HALF_MM),
]


def vec_mm(x: float, y: float) -> pcbnew.VECTOR2I:
    return pcbnew.VECTOR2I(pcbnew.FromMM(x), pcbnew.FromMM(y))


def pt_seg_dist2(px: float, py: float, x1: float, y1: float, x2: float, y2: float) -> float:
    dx, dy = x2 - x1, y2 - y1
    l2 = dx * dx + dy * dy
    if l2 <= 1e-12:
        return (px - x1) ** 2 + (py - y1) ** 2
    t = max(0.0, min(1.0, ((px - x1) * dx + (py - y1) * dy) / l2))
    qx, qy = x1 + t * dx, y1 + t * dy
    return (px - qx) ** 2 + (py - qy) ** 2


def _ccw(ax: float, ay: float, bx: float, by: float, cx: float, cy: float) -> float:
    return (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)


def segs_intersect(ax: float, ay: float, bx: float, by: float, cx: float, cy: float, dx: float, dy: float) -> bool:
    if max(ax, bx) < min(cx, dx) - 1e-9 or max(cx, dx) < min(ax, bx) - 1e-9:
        return False
    if max(ay, by) < min(cy, dy) - 1e-9 or max(cy, dy) < min(ay, by) - 1e-9:
        return False
    d1 = _ccw(ax, ay, bx, by, cx, cy)
    d2 = _ccw(ax, ay, bx, by, dx, dy)
    d3 = _ccw(cx, cy, dx, dy, ax, ay)
    d4 = _ccw(cx, cy, dx, dy, bx, by)
    if ((d1 > 0 and d2 < 0) or (d1 < 0 and d2 > 0)) and ((d3 > 0 and d4 < 0) or (d3 < 0 and d4 > 0)):
        return True
    if abs(d1) <= 1e-9 and pt_seg_dist2(cx, cy, ax, ay, bx, by) <= 1e-12:
        return True
    if abs(d2) <= 1e-9 and pt_seg_dist2(dx, dy, ax, ay, bx, by) <= 1e-12:
        return True
    if abs(d3) <= 1e-9 and pt_seg_dist2(ax, ay, cx, cy, dx, dy) <= 1e-12:
        return True
    if abs(d4) <= 1e-9 and pt_seg_dist2(bx, by, cx, cy, dx, dy) <= 1e-12:
        return True
    return False


def seg_seg_dist(ax: float, ay: float, bx: float, by: float, cx: float, cy: float, dx: float, dy: float) -> float:
    if segs_intersect(ax, ay, bx, by, cx, cy, dx, dy):
        return 0.0
    return math.sqrt(min(
        pt_seg_dist2(ax, ay, cx, cy, dx, dy),
        pt_seg_dist2(bx, by, cx, cy, dx, dy),
        pt_seg_dist2(cx, cy, ax, ay, bx, by),
        pt_seg_dist2(dx, dy, ax, ay, bx, by),
    ))


def pt_in_poly(px: float, py: float, poly: list[tuple[float, float]]) -> bool:
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if ((yi > py) != (yj > py)) and (px < (xj - xi) * (py - yi) / (yj - yi + 1e-15) + xi):
            inside = not inside
        j = i
    return inside


def pt_poly_dist(px: float, py: float, poly: list[tuple[float, float]]) -> float:
    if pt_in_poly(px, py, poly):
        return 0.0
    best = 1e9
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        d2 = pt_seg_dist2(px, py, x1, y1, x2, y2)
        if d2 < best:
            best = d2
    return math.sqrt(best)


def seg_poly_dist(ax: float, ay: float, bx: float, by: float, poly: list[tuple[float, float]]) -> float:
    if pt_in_poly(ax, ay, poly) or pt_in_poly(bx, by, poly):
        return 0.0
    best = 1e9
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        d = seg_seg_dist(ax, ay, bx, by, x1, y1, x2, y2)
        if d <= 0.0:
            return 0.0
        if d < best:
            best = d
    return best


def pt_rect_dist(px: float, py: float, u0: float, v0: float, u1: float, v1: float) -> float:
    dx = max(u0 - px, 0.0, px - u1)
    dy = max(v0 - py, 0.0, py - v1)
    return math.hypot(dx, dy)


class FineBoard:
    CLR_CU = 0.106
    CLR_HOLE = 0.206
    CLR_H2H = 0.256
    VIA_RCU = 0.175
    VIA_RDRL = 0.075

    def __init__(self) -> None:
        # Spatial bins of 1.0 mm in (u, v)
        self.pads: dict[tuple[int, int, int], list[tuple[float, float, float, float, list[tuple[float, float]], str, bool]]] = defaultdict(list)
        self.segs: dict[tuple[int, int, int], list[tuple[float, float, float, float, float, str]]] = defaultdict(list)
        self.vias: dict[tuple[int, int], list[tuple[float, float, float, float, str]]] = defaultdict(list)

    @staticmethod
    def _bins(u0: float, v0: float, u1: float, v1: float, margin: float = 0.45):
        ix0, ix1 = int(math.floor(u0 - margin)), int(math.floor(u1 + margin))
        iy0, iy1 = int(math.floor(v0 - margin)), int(math.floor(v1 + margin))
        for ix in range(ix0, ix1 + 1):
            for iy in range(iy0, iy1 + 1):
                yield ix, iy

    def add_pad(self, lyr: int, poly: list[tuple[float, float]], net: str) -> None:
        # Decimate dense rounded-rect vertices (< 0.035 mm apart) for 8x faster exact polygon checks
        dec: list[tuple[float, float]] = []
        for pt in poly:
            if not dec or math.hypot(pt[0] - dec[-1][0], pt[1] - dec[-1][1]) >= 0.035:
                dec.append(pt)
        if len(dec) >= 3:
            poly = dec
        u0 = min(p[0] for p in poly)
        u1 = max(p[0] for p in poly)
        v0 = min(p[1] for p in poly)
        v1 = max(p[1] for p in poly)
        is_ep = min(u1 - u0, v1 - v0) >= 1.45
        item = (u0, v0, u1, v1, poly, net, is_ep)
        for ix, iy in self._bins(u0, v0, u1, v1, 0.40):
            self.pads[(lyr, ix, iy)].append(item)

    def add_seg(self, lyr: int, u0: float, v0: float, u1: float, v1: float, hw: float, net: str) -> None:
        item = (u0, v0, u1, v1, hw, net)
        for ix, iy in self._bins(min(u0, u1), min(v0, v1), max(u0, u1), max(v0, v1), hw + 0.40):
            self.segs[(lyr, ix, iy)].append(item)

    def add_via(self, u: float, v: float, r_cu: float, r_drl: float, net: str) -> None:
        item = (u, v, r_cu, r_drl, net)
        for ix, iy in self._bins(u, v, u, v, r_cu + 0.45):
            self.vias[(ix, iy)].append(item)

    def in_bounds(self, u: float, v: float, r_cu: float, allow_ant: bool = False) -> bool:
        if abs(u) + r_cu > WAIST_HALF_MM - 0.50 or abs(v) + r_cu > WAIST_HALF_MM - 0.50:
            return False
        for mu, mv in M2_UV:
            if math.hypot(u - mu, v - mv) < (M2_HOLE_DIA_MM * 0.5 + 0.50 + r_cu):
                return False
        if not allow_ant:
            ku0, kv0, ku1, kv1 = ANT_KO
            if pt_rect_dist(u, v, ku0, kv0, ku1, kv1) < r_cu + 0.05:
                return False
        return True

    def can_via(self, u: float, v: float, net: str) -> bool:
        rcu, rdrl = self.VIA_RCU, self.VIA_RDRL
        if not self.in_bounds(u, v, rcu, False):
            return False

        seen_v: set[int] = set()
        for ix, iy in self._bins(u, v, u, v, 0.55):
            for item in self.vias.get((ix, iy), ()):
                if id(item) in seen_v:
                    continue
                seen_v.add(id(item))
                vu, vv, vrcu, vrdrl, vnet = item
                d = math.hypot(u - vu, v - vv)
                if vnet == net:
                    if 1e-4 < d < rdrl + vrdrl + self.CLR_H2H:
                        return False
                else:
                    req = max(rcu + vrcu + self.CLR_CU, rdrl + vrdrl + self.CLR_H2H, rdrl + vrcu + self.CLR_HOLE, vrdrl + rcu + self.CLR_HOLE)
                    if d < req:
                        return False

        for lyr in (0, 3):
            seen_p: set[int] = set()
            for ix, iy in self._bins(u, v, u, v, 0.40):
                for item in self.pads.get((lyr, ix, iy), ()):
                    if id(item) in seen_p:
                        continue
                    seen_p.add(id(item))
                    pu0, pv0, pu1, pv1, poly, pnet, is_ep = item
                    req = max(rcu + self.CLR_CU, rdrl + self.CLR_HOLE)
                    if u < pu0 - req or u > pu1 + req or v < pv0 - req or v > pv1 + req:
                        continue
                    if pnet == net:
                        if not is_ep and pt_poly_dist(u, v, poly) < 0.04:
                            return False
                    else:
                        if pt_poly_dist(u, v, poly) < req:
                            return False

        for lyr in (0, 1, 2, 3):
            seen_s: set[int] = set()
            for ix, iy in self._bins(u, v, u, v, 0.45):
                for item in self.segs.get((lyr, ix, iy), ()):
                    if id(item) in seen_s:
                        continue
                    seen_s.add(id(item))
                    su0, sv0, su1, sv1, shw, snet = item
                    if snet == net:
                        continue
                    req = max(rcu + shw + self.CLR_CU, rdrl + shw + self.CLR_HOLE)
                    if math.sqrt(pt_seg_dist2(u, v, su0, sv0, su1, sv1)) < req:
                        return False
        return True

    def can_seg(self, lyr: int, u0: float, v0: float, u1: float, v1: float, hw: float, net: str) -> bool:
        if lyr == 1 and min(u0, u1) < -7.75 and 5.50 < max(v0, v1) and min(v0, v1) < 7.60:
            return False
        if not self.in_bounds(u0, v0, hw, False) or not self.in_bounds(u1, v1, hw, False):
            return False
        for mu, mv in M2_UV:
            if math.sqrt(pt_seg_dist2(mu, mv, u0, v0, u1, v1)) < (M2_HOLE_DIA_MM * 0.5 + 0.50 + hw):
                return False

        bu0, bu1 = min(u0, u1), max(u0, u1)
        bv0, bv1 = min(v0, v1), max(v0, v1)

        if lyr in (0, 3):
            req_p = hw + self.CLR_CU
            seen_p: set[int] = set()
            for ix, iy in self._bins(bu0, bv0, bu1, bv1, req_p + 0.05):
                for item in self.pads.get((lyr, ix, iy), ()):
                    if id(item) in seen_p:
                        continue
                    seen_p.add(id(item))
                    pu0, pv0, pu1, pv1, poly, pnet, _ = item
                    if pnet == net:
                        continue
                    if bu1 + req_p < pu0 or bu0 - req_p > pu1 or bv1 + req_p < pv0 or bv0 - req_p > pv1:
                        continue
                    if seg_poly_dist(u0, v0, u1, v1, poly) < req_p:
                        return False

        seen_v: set[int] = set()
        for ix, iy in self._bins(bu0, bv0, bu1, bv1, 0.45):
            for item in self.vias.get((ix, iy), ()):
                if id(item) in seen_v:
                    continue
                seen_v.add(id(item))
                vu, vv, vrcu, vrdrl, vnet = item
                if vnet == net:
                    continue
                req_v = max(hw + vrcu + self.CLR_CU, hw + vrdrl + self.CLR_HOLE)
                if math.sqrt(pt_seg_dist2(vu, vv, u0, v0, u1, v1)) < req_v:
                    return False

        seen_s: set[int] = set()
        for ix, iy in self._bins(bu0, bv0, bu1, bv1, hw + 0.30):
            for item in self.segs.get((lyr, ix, iy), ()):
                if id(item) in seen_s:
                    continue
                seen_s.add(id(item))
                su0, sv0, su1, sv1, shw, snet = item
                if snet == net:
                    continue
                if seg_seg_dist(u0, v0, u1, v1, su0, sv0, su1, sv1) < hw + shw + self.CLR_CU:
                    return False
        return True


def prune_dangling_tracks(
    board: pcbnew.BOARD,
    alive_tracks: list[pcbnew.PCB_TRACK],
    pad_boxes: list[tuple[int, str, float, float, float, float]],
) -> int:
    """Iteratively remove any track segment with an unconnected open endpoint."""
    LYR_CU = {pcbnew.F_Cu: 0, pcbnew.In1_Cu: 1, pcbnew.In2_Cu: 2, pcbnew.B_Cu: 3}

    removed_total = 0
    while True:
        vias: list[tuple[str, float, float, float]] = []
        trks: list[tuple[int, pcbnew.PCB_TRACK, int, str, float, float, float, float]] = []
        pt_deg: dict[tuple[int, str, int, int], int] = defaultdict(int)

        for idx_t, item in enumerate(alive_tracks):
            n = item.GetNetname()
            if isinstance(item, pcbnew.PCB_VIA):
                vias.append((n, pcbnew.ToMM(item.GetPosition().x), pcbnew.ToMM(item.GetPosition().y), pcbnew.ToMM(item.GetWidth(pcbnew.F_Cu)) * 0.5 + 0.02))
            else:
                li = LYR_CU.get(item.GetLayer(), -1)
                if li < 0:
                    continue
                sx, sy = pcbnew.ToMM(item.GetStart().x), pcbnew.ToMM(item.GetStart().y)
                ex, ey = pcbnew.ToMM(item.GetEnd().x), pcbnew.ToMM(item.GetEnd().y)
                trks.append((idx_t, item, li, n, sx, sy, ex, ey))
                pt_deg[(li, n, round(sx * 200), round(sy * 200))] += 1
                pt_deg[(li, n, round(ex * 200), round(ey * 200))] += 1

        def end_supported(li: int, n: str, x: float, y: float) -> bool:
            if pt_deg[(li, n, round(x * 200), round(y * 200))] >= 2:
                return True
            for vn, vx, vy, vr in vias:
                if vn == n and math.hypot(x - vx, y - vy) <= vr:
                    return True
            for pli, pn, x0, y0, x1, y1 in pad_boxes:
                if pli == li and pn == n and x0 <= x <= x1 and y0 <= y <= y1:
                    return True
            return False

        del_indices: set[int] = set()
        for idx_t, item, li, n, sx, sy, ex, ey in trks:
            if not end_supported(li, n, sx, sy) or not end_supported(li, n, ex, ey):
                del_indices.add(idx_t)

        if not del_indices:
            break
        new_alive: list[pcbnew.PCB_TRACK] = []
        for idx_t, item in enumerate(alive_tracks):
            if idx_t in del_indices:
                board.Remove(item)
                removed_total += 1
            else:
                new_alive.append(item)
        alive_tracks[:] = new_alive
    return removed_total


LAST_BLOCKED_PTS: list[tuple[int, float, float]] = []


def route_fine_astar(
    fb: FineBoard,
    net: str,
    src_pts: list[tuple[int, float, float]],
    dst_pts: list[tuple[int, float, float]],
    step: float = 0.125,
    hw: float = 0.0525,
) -> tuple[list[tuple[int, float, float, float, float]], list[tuple[float, float]]] | None:
    """Exact 0.125mm 4-layer A* router between src_pts and dst_pts."""
    LAST_BLOCKED_PTS.clear()
    G_LIM = int(math.floor(13.0 / step))

    def build_escapes(pts: list[tuple[int, float, float]]):
        esc: dict[tuple[int, int, int], list[tuple[float, float]]] = {}
        for lyr, pu, pv in pts:
            iu0, iv0 = int(round(pu / step)), int(round(pv / step))
            for rad in range(0, 10):
                for diu in range(-rad, rad + 1):
                    for div in range(-rad, rad + 1):
                        if max(abs(diu), abs(div)) != rad:
                            continue
                        iu, iv = iu0 + diu, iv0 + div
                        if abs(iu) > G_LIM or abs(iv) > G_LIM:
                            continue
                        gu, gv = iu * step, iv * step
                        node = (lyr, iu, iv)
                        if node in esc:
                            continue
                        if math.hypot(gu - pu, gv - pv) < 1e-4:
                            esc[node] = [(pu, pv)]
                        elif rad <= 1 and fb.can_seg(lyr, pu, pv, gu, gv, hw, net):
                            esc[node] = [(pu, pv), (gu, gv)]
                        elif fb.can_seg(lyr, pu, pv, pu, gv, hw, net) and fb.can_seg(lyr, pu, gv, gu, gv, hw, net):
                            esc[node] = [(pu, pv), (pu, gv), (gu, gv)]
                        elif fb.can_seg(lyr, pu, pv, gu, pv, hw, net) and fb.can_seg(lyr, gu, pv, gu, gv, hw, net):
                            esc[node] = [(pu, pv), (gu, pv), (gu, gv)]
                if len(esc) >= 24 and rad >= 2:
                    break
        return esc

    src_esc = build_escapes(src_pts)
    dst_esc = build_escapes(dst_pts)
    if not src_esc:
        LAST_BLOCKED_PTS.extend(src_pts[:6])
        return None
    if not dst_esc:
        LAST_BLOCKED_PTS.extend(dst_pts[:6])
        return None

    du_lo = min(k[1] for k in dst_esc)
    du_hi = max(k[1] for k in dst_esc)
    dv_lo = min(k[2] for k in dst_esc)
    dv_hi = max(k[2] for k in dst_esc)
    dst_lyrs = {k[0] for k in dst_esc}

    def h_est(l: int, iu: int, iv: int) -> float:
        dx = du_lo - iu if iu < du_lo else (iu - du_hi if iu > du_hi else 0)
        dy = dv_lo - iv if iv < dv_lo else (iv - dv_hi if iv > dv_hi else 0)
        return (dx + dy) * step + (0.0 if l in dst_lyrs else 0.35)

    pq: list[tuple[float, float, tuple[int, int, int]]] = []
    g_cost: dict[tuple[int, int, int], float] = {}
    parent: dict[tuple[int, int, int], tuple[int, int, int] | None] = {}

    for snode, wpts in src_esc.items():
        sc = 0.02 * len(wpts)
        g_cost[snode] = sc
        parent[snode] = None
        heapq.heappush(pq, (sc + h_est(*snode), sc, snode))

    seg_memo: dict[tuple[int, int, int, int, int], bool] = {}
    via_memo: dict[tuple[int, int], bool] = {}
    DIRS = [(1, 0), (-1, 0), (0, 1), (0, -1)]

    def step_ok(cl: int, ciu: int, civ: int, niu: int, niv: int) -> bool:
        mkey = (cl, min(ciu, niu), min(civ, niv), max(ciu, niu), max(civ, niv))
        ok = seg_memo.get(mkey)
        if ok is None:
            ok = fb.can_seg(cl, ciu * step, civ * step, niu * step, niv * step, hw, net)
            seg_memo[mkey] = ok
        return ok

    def via_ok(ciu: int, civ: int) -> bool:
        ok = via_memo.get((ciu, civ))
        if ok is None:
            ok = fb.can_via(ciu * step, civ * step, net)
            via_memo[(ciu, civ)] = ok
        return ok

    def extract_pocket_boundary(comp: set[tuple[int, int, int]], tgt_u: float, tgt_v: float) -> list[tuple[int, float, float]]:
        cand: list[tuple[float, int, float, float]] = []
        for cl, ciu, civ in comp:
            cu, cv = ciu * step, civ * step
            d_tgt = math.hypot(cu - tgt_u, cv - tgt_v)
            for diu, div in DIRS:
                niu, niv = ciu + diu, civ + div
                if abs(niu) <= G_LIM and abs(niv) <= G_LIM and (cl, niu, niv) not in comp:
                    if not step_ok(cl, ciu, civ, niu, niv):
                        mu, mv = (ciu + 0.5 * diu) * step, (civ + 0.5 * div) * step
                        cand.append((math.hypot(mu - tgt_u, mv - tgt_v), cl, mu, mv))
            if not via_ok(ciu, civ):
                cand.append((d_tgt + 0.08, -1, cu, cv))
        cand.sort(key=lambda x: x[0])
        return [(cl, mu, mv) for _, cl, mu, mv in cand[:24]]

    # Fast pocket pre-check on dst_esc & src_esc so boxed-in pads fail in <2 ms instead of 40k expansions
    for seeds, other, opp_pt in ((dst_esc, src_esc, src_pts[0]), (src_esc, dst_esc, dst_pts[0])):
        vis = set(seeds.keys())
        q_chk = list(seeds.keys())
        reached_other = any(s in other for s in q_chk)
        qi = 0
        while qi < len(q_chk) and len(vis) < 120 and not reached_other:
            cl, ciu, civ = q_chk[qi]
            qi += 1
            for diu, div in DIRS:
                niu, niv = ciu + diu, civ + div
                if abs(niu) <= G_LIM and abs(niv) <= G_LIM and (cl, niu, niv) not in vis and step_ok(cl, ciu, civ, niu, niv):
                    if (cl, niu, niv) in other:
                        reached_other = True
                        break
                    vis.add((cl, niu, niv))
                    q_chk.append((cl, niu, niv))
            if not reached_other and via_ok(ciu, civ):
                for nl in (0, 1, 2, 3):
                    if nl != cl and (nl, ciu, civ) not in vis:
                        if (nl, ciu, civ) in other:
                            reached_other = True
                            break
                        vis.add((nl, ciu, civ))
                        q_chk.append((nl, ciu, civ))
        if len(vis) < 120 and not reached_other:
            LAST_BLOCKED_PTS.extend(extract_pocket_boundary(vis, opp_pt[1], opp_pt[2]))
            return None

    goal_node: tuple[int, int, int] | None = None
    exp = 0

    while pq and exp < 40000:
        _, gc, cur = heapq.heappop(pq)
        if cur in dst_esc:
            goal_node = cur
            break
        if gc > g_cost.get(cur, 1e9) + 1e-6:
            continue
        exp += 1
        cl, ciu, civ = cur

        for diu, div in DIRS:
            niu, niv = ciu + diu, civ + div
            if abs(niu) > G_LIM or abs(niv) > G_LIM:
                continue
            if not step_ok(cl, ciu, civ, niu, niv):
                continue
            if cl == 1:
                dc = step * (1.00 if div == 0 else 1.25)
            elif cl == 2:
                dc = step * (1.00 if diu == 0 else 1.25)
            else:
                dc = step * 1.15
            nxt = (cl, niu, niv)
            ng = gc + dc
            if ng + 1e-6 < g_cost.get(nxt, 1e9):
                g_cost[nxt] = ng
                parent[nxt] = cur
                heapq.heappush(pq, (ng + h_est(cl, niu, niv), ng, nxt))

        if via_ok(ciu, civ):
            for nl in (0, 1, 2, 3):
                if nl == cl:
                    continue
                nxt = (nl, ciu, civ)
                ng = gc + 0.45
                if ng + 1e-6 < g_cost.get(nxt, 1e9):
                    g_cost[nxt] = ng
                    parent[nxt] = cur
                    heapq.heappush(pq, (ng + h_est(nl, ciu, civ), ng, nxt))

    if goal_node is None:
        # Bounded reverse BFS from dst_esc to check if dst_esc sits in a finite pocket (<2000 states)
        rev_vis = set(dst_esc.keys())
        rq = list(dst_esc.keys())
        rqi = 0
        while rqi < len(rq) and len(rev_vis) < 2000:
            cl, ciu, civ = rq[rqi]
            rqi += 1
            for diu, div in DIRS:
                niu, niv = ciu + diu, civ + div
                if abs(niu) <= G_LIM and abs(niv) <= G_LIM and (cl, niu, niv) not in rev_vis and step_ok(cl, ciu, civ, niu, niv):
                    rev_vis.add((cl, niu, niv))
                    rq.append((cl, niu, niv))
            if via_ok(ciu, civ):
                for nl in (0, 1, 2, 3):
                    if nl != cl and (nl, ciu, civ) not in rev_vis:
                        rev_vis.add((nl, ciu, civ))
                        rq.append((nl, ciu, civ))
        fwd_set = set(g_cost.keys())
        if len(rev_vis) < 2000 and (exp >= 40000 or len(rev_vis) <= len(fwd_set)):
            LAST_BLOCKED_PTS.extend(extract_pocket_boundary(rev_vis, src_pts[0][1], src_pts[0][2]))
        elif fwd_set:
            LAST_BLOCKED_PTS.extend(extract_pocket_boundary(fwd_set, dst_pts[0][1], dst_pts[0][2]))
        else:
            LAST_BLOCKED_PTS.extend(dst_pts[:4] + src_pts[:4])
        return None

    path: list[tuple[int, int, int]] = []
    curr: tuple[int, int, int] | None = goal_node
    while curr is not None:
        path.append(curr)
        curr = parent[curr]
    path.reverse()

    out_segs: list[tuple[int, float, float, float, float]] = []
    out_vias: list[tuple[float, float]] = []

    swpts = src_esc[path[0]]
    sl = path[0][0]
    for k in range(len(swpts) - 1):
        if math.hypot(swpts[k + 1][0] - swpts[k][0], swpts[k + 1][1] - swpts[k][1]) > 1e-4:
            out_segs.append((sl, swpts[k][0], swpts[k][1], swpts[k + 1][0], swpts[k + 1][1]))

    i = 0
    while i < len(path) - 1:
        l0, iu0, iv0 = path[i]
        l1, iu1, iv1 = path[i + 1]
        if l0 != l1:
            vu, vv = iu0 * step, iv0 * step
            if all(math.hypot(vu - x, vv - y) > 1e-4 for x, y in out_vias):
                out_vias.append((vu, vv))
            i += 1
        else:
            diu, div = iu1 - iu0, iv1 - iv0
            j = i + 1
            while j + 1 < len(path) and path[j + 1][0] == l0 and (path[j + 1][1] - path[j][1], path[j + 1][2] - path[j][2]) == (diu, div):
                j += 1
            out_segs.append((l0, iu0 * step, iv0 * step, path[j][1] * step, path[j][2] * step))
            i = j

    dwpts = dst_esc[goal_node]
    dl = goal_node[0]
    for k in range(len(dwpts) - 1, 0, -1):
        if math.hypot(dwpts[k - 1][0] - dwpts[k][0], dwpts[k - 1][1] - dwpts[k][1]) > 1e-4:
            out_segs.append((dl, dwpts[k][0], dwpts[k][1], dwpts[k - 1][0], dwpts[k - 1][1]))

    return out_segs, out_vias


def polish_board(pcb_path: Path, drc_json_path: Path | None = None) -> int:
    t0 = time.time()
    board = pcbnew.LoadBoard(str(pcb_path))
    LYR_CU = {pcbnew.F_Cu: 0, pcbnew.In1_Cu: 1, pcbnew.In2_Cu: 2, pcbnew.B_Cu: 3}
    LYR_PCB = {0: pcbnew.F_Cu, 1: pcbnew.In1_Cu, 2: pcbnew.In2_Cu, 3: pcbnew.B_Cu}
    POWER_NETS = {"GND", "+3V3_MCU", "+VBAT", "+5V_BEC"}

    # 1. Identify minimal nets to rip up & re-route on 0.125 mm fine grid
    polish_nets = {
        "OSD_X2",
        "GYRO_CS",
        "SPI1_MOSI",
        "GYRO_EXTI",
        "M1_DSHOT_RAW",
        "M2_DSHOT_RAW",
        "LED_PWM_RAW",
        "HSE_OUT",
    }
    unconn_gnd_pairs: list[tuple[tuple[int, float, float], tuple[int, float, float]]] = []
    if drc_json_path and drc_json_path.exists():
        drc = json.loads(drc_json_path.read_text(encoding="utf-8"))
        for v in drc.get("violations", []):
            if v.get("type") == "track_dangling":
                continue
            vnets = []
            for it in v.get("items", []):
                desc = it.get("description", "")
                if "[" in desc and "]" in desc:
                    vnets.append(desc.split("[", 1)[1].split("]", 1)[0])
            if vnets and not any(vn in polish_nets for vn in vnets):
                for vn in vnets:
                    if vn not in POWER_NETS:
                        polish_nets.add(vn)
                        break
        for u in drc.get("unconnected_items", []):
            its = u.get("items", [])
            if len(its) >= 2:
                desc0 = its[0].get("description", "")
                unet = desc0.split("[", 1)[1].split("]", 1)[0] if ("[" in desc0 and "]" in desc0) else ""
                if unet and unet not in POWER_NETS:
                    polish_nets.add(unet)
                    continue
                pts_pair = []
                for it in its[:2]:
                    desc = it.get("description", "")
                    # KiCad 10 drc.json coordinate_units is already "mm"!
                    xm, ym = float(it["pos"]["x"]), float(it["pos"]["y"])
                    uu, vv = xy_to_uv(xm, ym)
                    li = 3 if "on B.Cu" in desc else 0
                    pts_pair.append((li, uu, vv))
                unconn_gnd_pairs.append((pts_pair[0], pts_pair[1]))

    # Extract all pad geometry ONCE up front before modifying board tracks
    pad_uv_polys: list[tuple[int, list[tuple[float, float]], str]] = []
    pad_boxes_xy: list[tuple[int, str, float, float, float, float]] = []
    net_pads: dict[str, list[list[tuple[int, float, float]]]] = defaultdict(list)
    net_pad_flat: dict[str, list[tuple[int, float, float]]] = defaultdict(list)
    ic_escape_stubs: list[tuple[int, float, float, float, float, str]] = []
    ic_cand_pads: list[tuple[int, float, float, float, float, str]] = []
    for fp in board.GetFootprints():
        pads_list = list(fp.Pads())
        is_fine_ic = len(pads_list) >= 24
        ic_cu = ic_cv = 0.0
        if is_fine_ic:
            uv_all = [xy_to_uv(pcbnew.ToMM(px.GetPosition().x), pcbnew.ToMM(px.GetPosition().y)) for px in pads_list]
            ic_cu = sum(q[0] for q in uv_all) / len(uv_all)
            ic_cv = sum(q[1] for q in uv_all) / len(uv_all)
        for p in pads_list:
            n = p.GetNetname()
            pu, pv = xy_to_uv(pcbnew.ToMM(p.GetPosition().x), pcbnew.ToMM(p.GetPosition().y))
            for pcb_l, li in ((pcbnew.F_Cu, 0), (pcbnew.B_Cu, 3)):
                if p.IsOnLayer(pcb_l):
                    eff = p.GetEffectivePolygon(pcb_l)
                    pts_xy = [
                        (pcbnew.ToMM(eff.Outline(oi).CPoint(pi).x), pcbnew.ToMM(eff.Outline(oi).CPoint(pi).y))
                        for oi in range(eff.OutlineCount())
                        for pi in range(eff.Outline(oi).PointCount())
                    ]
                    pts_uv = [xy_to_uv(qx, qy) for qx, qy in pts_xy]
                    if pts_uv:
                        pad_uv_polys.append((li, pts_uv, n))
                        pad_boxes_xy.append((li, n, min(q[0] for q in pts_xy) - 0.03, min(q[1] for q in pts_xy) - 0.03, max(q[0] for q in pts_xy) + 0.03, max(q[1] for q in pts_xy) + 0.03))
                        if n:
                            u0, u1 = min(q[0] for q in pts_uv), max(q[0] for q in pts_uv)
                            v0, v1 = min(q[1] for q in pts_uv), max(q[1] for q in pts_uv)
                            if (
                                is_fine_ic
                                and not p.IsOnLayer(pcbnew.B_Cu if li == 0 else pcbnew.F_Cu)
                                and not n.startswith("unconnected-")
                                and n not in POWER_NETS
                                and math.hypot(pu - ic_cu, pv - ic_cv) > 1.0
                            ):
                                if (u1 - u0) >= (v1 - v0):
                                    du_e = 0.58 if pu >= ic_cu else -0.58
                                    dv_e = 0.0
                                else:
                                    du_e = 0.0
                                    dv_e = 0.58 if pv >= ic_cv else -0.58
                                ic_cand_pads.append((li, pu, pv, du_e, dv_e, n))
                            lpts = [(li, pu, pv)]
                            if u1 - u0 > 0.55 and v1 - v0 >= 0.20:
                                du = 0.34 * (u1 - u0)
                                lpts.extend([(li, pu - du, pv), (li, pu + du, pv)])
                            if v1 - v0 > 0.55 and u1 - u0 >= 0.20:
                                dv = 0.34 * (v1 - v0)
                                lpts.extend([(li, pu, pv - dv), (li, pu, pv + dv)])
                            net_pads[n].append(lpts)
                            net_pad_flat[n].extend(lpts)

    # Include HSE_IN alongside HSE_OUT so the crystal pair routes cleanly together without ping-ponging
    polish_nets.add("HSE_IN")

    # Remove all tracks & vias of polish_nets (call board.GetTracks() ONCE!)
    raw_tracks = list(board.GetTracks())
    alive_tracks: list[pcbnew.PCB_TRACK] = []
    removed_net_items = 0
    for item in raw_tracks:
        if item.GetNetname() in polish_nets:
            board.Remove(item)
            removed_net_items += 1
        else:
            alive_tracks.append(item)

    unrouted_nets: set[str] = set(polish_nets)

    def build_fine_board(items_list: list[pcbnew.PCB_TRACK], include_stubs: bool = True) -> tuple[FineBoard, list[tuple[float, float]]]:
        fb_inst = FineBoard()
        for li, pts_uv, n in pad_uv_polys:
            fb_inst.add_pad(li, pts_uv, n)
        g_vias: list[tuple[float, float]] = []
        for itm in items_list:
            n = itm.GetNetname()
            if isinstance(itm, pcbnew.PCB_VIA):
                vu, vv = xy_to_uv(pcbnew.ToMM(itm.GetPosition().x), pcbnew.ToMM(itm.GetPosition().y))
                fb_inst.add_via(vu, vv, pcbnew.ToMM(itm.GetWidth(pcbnew.F_Cu)) * 0.5, pcbnew.ToMM(itm.GetDrillValue()) * 0.5, n)
                if n == "GND":
                    g_vias.append((vu, vv))
            else:
                li = LYR_CU.get(itm.GetLayer(), -1)
                if li >= 0:
                    u0, v0 = xy_to_uv(pcbnew.ToMM(itm.GetStart().x), pcbnew.ToMM(itm.GetStart().y))
                    u1, v1 = xy_to_uv(pcbnew.ToMM(itm.GetEnd().x), pcbnew.ToMM(itm.GetEnd().y))
                    fb_inst.add_seg(li, u0, v0, u1, v1, pcbnew.ToMM(itm.GetWidth()) * 0.5, n)
        if include_stubs:
            for li_s, pu_s, pv_s, du_e, dv_e, sn in ic_cand_pads:
                if sn in unrouted_nets:
                    if fb_inst.can_seg(li_s, pu_s, pv_s, pu_s + du_e, pv_s + dv_e, 0.045, sn):
                        fb_inst.add_seg(li_s, pu_s, pv_s, pu_s + du_e, pv_s + dv_e, 0.045, sn)
                    elif fb_inst.can_seg(li_s, pu_s, pv_s, pu_s - du_e, pv_s - dv_e, 0.045, sn):
                        fb_inst.add_seg(li_s, pu_s, pv_s, pu_s - du_e, pv_s - dv_e, 0.045, sn)
        return fb_inst, g_vias

    # Drop the missing GND via at (-4.50, -10.75) = xy (4.4194, -10.7834) BEFORE pruning dangling stubs
    gnd_ni = board.FindNet("GND")
    fb_tmp, _ = build_fine_board(alive_tracks, include_stubs=False)
    u_led9_v, v_led9_v = xy_to_uv(4.419417, -10.783379)
    if fb_tmp.can_via(u_led9_v, v_led9_v, "GND"):
        via = pcbnew.PCB_VIA(board)
        via.SetPosition(vec_mm(*uv_to_xy(u_led9_v, v_led9_v)))
        via.SetWidth(pcbnew.FromMM(0.35))
        via.SetDrill(pcbnew.FromMM(0.15))
        via.SetLayerPair(pcbnew.F_Cu, pcbnew.B_Cu)
        via.SetNet(gnd_ni)
        board.Add(via)
        alive_tracks.append(via)
        print("Added missing GND transition via for LED9.2 at", round(u_led9_v, 3), round(v_led9_v, 3), flush=True)

    pruned = prune_dangling_tracks(board, alive_tracks, pad_boxes_xy)
    print(f"Removed {removed_net_items} items across {sorted(polish_nets)}; pruned {pruned} dangling segments.", flush=True)

    fb, gnd_via_uvs = build_fine_board(alive_tracks, include_stubs=True)
    W_NEW = 0.105
    HW_NEW = W_NEW * 0.5

    def commit_route(net: str, segs: list[tuple[int, float, float, float, float]], vias: list[tuple[float, float]]) -> None:
        ni = board.FindNet(net)
        for li, u0, v0, u1, v1 in segs:
            if math.hypot(u1 - u0, v1 - v0) < 1e-4:
                continue
            t = pcbnew.PCB_TRACK(board)
            t.SetLayer(LYR_PCB[li])
            t.SetStart(vec_mm(*uv_to_xy(u0, v0)))
            t.SetEnd(vec_mm(*uv_to_xy(u1, v1)))
            t.SetWidth(pcbnew.FromMM(W_NEW))
            t.SetNet(ni)
            board.Add(t)
            alive_tracks.append(t)
            fb.add_seg(li, u0, v0, u1, v1, HW_NEW, net)
        for vu, vv in vias:
            via = pcbnew.PCB_VIA(board)
            via.SetPosition(vec_mm(*uv_to_xy(vu, vv)))
            via.SetWidth(pcbnew.FromMM(0.35))
            via.SetDrill(pcbnew.FromMM(0.15))
            via.SetLayerPair(pcbnew.F_Cu, pcbnew.B_Cu)
            via.SetNet(ni)
            board.Add(via)
            alive_tracks.append(via)
            fb.add_via(vu, vv, FineBoard.VIA_RCU, FineBoard.VIA_RDRL, net)
            if net == "GND":
                gnd_via_uvs.append((vu, vv))

    def rip_net_live(victim: str) -> None:
        nonlocal fb, gnd_via_uvs
        unrouted_nets.add(victim)
        kept: list[pcbnew.PCB_TRACK] = []
        cnt = 0
        for itm in alive_tracks:
            if itm.GetNetname() == victim:
                board.Remove(itm)
                cnt += 1
            else:
                kept.append(itm)
        alive_tracks[:] = kept
        fb, gnd_via_uvs = build_fine_board(alive_tracks, include_stubs=True)
        print(f"  [RIP] Dynamically ripped blocking neighbor {victim} ({cnt} items)", flush=True)

    def find_blocker_near(pts: list[tuple[int, float, float]], cur_net: str, rip_counts: dict[str, int], last_victim: str | None) -> str | None:
        for rad in (0.48, 1.15):
            best_n = None
            best_score = 1e9
            for rank_i, (pl, pu, pv) in enumerate(pts):
                rank_pen = 0.015 * rank_i
                for ix, iy in FineBoard._bins(pu, pv, pu, pv, rad):
                    for vu, vv, _, _, vn in fb.vias.get((ix, iy), ()):
                        if vn != cur_net and vn not in POWER_NETS and vn not in unrouted_nets and rip_counts[vn] < 8 and vn != last_victim:
                            d = math.hypot(pu - vu, pv - vv)
                            if d < rad:
                                sc = d + rank_pen + 0.35 * rip_counts[vn]
                                if sc < best_score:
                                    best_score, best_n = sc, vn
                    lyrs = (0, 1, 2, 3) if pl < 0 else (pl,)
                    for lyr in lyrs:
                        for su0, sv0, su1, sv1, _, sn in fb.segs.get((lyr, ix, iy), ()):
                            if sn != cur_net and sn not in POWER_NETS and sn not in unrouted_nets and rip_counts[sn] < 8 and sn != last_victim:
                                d = math.sqrt(pt_seg_dist2(pu, pv, su0, sv0, su1, sv1))
                                if d < rad:
                                    sc = d + rank_pen + 0.35 * rip_counts[sn]
                                    if sc < best_score:
                                        best_score, best_n = sc, sn
            if best_n is not None:
                return best_n
        return None

    # Order nets so short crystal nets and tight U1 East/North pins route cleanly first
    ordered_nets = [
        "HSE_OUT",
        "HSE_IN",
        "OSD_X1",
        "OSD_X2",
        "M1_DSHOT_RAW",
        "GYRO_EXTI",
        "M2_DSHOT_RAW",
        "SPI1_MOSI",
        "LED_PWM_RAW",
        "GYRO_CS",
    ]
    for n in sorted(polish_nets):
        if n not in ordered_nets:
            ordered_nets.append(n)

    rip_counts: dict[str, int] = defaultdict(int)
    total_rips = 0
    last_victim: str | None = None
    idx_q = 0
    while idx_q < len(ordered_nets):
        net = ordered_nets[idx_q]
        idx_q += 1
        if net not in unrouted_nets:
            continue
        pad_groups = net_pads[net]
        if len(pad_groups) < 2:
            unrouted_nets.discard(net)
            continue

        start_idx = 0
        if len(pad_groups) >= 3:
            best_pair_d = 1e9
            for i_pg in range(len(pad_groups)):
                for j_pg in range(i_pg + 1, len(pad_groups)):
                    dp = math.hypot(pad_groups[i_pg][0][1] - pad_groups[j_pg][0][1], pad_groups[i_pg][0][2] - pad_groups[j_pg][0][2])
                    if dp < best_pair_d:
                        best_pair_d = dp
                        start_idx = i_pg
        in_tree = [pad_groups[start_idx]]
        rem = [g for k, g in enumerate(pad_groups) if k != start_idx]
        tree_nodes: list[tuple[int, float, float]] = list(pad_groups[start_idx])
        net_ok = True
        while rem:
            best_idx = 0
            best_d = 1e9
            for idx_r, rp_grp in enumerate(rem):
                rc = rp_grp[0]
                for tp_grp in in_tree:
                    tc = tp_grp[0]
                    d = math.hypot(rc[1] - tc[1], rc[2] - tc[2])
                    if d < best_d:
                        best_d = d
                        best_idx = idx_r
            target_grp = rem.pop(best_idx)
            res = route_fine_astar(fb, net, tree_nodes, target_grp, step=0.125, hw=HW_NEW)
            pts_125 = list(LAST_BLOCKED_PTS)
            if res is None:
                print(f"  [WARN] 0.125mm failed on {net}, retrying at 0.100mm / 0.0625mm...", flush=True)
                res = route_fine_astar(fb, net, tree_nodes, target_grp, step=0.100, hw=HW_NEW)
                if res is None:
                    res = route_fine_astar(fb, net, tree_nodes, target_grp, step=0.0625, hw=HW_NEW)
            if res is None:
                comb_pts = pts_125 + list(LAST_BLOCKED_PTS)
                blocked_search = comb_pts if comb_pts else (target_grp + tree_nodes[:4])
                blocker = (
                    find_blocker_near(blocked_search, net, rip_counts, last_victim)
                    or find_blocker_near(target_grp, net, rip_counts, last_victim)
                    or find_blocker_near(tree_nodes[:4], net, rip_counts, last_victim)
                )
                if blocker and total_rips < 200:
                    rip_counts[blocker] += 1
                    total_rips += 1
                    last_victim = blocker
                    rip_net_live(blocker)
                    rip_net_live(net)
                    polish_nets.add(blocker)
                    ordered_nets.insert(idx_q - 1, net)
                    ordered_nets.append(blocker)
                    net_ok = False
                    break
                print(f"  [FAIL] Could not route {net} -> {target_grp[0]}", flush=True)
                return 1
            segs, vias = res
            commit_route(net, segs, vias)
            in_tree.append(target_grp)
            tree_nodes.extend(target_grp)
            for li, u0, v0, u1, v1 in segs:
                tree_nodes.append((li, u0, v0))
                tree_nodes.append((li, u1, v1))
            print(f"  [OK] Routed {net} edge ({len(segs)} segs, {len(vias)} vias)", flush=True)
        if not net_ok:
            continue
        unrouted_nets.discard(net)

    # Helper to expand all connected GND points around a DRC unconnected seed
    def expand_gnd_island(seed: tuple[int, float, float]) -> list[tuple[int, float, float]]:
        pts = [seed]
        g_segs: list[tuple[int, float, float, float, float]] = []
        for itm in alive_tracks:
            if itm.GetNetname() != "GND" or isinstance(itm, pcbnew.PCB_VIA):
                continue
            li = LYR_CU.get(itm.GetLayer(), -1)
            if li >= 0:
                u0, v0 = xy_to_uv(pcbnew.ToMM(itm.GetStart().x), pcbnew.ToMM(itm.GetStart().y))
                u1, v1 = xy_to_uv(pcbnew.ToMM(itm.GetEnd().x), pcbnew.ToMM(itm.GetEnd().y))
                g_segs.append((li, u0, v0, u1, v1))
        changed = True
        while changed:
            changed = False
            for vu, vv in gnd_via_uvs:
                if any(math.hypot(vu - pu, vv - pv) < 0.08 for _, pu, pv in pts):
                    for l in (0, 1, 2, 3):
                        if not any(pl == l and math.hypot(vu - pu, vv - pv) < 0.03 for pl, pu, pv in pts):
                            pts.append((l, vu, vv))
                            changed = True
            for li, u0, v0, u1, v1 in g_segs:
                d_min = min(math.sqrt(pt_seg_dist2(pu, pv, u0, v0, u1, v1)) for pl, pu, pv in pts if pl == li) if any(pl == li for pl, _, _ in pts) else 9.0
                if d_min < 0.08:
                    for eu, ev in ((u0, v0), (u1, v1), ((u0 + u1) * 0.5, (v0 + v1) * 0.5)):
                        if not any(pl == li and math.hypot(eu - pu, ev - pv) < 0.04 for pl, pu, pv in pts):
                            pts.append((li, eu, ev))
                            changed = True
            for pl, pu, pv in net_pad_flat["GND"]:
                if any(ql == pl and math.hypot(pu - qu, pv - qv) < 0.25 for ql, qu, qv in pts):
                    if not any(ql == pl and math.hypot(pu - qu, pv - qv) < 0.04 for ql, qu, qv in pts):
                        pts.append((pl, pu, pv))
                        changed = True
        return pts

    # Stitch any unconnected GND pairs reported by DRC
    for idx_g, (p_src, p_dst) in enumerate(unconn_gnd_pairs):
        srcs = expand_gnd_island(p_src)
        dsts = expand_gnd_island(p_dst)
        print(f"  [GND] Stitching pair #{idx_g}: {p_src} ({len(srcs)} pts) <-> {p_dst} ({len(dsts)} pts)", flush=True)
        res = route_fine_astar(fb, "GND", srcs, dsts, step=0.125, hw=HW_NEW)
        if res is None:
            res = route_fine_astar(fb, "GND", srcs, dsts, step=0.100, hw=HW_NEW)
        if res is None:
            # Fallback: connect whichever island is smaller to any nearby main-net GND via/pad
            smaller = srcs if len(srcs) <= len(dsts) else dsts
            main_gnd = [(l, vu, vv) for vu, vv in gnd_via_uvs for l in (0, 1, 2, 3) if all(math.hypot(vu - su, vv - sv) > 0.35 for _, su, sv in smaller)]
            main_gnd.extend([p for p in net_pad_flat["GND"] if all(math.hypot(p[1] - su, p[2] - sv) > 0.35 for _, su, sv in smaller)])
            res = route_fine_astar(fb, "GND", smaller, main_gnd, step=0.100, hw=HW_NEW)
        if res is not None:
            commit_route("GND", res[0], res[1])
            print(f"  [OK] Stitched GND pair #{idx_g} ({len(res[0])} segs, {len(res[1])} vias)", flush=True)
        else:
            print(f"  [WARN] Could not stitch GND pair #{idx_g}: {p_src} -> {p_dst}", flush=True)

    pcbnew.ZONE_FILLER(board).Fill(board.Zones())
    conn = board.GetConnectivity()
    conn.Build(board)
    print(f"Polish complete in {time.time() - t0:.2f}s — pcbnew unconnected count: {conn.GetUnconnectedCount(False)}", flush=True)
    pcbnew.SaveBoard(str(pcb_path), board)
    return 0


if __name__ == "__main__":
    sys.exit(polish_board(PCB_DIR / f"{PROJECT_NAME}.kicad_pcb", PCB_DIR / "build" / "drc.json"))
