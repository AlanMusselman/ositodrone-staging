#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OSITO DRONE LLC — NATIVE KICAD 10 RAYTRACED FRAME + FC + MOTOR-WIRE ROUTING RENDERER
====================================================================================
Uses KiCad 10's bundled `pcbnew` + `kicad-cli.exe pcb render --quality high` to render
the upgraded multi-rotor Binary `.stl` airframes mated with `OSITO_KODIAK_FC_v1.kicad_pcb`,
4x brushless motors, and 4x 5-stage 30AWG color-coded (U/V/W) motor wire harnesses
terminating directly into the live `J_M1..J_M4` JST-1.25mm footprints on the PCB.

Architecture Invariant:
  All VRML 2.0 `.wrl` (`1 unit = 2.54 mm`) airframe + harness assemblies are attached
  ONLY to temporary staging copies of `OSITO_KODIAK_FC_v1.kicad_pcb` inside
  `tempfile.TemporaryDirectory()`, leaving the production `.kicad_pcb` 100% clean.
"""

from __future__ import annotations

import math
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import pcbnew
from PIL import Image, ImageDraw

ROOT = Path(r"c:\Users\Alan Musselman\OneDrive\Documents\Osito drone")
PCB_DIR = ROOT / "03_Hardware_and_Drones/Active_Subprojects/Bumper Drones/pcb"
PCB_PATH = PCB_DIR / "OSITO_KODIAK_FC_v1.kicad_pcb"
SHAPES_DIR = PCB_DIR / "OSITO_KODIAK.3dshapes"
OUT_DIR = PCB_DIR / "build/frames_kicad_renders"
KICAD_CLI = r"C:\Program Files\KiCad\10.0\bin\kicad-cli.exe"

VRML_SCALE = 1.0 / 2.54  # KiCad VRML 2.0: 1 unit = 2.54 mm (0.1 inch)

STL_DTYPE = np.dtype(
    [
        ("normal", "<f4", (3,)),
        ("v0", "<f4", (3,)),
        ("v1", "<f4", (3,)),
        ("v2", "<f4", (3,)),
        ("attr", "<u2"),
    ]
)


def load_binary_stl(stl_path: Path) -> np.ndarray:
    data = stl_path.read_bytes()
    n_tris = struct.unpack("<I", data[80:84])[0]
    return np.frombuffer(data[84 : 84 + n_tris * 50], dtype=STL_DTYPE).copy()


# ---------------------------------------------------------------------------
# VRML 2.0 Mesh Builders (`1 unit = 2.54 mm`)
# ---------------------------------------------------------------------------
def vrml_shape_from_indexed(
    verts_mm: np.ndarray,
    tris: np.ndarray,
    z_fc_top_mm: float,
    diffuse: tuple[float, float, float],
    specular: tuple[float, float, float] = (0.22, 0.22, 0.25),
    shininess: float = 0.28,
    transparency: float = 0.0,
) -> str:
    v_wrl = verts_mm.astype(np.float64).copy()
    v_wrl[:, 2] -= z_fc_top_mm
    v_wrl *= VRML_SCALE

    coord_str = ",\n          ".join(f"{p[0]:.5f} {p[1]:.5f} {p[2]:.5f}" for p in v_wrl)
    idx_str = ",\n          ".join(f"{int(t[0])},{int(t[1])},{int(t[2])},-1" for t in tris)
    return f"""Shape {{
  appearance Appearance {{
    material Material {{
      diffuseColor {diffuse[0]:.3f} {diffuse[1]:.3f} {diffuse[2]:.3f}
      specularColor {specular[0]:.3f} {specular[1]:.3f} {specular[2]:.3f}
      ambientIntensity 0.35
      shininess {shininess:.2f}
      transparency {transparency:.2f}
    }}
  }}
  geometry IndexedFaceSet {{
    solid FALSE
    creaseAngle 0.55
    coord Coordinate {{
      point [
          {coord_str}
      ]
    }}
    coordIndex [
          {idx_str}
    ]
  }}
}}
"""


def stl_to_vrml_shape(
    stl_path: Path,
    z_fc_top_mm: float,
    diffuse: tuple[float, float, float],
    z_offset_mm: float = 0.0,
    transparency: float = 0.0,
    flip_x_z: float | None = None,
) -> str:
    arr = load_binary_stl(stl_path)
    pts = np.stack([arr["v0"], arr["v1"], arr["v2"]], axis=1).reshape(-1, 3).astype(np.float64)
    if flip_x_z is not None:
        pts[:, 1] = -pts[:, 1]
        pts[:, 2] = flip_x_z - pts[:, 2]
    if abs(z_offset_mm) > 1e-6:
        pts[:, 2] += z_offset_mm
    q = np.rint(pts * 2000.0).astype(np.int64)
    _, first_idx, inv = np.unique(q, axis=0, return_index=True, return_inverse=True)
    uniq_pts = pts[first_idx]
    tris = inv.reshape(-1, 3).copy()
    if flip_x_z is not None:
        tris[:, [1, 2]] = tris[:, [2, 1]]
    return vrml_shape_from_indexed(uniq_pts, tris, z_fc_top_mm, diffuse=diffuse, transparency=transparency)


def make_cylinder_indexed(cx: float, cy: float, z0: float, z1: float, r: float, segs: int = 24) -> tuple[np.ndarray, np.ndarray]:
    verts = [[cx, cy, z0], [cx, cy, z1]]
    for i in range(segs):
        a = 2.0 * math.pi * i / segs
        ca, sa = math.cos(a), math.sin(a)
        verts.append([cx + r * ca, cy + r * sa, z0])
        verts.append([cx + r * ca, cy + r * sa, z1])
    tris = []
    for i in range(segs):
        b0 = 2 + 2 * i
        t0 = b0 + 1
        b1 = 2 + 2 * ((i + 1) % segs)
        t1 = b1 + 1
        tris.append([0, b1, b0])
        tris.append([1, t0, t1])
        tris.append([b0, b1, t1])
        tris.append([b0, t1, t0])
    return np.array(verts, dtype=np.float64), np.array(tris, dtype=np.int32)


def catmull_rom_chain(ctrl: list[tuple[float, float, float]], samples_per_seg: int = 8) -> np.ndarray:
    pts = [ np.array(ctrl[0], dtype=np.float64) ] + [ np.array(p, dtype=np.float64) for p in ctrl ] + [ np.array(ctrl[-1], dtype=np.float64) ]
    out = []
    for i in range(1, len(pts) - 2):
        p0, p1, p2, p3 = pts[i - 1], pts[i], pts[i + 1], pts[i + 2]
        n_s = samples_per_seg if i < len(pts) - 3 else samples_per_seg + 1
        for k in range(n_s):
            t = k / float(samples_per_seg)
            t2, t3 = t * t, t * t * t
            pt = 0.5 * (
                (2.0 * p1)
                + (-p0 + p2) * t
                + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t2
                + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t3
            )
            out.append(pt)
    return np.array(out, dtype=np.float64)


def make_tube_indexed(path_pts: np.ndarray, radius: float, segs: int = 10) -> tuple[np.ndarray, np.ndarray]:
    n = len(path_pts)
    verts = []
    tris = []
    up = np.array([0.0, 0.0, 1.0])
    for i in range(n):
        if i == 0:
            tang = path_pts[1] - path_pts[0]
        elif i == n - 1:
            tang = path_pts[-1] - path_pts[-2]
        else:
            tang = path_pts[i + 1] - path_pts[i - 1]
        tl = np.linalg.norm(tang)
        tang = tang / (tl if tl > 1e-9 else 1.0)
        ref = up if abs(np.dot(tang, up)) < 0.92 else np.array([1.0, 0.0, 0.0])
        n1 = np.cross(tang, ref)
        n1 /= np.linalg.norm(n1)
        n2 = np.cross(tang, n1)
        for j in range(segs):
            ang = 2.0 * math.pi * j / segs
            pt = path_pts[i] + radius * (math.cos(ang) * n1 + math.sin(ang) * n2)
            verts.append(pt)
    # End caps
    c_start = len(verts)
    verts.append(path_pts[0])
    c_end = len(verts)
    verts.append(path_pts[-1])

    for i in range(n - 1):
        base0 = i * segs
        base1 = (i + 1) * segs
        for j in range(segs):
            jn = (j + 1) % segs
            tris.append([base0 + j, base0 + jn, base1 + jn])
            tris.append([base0 + j, base1 + jn, base1 + j])
    for j in range(segs):
        jn = (j + 1) % segs
        tris.append([c_start, jn, j])
        tris.append([c_end, (n - 1) * segs + j, (n - 1) * segs + jn])
    return np.array(verts, dtype=np.float64), np.array(tris, dtype=np.int32)


def merge_meshes(parts: list[tuple[np.ndarray, np.ndarray]]) -> tuple[np.ndarray, np.ndarray]:
    v_all = []
    t_all = []
    off = 0
    for v, t in parts:
        v_all.append(v)
        t_all.append(t + off)
        off += len(v)
    return np.vstack(v_all), np.vstack(t_all)


def build_motors_props_and_harnesses_vrml(
    m_rad: float,
    prop_dia: float,
    bell_dia: float,
    z_arm_top: float,
    z_trench: float,
    z_fc_top: float,
    jm_coords_scad: dict[str, tuple[float, float, float]],
) -> str:
    """
    Generates VRML shapes for:
      - 4x Brushless motor stator bases + anodized #7077CF bells + shafts
      - 4x Translucent spinning propeller discs (showing exact duct & FC clearance)
      - 4x Mated JST-1.25mm 3-pin plugs seated in J_M1..J_M4
      - 12x Swept 30AWG silicone motor wires (Red U, Periwinkle V, Gold W) routed
        from the 180-deg stator solder tab -> arm U-channel -> FC waist riser -> J_M1..J_M4!
    """
    motor_defs = [
        ("J_M1", 315.0),  # Rear-Right  (+X, -Y)
        ("J_M2", 45.0),   # Front-Right (+X, +Y)
        ("J_M3", 225.0),  # Rear-Left   (-X, -Y)
        ("J_M4", 135.0),  # Front-Left  (-X, +Y)
    ]

    bell_parts = []
    stator_parts = []
    prop_parts = []
    plug_parts = []
    wire_u_parts = []
    wire_v_parts = []
    wire_w_parts = []

    for ref, ang_deg in motor_defs:
        ar = math.radians(ang_deg)
        ca, sa = math.cos(ar), math.sin(ar)
        # Unit tangent perpendicular to arm (+90 deg CCW)
        tx, ty = -sa, ca
        mx, my = m_rad * ca, m_rad * sa

        # Stator aluminum base + shaft + 180-deg inward PCB solder tab
        stator_parts.append(make_cylinder_indexed(mx, my, z_arm_top + 0.02, z_arm_top + 1.30, 4.20, 20))
        stator_parts.append(make_cylinder_indexed(mx, my, z_arm_top + 1.30, z_arm_top + 8.20, 0.75, 14))
        # Anodized motor bell
        bell_parts.append(make_cylinder_indexed(mx, my, z_arm_top + 1.35, z_arm_top + 5.80, bell_dia * 0.5, 28))
        # Translucent propeller sweep disc
        prop_parts.append(make_cylinder_indexed(mx, my, z_arm_top + 5.85, z_arm_top + 6.55, prop_dia * 0.5, 36))

        # Target JST-1.25mm connector center & orientation on FC F.Cu
        jx, jy, jrot_deg = jm_coords_scad[ref]
        jr = math.radians(jrot_deg)
        j_ux, j_uy = math.cos(jr), math.sin(jr)  # Pin pitch axis (1.25mm pitch for pins 1, 2, 3)

        # Mated ivory JST-1.25mm plug housing seated inside header (z_fc_top + 1.8 .. z_fc_top + 4.1)
        plug_parts.append(make_cylinder_indexed(jx - 1.25 * j_ux, jy - 1.25 * j_uy, z_fc_top + 1.6, z_fc_top + 4.0, 0.85, 12))
        plug_parts.append(make_cylinder_indexed(jx, jy, z_fc_top + 1.6, z_fc_top + 4.0, 0.85, 12))
        plug_parts.append(make_cylinder_indexed(jx + 1.25 * j_ux, jy + 1.25 * j_uy, z_fc_top + 1.6, z_fc_top + 4.0, 0.85, 12))

        # Compute clean outboard waist riser waypoint around the 28.4x28.4mm rotated diamond PCB
        # Diamond PCB edge along `ang_deg` sits at radius ~14.20 mm! So R_waist = 15.60 mm clears FR4 cleanly!
        r_arm_exit = 16.20
        r_waist = 15.65
        # Mid-angle between motor arm and connector vector for smooth waist climb
        j_ang = math.atan2(jy, jx)
        # Shortest angular delta from ar to j_ang
        d_ang = math.atan2(math.sin(j_ang - ar), math.cos(j_ang - ar))
        waist_ang = ar + 0.68 * d_ang
        wx_mid = r_waist * math.cos(waist_ang)
        wy_mid = r_waist * math.sin(waist_ang)

        # 3 phase wires (idx = -1, 0, +1 -> U Red, V Indigo, W Gold)
        for p_idx, bucket in ((-1, wire_u_parts), (0, wire_v_parts), (1, wire_w_parts)):
            lat = p_idx * 0.68  # Fits 3x Ø0.62mm wires side-by-side inside 2.60..2.80mm U-channel!
            pin_x = jx + (p_idx * 1.25) * j_ux
            pin_y = jy + (p_idx * 1.25) * j_uy

            ctrl_pts = [
                # Stage 1: 180-deg inward stator PCB solder tab inside motor pad relief
                ((m_rad - 4.40) * ca + lat * tx, (m_rad - 4.40) * sa + lat * ty, z_trench),
                # Stage 2: Mid-arm protected top U-channel
                ((0.55 * m_rad) * ca + lat * tx, (0.55 * m_rad) * sa + lat * ty, z_trench),
                # Stage 3: Inboard prop-hoop crossing (clears Z=3.0..3.2mm base ring)
                (r_arm_exit * ca + lat * tx, r_arm_exit * sa + lat * ty, max(z_trench + 0.95, 3.35)),
                # Stage 4: FC waist riser climbing outside R=14.2mm FR4 edge
                (wx_mid + 0.55 * lat * tx, wy_mid + 0.55 * lat * ty, z_fc_top + 2.60),
                # Stage 5A: Smooth strain-relief arch above JST-1.25mm plug
                (pin_x + 0.90 * math.cos(waist_ang), pin_y + 0.90 * math.sin(waist_ang), z_fc_top + 5.15),
                # Stage 5B: Vertical entry into mated JST-1.25mm crimp socket
                (pin_x, pin_y, z_fc_top + 3.70),
            ]
            curve = catmull_rom_chain(ctrl_pts, samples_per_seg=7)
            bucket.append(make_tube_indexed(curve, radius=0.31, segs=10))

    chunks = [
        vrml_shape_from_indexed(*merge_meshes(stator_parts), z_fc_top, diffuse=(0.76, 0.79, 0.84), shininess=0.55),
        vrml_shape_from_indexed(*merge_meshes(bell_parts), z_fc_top, diffuse=(0.44, 0.47, 0.81), shininess=0.60),
        vrml_shape_from_indexed(*merge_meshes(plug_parts), z_fc_top, diffuse=(0.94, 0.92, 0.85), shininess=0.20),
        vrml_shape_from_indexed(*merge_meshes(wire_u_parts), z_fc_top, diffuse=(0.92, 0.22, 0.24), shininess=0.35),
        vrml_shape_from_indexed(*merge_meshes(wire_v_parts), z_fc_top, diffuse=(0.30, 0.72, 0.96), shininess=0.35),
        vrml_shape_from_indexed(*merge_meshes(wire_w_parts), z_fc_top, diffuse=(0.96, 0.68, 0.12), shininess=0.35),
        vrml_shape_from_indexed(*merge_meshes(prop_parts), z_fc_top, diffuse=(0.10, 0.75, 0.52), transparency=0.70),
    ]
    return "\n".join(chunks)


def read_live_jm_positions() -> dict[str, tuple[float, float, float]]:
    """Extracts exact (X_scad, Y_scad, rot_deg) of J_M1..J_M4 directly from OSITO_KODIAK_FC_v1.kicad_pcb."""
    board = pcbnew.LoadBoard(str(PCB_PATH))
    coords: dict[str, tuple[float, float, float]] = {}
    for ref in ("J_M1", "J_M2", "J_M3", "J_M4"):
        fp = board.FindFootprintByReference(ref)
        if fp is None:
            raise RuntimeError(f"Footprint {ref} not found on {PCB_PATH.name}")
        pos = fp.GetPosition()
        x_mm = pcbnew.ToMM(pos.x)
        y_scad = -pcbnew.ToMM(pos.y)  # KiCad +Y South -> 3D VRML +Y North
        rot_deg = fp.GetOrientationDegrees()
        coords[ref] = (x_mm, y_scad, rot_deg)
    return coords


FRAME_RENDER_TARGETS = [
    {
        "slug": "01_KODIAK75_Frame_Protected_v2",
        "title": "KODIAK-75 / SHARD-75 Protected v2 (75mm PAHT-CF)",
        "subtitle": "12.40mm Motor Pads (2.20mm Wall) + Top Wire Trench -> J_M1..J_M4",
        "stls": [(ROOT / "03_Hardware_and_Drones/Active_Subprojects/Bumper Drones/cad/KODIAK75_Frame_Protected_v2.stl", (0.16, 0.18, 0.22), 0.0, 0.0)],
        "m_rad": 37.5,
        "prop_dia": 40.0,
        "bell_dia": 13.2,
        "z_arm_top": 2.50,
        "z_trench": 2.05,
        "z_standoff": 5.52,
        "copy_to": ROOT / "03_Hardware_and_Drones/Active_Subprojects/Bumper Drones/cad/KODIAK75_Frame_Protected_v2_KiCad10_WireRouting.png",
    },
    {
        "slug": "02_KODIAK75_Protected_v2_VaultedDeck",
        "title": "KODIAK-75 Protected v2 + Vaulted LOS Deck (Z=5.80mm Risers)",
        "subtitle": "Translucent Deck Proof: Zero Clip on Mated J_M1..J_M4 JST-1.25mm Plugs",
        "stls": [
            (ROOT / "03_Hardware_and_Drones/Active_Subprojects/Bumper Drones/cad/KODIAK75_Frame_Protected_v2.stl", (0.16, 0.18, 0.22), 0.0, 0.0),
            (ROOT / "03_Hardware_and_Drones/Active_Subprojects/Bumper Drones/cad/KODIAK75_Deck_LOS_v1.stl", (0.44, 0.47, 0.81), 6.80, 0.42),
        ],
        "m_rad": 37.5,
        "prop_dia": 40.0,
        "bell_dia": 13.2,
        "z_arm_top": 2.50,
        "z_trench": 2.05,
        "z_standoff": 5.52,
        "copy_to": None,
    },
    {
        "slug": "03_KODIAK75_Frame_Protected_80Pro_45mm",
        "title": "KODIAK-75 80Pro Frame (80.8mm / 45mm Props)",
        "subtitle": "12.40mm Motor Pads (2.20mm Wall) + Extended 45mm-Prop Wire Trench",
        "stls": [(ROOT / "03_Hardware_and_Drones/Active_Subprojects/Bumper Drones/cad/KODIAK75_Frame_Protected_80Pro_45mm.stl", (0.15, 0.19, 0.25), 0.0, 0.0)],
        "m_rad": 40.4,
        "prop_dia": 45.0,
        "bell_dia": 13.5,
        "z_arm_top": 2.50,
        "z_trench": 2.05,
        "z_standoff": 5.52,
        "copy_to": None,
    },
    {
        "slug": "04_KODIAK75_Frame_v1_Guardless",
        "title": "KODIAK-75 Guardless v1 Freestyle X-Frame (75mm)",
        "subtitle": "Restored 2-Manifold X-Frame + 12.40mm Pads + Protected Arm Wire Trench",
        "stls": [(ROOT / "03_Hardware_and_Drones/Active_Subprojects/Bumper Drones/cad/KODIAK75_Frame_v1.stl", (0.18, 0.20, 0.24), 0.0, 0.0)],
        "m_rad": 37.5,
        "prop_dia": 45.0,
        "bell_dia": 13.2,
        "z_arm_top": 2.50,
        "z_trench": 2.05,
        "z_standoff": 5.52,
        "copy_to": None,
    },
    {
        "slug": "05_CUB75_Frame_KidSafe_75mm",
        "title": "CUB-75 Production STEM Trainer (75mm PETG-CF)",
        "subtitle": "Upgraded 12.40mm Motor Pads (was 8.8mm) + 2.70x0.85mm Stator Wire Trench",
        "stls": [(ROOT / "03_Hardware_and_Drones/Core_Fleet/Kids Training Drone/cad/CUB75_Frame_KidSafe_75mm.stl", (0.17, 0.21, 0.27), 0.0, 0.0)],
        "m_rad": 37.5,
        "prop_dia": 40.0,
        "bell_dia": 12.0,
        "z_arm_top": 2.60,
        "z_trench": 2.15,
        "z_standoff": 5.60,
        "copy_to": ROOT / "03_Hardware_and_Drones/Core_Fleet/Kids Training Drone/cad/CUB75_KiCad10_FC_WireRouting.png",
    },
    {
        "slug": "06_CUB75_QB_Frame_75mm_SnapMotor",
        "title": "CUB-75 QuickBuild STEM Frame (75mm SnapMotor)",
        "subtitle": "Upgraded 13.80mm Snap-Motor Pods (1.80mm Collar Wall) + Protected Wire Trench",
        "stls": [(ROOT / "03_Hardware_and_Drones/Core_Fleet/Kids Training Drone/CUB75_30Min_QuickBuild_STEM_Kit/cad/CUB75_QB_Frame_75mm_SnapMotor.stl", (0.19, 0.22, 0.28), 0.0, 0.0)],
        "m_rad": 37.5,
        "prop_dia": 40.0,
        "bell_dia": 12.0,
        "z_arm_top": 3.00,
        "z_trench": 2.55,
        "z_standoff": 6.20,
        "copy_to": None,
    },
    {
        "slug": "07_MINICUB65_GrizzlyRing_Brushless0702",
        "title": "MiniCub-65 GrizzlyRing Brushless 0702SE (65mm)",
        "subtitle": "Upgraded 12.40mm Pads (2.17mm Wall) + Diagonal Stator-to-FC Wire Channels",
        "stls": [(ROOT / "03_Hardware_and_Drones/Core_Fleet/Osito_MiniCub65_BNF/cad/OSITO_MINICUB65_GrizzlyRing65_Frame_Brushless0702.stl", (0.17, 0.19, 0.24), 0.0, 0.0)],
        "flip_x_z": 7.60,
        "m_rad": 32.5,
        "prop_dia": 31.0,
        "bell_dia": 10.0,
        "z_arm_top": 2.60,
        "z_trench": 2.65,
        "z_standoff": 5.52,
        "copy_to": None,
    },
    {
        "slug": "08_THERMO95_Frame_95mm_Ducted",
        "title": "THERMO-95 HVAC Inspection Cinewhoop (95mm PAHT-CF)",
        "subtitle": "Upgraded 19.00mm 1204 Stator Cups (2.11mm M2 Wall) + Protected Arm Trenches",
        "stls": [(ROOT / "03_Hardware_and_Drones/Active_Subprojects/HVAC Inspection Drone/cad/THERMO95_Frame_95mm_Ducted.stl", (0.16, 0.18, 0.22), 0.0, 0.0)],
        "m_rad": 47.5,
        "prop_dia": 51.0,
        "bell_dia": 15.0,
        "z_arm_top": 3.20,
        "z_trench": 2.70,
        "z_standoff": 7.70,
        "copy_to": ROOT / "03_Hardware_and_Drones/Active_Subprojects/HVAC Inspection Drone/cad/THERMO95_KiCad10_FC_WireRouting.png",
    },
    {
        "slug": "09_OSITO_Interceptor_95mm_Frame",
        "title": "OSITO-INT-95 AI Security Interceptor (95mm PAHT-CF)",
        "subtitle": "Upgraded 13.20mm Motor Pads (2.40mm Wall) + 5-Stage Wire Trench to AIO FC",
        "stls": [(ROOT / "03_Hardware_and_Drones/Active_Subprojects/Osito_Security_Services/OSITO_INT_95_Interceptor/OSITO_Interceptor_95mm_Frame.stl", (0.14, 0.16, 0.20), 0.0, 0.0)],
        "m_rad": 33.44 * math.sqrt(2.0),
        "prop_dia": 50.8,
        "bell_dia": 14.2,
        "z_arm_top": 2.50,
        "z_trench": 2.05,
        "z_standoff": 5.50,
        "copy_to": ROOT / "03_Hardware_and_Drones/Active_Subprojects/Osito_Security_Services/OSITO_INT_95_Interceptor/OSITO_INT95_KiCad10_FC_WireRouting.png",
    },
]


def inject_staging_airframe_footprint(pcb_text: str, wrl_filename: str) -> str:
    """Appends a padless mechanical 3D-model footprint at (0,0) on F.Cu to the temporary PCB text."""
    fp_sexpr = f"""
  (footprint "OSITO_KODIAK:AIRFRAME_HARNESS_STAGE"
    (layer "F.Cu")
    (uuid "00000000-0000-4000-8000-00000000f7a3")
    (at 0 0)
    (property "Reference" "MECH_FRAME" (at 0 0 0) (layer "F.Fab") (hide yes) (uuid "00000000-0000-4000-8000-00000000f7a4"))
    (property "Value" "AIRFRAME_3D" (at 0 0 0) (layer "F.Fab") (hide yes) (uuid "00000000-0000-4000-8000-00000000f7a5"))
    (attr board_only exclude_from_pos_files exclude_from_bom)
    (model "${{KIPRJMOD}}/{wrl_filename}"
      (offset (xyz 0 0 0))
      (scale (xyz 1 1 1))
      (rotate (xyz 0 0 0))
    )
  )
)"""
    idx = pcb_text.rfind(")")
    if idx < 0:
        raise ValueError("Invalid .kicad_pcb S-expression")
    return pcb_text[:idx] + fp_sexpr


def main() -> int:
    t0 = time.time()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    jm_coords = read_live_jm_positions()
    print("=" * 92)
    print("LIVE KICAD 10 CONNECTOR TARGETS (EXTRACTED VIA PCBNEW FROM OSITO_KODIAK_FC_v1.kicad_pcb)")
    print("=" * 92)
    for k, (x, y, r) in jm_coords.items():
        print(f"  {k}: X_3d={x:+7.3f} mm, Y_3d={y:+7.3f} mm, rot={r:+6.1f} deg")

    base_pcb_text = PCB_PATH.read_text(encoding="utf-8")
    rendered_cards: list[tuple[dict, Path, Path]] = []

    with tempfile.TemporaryDirectory() as td_str:
        td = Path(td_str)
        # Copy component 3D shapes into temporary staging project dir so ${KIPRJMOD}/OSITO_KODIAK.3dshapes resolves
        shutil.copytree(SHAPES_DIR, td / "OSITO_KODIAK.3dshapes")

        for spec in FRAME_RENDER_TARGETS:
            t_f = time.time()
            z_fc_top = spec["z_standoff"] + 1.00
            vrml_parts = ["#VRML V2.0 utf8\n"]
            for stl_p, diff_rgb, z_off, transp in spec["stls"]:
                if not stl_p.exists():
                    raise FileNotFoundError(f"Missing compiled STL for KiCad render: {stl_p}")
                vrml_parts.append(
                    stl_to_vrml_shape(
                        stl_p,
                        z_fc_top,
                        diffuse=diff_rgb,
                        z_offset_mm=z_off,
                        transparency=transp,
                        flip_x_z=spec.get("flip_x_z"),
                    )
                )

            vrml_parts.append(
                build_motors_props_and_harnesses_vrml(
                    m_rad=spec["m_rad"],
                    prop_dia=spec["prop_dia"],
                    bell_dia=spec["bell_dia"],
                    z_arm_top=spec["z_arm_top"],
                    z_trench=spec["z_trench"],
                    z_fc_top=z_fc_top,
                    jm_coords_scad=jm_coords,
                )
            )
            wrl_name = f"{spec['slug']}.wrl"
            (td / wrl_name).write_text("\n".join(vrml_parts), encoding="utf-8")

            staged_pcb = td / f"{spec['slug']}.kicad_pcb"
            staged_pcb.write_text(inject_staging_airframe_footprint(base_pcb_text, wrl_name), encoding="utf-8")

            top_png = OUT_DIR / f"{spec['slug']}_top.png"
            iso_png = OUT_DIR / f"{spec['slug']}_iso.png"

            # 1. High-quality Top Orthographic Wire-Routing Render
            subprocess.run(
                [
                    KICAD_CLI,
                    "pcb",
                    "render",
                    "--side",
                    "top",
                    "--quality",
                    "high",
                    "--background",
                    "opaque",
                    "--zoom",
                    "0.92",
                    "-w",
                    "1600",
                    "-h",
                    "1300",
                    "-o",
                    str(top_png),
                    str(staged_pcb),
                ],
                check=True,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=120,
            )

            # 2. High-quality 3D Isometric Perspective Render
            subprocess.run(
                [
                    KICAD_CLI,
                    "pcb",
                    "render",
                    "--perspective",
                    "--rotate",
                    "-44,0,36",
                    "--quality",
                    "high",
                    "--background",
                    "opaque",
                    "--zoom",
                    "0.95",
                    "-w",
                    "1600",
                    "-h",
                    "1300",
                    "-o",
                    str(iso_png),
                    str(staged_pcb),
                ],
                check=True,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=120,
            )

            if spec["copy_to"] is not None:
                shutil.copy2(iso_png, spec["copy_to"])

            rendered_cards.append((spec, top_png, iso_png))
            print(
                f"  [OK] {spec['slug']:<42} -> {top_png.name} ({top_png.stat().st_size//1024} KB) "
                f"& {iso_png.name} ({iso_png.stat().st_size//1024} KB) in {time.time() - t_f:.1f}s"
            )

    # Compose 3x3 Master Fleet KiCad 10 Raytraced Wire-Routing Sheet (`ositodrone.com` sharp 0px tokens)
    W, H = 2400, 1960
    sheet = Image.new("RGB", (W, H), (246, 246, 246))
    draw = ImageDraw.Draw(sheet)

    draw.rectangle([0, 0, W, 86], fill=(22, 22, 22))
    draw.rectangle([0, 86, W, 92], fill=(112, 119, 207))
    draw.text(
        (32, 20),
        "OSITO DRONE LLC  |  NATIVE KICAD 10 RAYTRACED FLEET AIRFRAMES + OSITO_KODIAK_FC_v1 + 5-STAGE MOTOR WIRE ROUTING",
        fill=(255, 255, 255),
    )
    draw.text(
        (32, 50),
        "Rendered via `kicad-cli pcb render --quality high`  |  Expanded Motor Pads (>=2.11-2.40mm Solid Wall)  |  U/V/W 30AWG Harnesses -> Live J_M1..J_M4 JST-1.25mm Headers",
        fill=(192, 198, 244),
    )

    cw, ch = 768, 590
    for idx, (spec, top_p, iso_p) in enumerate(rendered_cards):
        col = idx % 3
        row = idx // 3
        x0 = 24 + col * (cw + 24)
        y0 = 114 + row * (ch + 20)
        draw.rectangle([x0, y0, x0 + cw, y0 + ch], fill=(255, 255, 255), outline=(226, 226, 226), width=2)
        draw.rectangle([x0, y0, x0 + cw, y0 + 38], fill=(35, 42, 104))
        draw.text((x0 + 12, y0 + 6), spec["title"], fill=(255, 255, 255))
        draw.text((x0 + 12, y0 + 21), spec["subtitle"], fill=(196, 202, 248))

        # Side-by-side Top Orthographic (left half) + 3D Isometric Raytrace (right half) inside each card!
        im_top = Image.open(top_p).convert("RGB").resize((372, 520), Image.Resampling.LANCZOS)
        im_iso = Image.open(iso_p).convert("RGB").resize((372, 520), Image.Resampling.LANCZOS)
        sheet.paste(im_top, (x0 + 8, y0 + 46))
        sheet.paste(im_iso, (x0 + 388, y0 + 46))
        draw.rectangle([x0 + 8, y0 + 544, x0 + 150, y0 + 566], fill=(22, 22, 22))
        draw.text((x0 + 14, y0 + 549), "TOP ORTHO ROUTING", fill=(255, 255, 255))
        draw.rectangle([x0 + 388, y0 + 544, x0 + 536, y0 + 566], fill=(22, 22, 22))
        draw.text((x0 + 394, y0 + 549), "3D RAYTRACED ISO", fill=(112, 119, 207))

    master_png = OUT_DIR / "OSITO_Fleet_Frames_KiCad10_WireRouting_MasterSheet.png"
    sheet.save(master_png, format="PNG")
    shutil.copy2(
        master_png,
        ROOT / "03_Hardware_and_Drones/Active_Subprojects/Bumper Drones/cad/OSITO_Fleet_Frames_KiCad10_WireRouting_MasterSheet.png",
    )
    print(f"\n[DONE] Saved master KiCad 10 sheet: {master_png} ({master_png.stat().st_size // 1024} KB) in {time.time() - t0:.1f}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
