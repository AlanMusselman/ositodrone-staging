# OSITO-KODIAK-G473 (`OSITO_KODIAK_FC_v1`): Datasheet & Firmware Pinout Verification

**Project:** `OSITO_KODIAK_FC_v1` — 4-Layer 1S 12A 5-in-1 Brushless Flight Controller for **CUB-75** (`39.5g` STEM Trainer) & **SHARD-75 / KODIAK-75** (`45.5g` Combat/Bumper Drone)  
**Toolchain:** Native KiCad `10.0.8` (`pcbnew` + `kicad-cli`) under `kicad-pcb-workflow`

---

## 1. Verified Source Datasheets & Firmware Targets (`datasheets/`)

| File in `datasheets/` | Authority / Part | Key Verified Pinout & Design Rules |
| :--- | :--- | :--- |
| [`BETAFPVG473_config.h`](./datasheets/BETAFPVG473_config.h) | Official Betaflight `BETAFPVG473` (`STM32G473CEU6` UFQFPN-48) | `M1=PB0 (17)`, `M2=PB1 (18)`, `M3=PB6 (44)`, `M4=PC13 (2)`, `LED_STRIP=PB2 (19)`, `SPI1=PA5/PA6/PA7 + CS PA4 + EXTI PC4`, `SPI2=PB13/PB14/PB15 + OSD_CS PB12`, `UART2_TX (VTX SmartAudio)=PA2 (10)`, `UART3 (ELRS CRSF)=PB10/PB11 (22/24)`, `ADC_BATT=PA0 (8)`, `ADC_CURR=PA1 (9)`, `HIT_DETECT=PC6 (29)`, `USB=PA11/PA12 (33/34)`, `PB8-BOOT0 (46)` pulled low via `10k`. |
| [`Bluejay_O.inc`](./datasheets/Bluejay_O.inc) & [`Bluejay_Base.inc`](./datasheets/Bluejay_Base.inc) | Official Bluejay `O-H-5` (`EFM8BB21F16G` QFN-20) | `RTX_PIN=P0.5 (17)`, `B_Mux=P0.0 (2)`, `C_Mux=P0.1 (1)`, `A_Mux=P0.2 (20)`, `V_Mux=P0.3 (19)`, `A_Pwm=P1.0 (14)`, `A_Com=P1.1 (13)`, `B_Pwm=P1.2 (11)`, `B_Com=P1.3 (10)`, `C_Pwm=P1.4 (9)`, `C_Com=P1.5 (8)`, `GND=3,12,21`, `VDD=4`, `C2CK=5 (NC)`, `C2D=6 (NC)`. |
| [`TPS63020_SLVS916.pdf`](./datasheets/TPS63020_SLVS916.pdf) | TI `TPS63020DSJR` (`VSON-14` `DSJ`, Page 4) | `1=VINA (+VBAT + 100nF C_VINA)`, `2=GND`, `3=FB (0.5V ref -> 910k/100k = 5.05V)`, `4,5=VOUT (+5V_BEC)`, `6,7=L2`, `8,9=L1 (1.5uH 4.2A)`, `10,11=VIN (+VBAT)`, `12=EN (+VBAT)`, `13=PS/SYNC (+VBAT Forced PWM)`, `14=PG (NC)`, `15 (EP)=GND`. |
| [`DRV5032_SLVSDC7.pdf`](./datasheets/DRV5032_SLVSDC7.pdf) | TI `DRV5032FADBZR` (`SOT-23` `DBZ`, Page 3) | `1=VCC (+3V3_MCU + 100nF C_HALL)`, `2=OUT (Push-pull omnipolar 4.8mT -> STM32 PC6)`, `3=GND`. |
| [`ICM-42688-P_DS-000347.pdf`](./datasheets/ICM-42688-P_DS-000347.pdf) | TDK `ICM-42688-P` (`LGA-14` `2.5x3.0mm`) | `1=SDO (PA6)`, `4=nCS (PA4)`, `5=SCLK (PA5)`, `6=SDI (PA7)`, `8=INT1 (PC4)`, `10,11=RESV (GND)`, `12=GND`, `13=VDD (+3V3_GYRO)`, `14=VDDIO (+3V3_GYRO)`; `2,3,7,9=NC`. |
| `AT7456E` / `MAX7456` HTSSOP-28-EP | Analog Betaflight OSD Generator (`U9`) | `1=VIN (100nF C_VIN from CAM_RAW)`, `3,18=DVDD (+5V_BEC)`, `4,17=DGND`, `5/6=CLKIN/XFB (27.000MHz Y3 + 2x15pF C0G)`, `8..11=SPI2 (/CS, SDIN, SCLK, SDOUT)`, `16=/RESET (10k R_OSD_RST pull-up to +5V_BEC)`, `19,22=AGND`, `20,21=AVDD (+5V_BEC)`, `23=PGND`, `24=PVDD (+5V_BEC)`, `25=SAG (VTX_VIDEO)`, `26=VOUT (22uF X7S C_VOUT to VTX_VIDEO)`, `29 (EP)=GND`. |

---

## 2. Seven Critical Hardware Fixes Applied vs. Legacy `1.9 KB` Stub

1. **Airframe Prop-Duct Clearance (`KODIAK-75` + `CUB-75`)**: Replaced the oversized `38.9 mm` stub polygon (`R = 19.47 mm` on `±45°` arms, which collided `4.57 mm` into `KODIAK-75`'s `14.90 mm` inboard prop hoops) with a contoured **`28.40 × 28.40 mm` Whoop Cardinal Diamond** (`14.20 mm` waist half-width = `0.70 mm` radial clearance to `14.90 mm` inboard prop hoops, plus `Ø4.90 mm` rounded M2 silicone-grommet ears at `(0, ±18.031 mm)` and `(±18.031, 0 mm)`).
2. **Ultra-Flat `<= 1.1 mm` Bottom Profile & 100% Top-Entry Connectors (`107` SMD Parts: `45` Top / `62` Bottom)**: All 8 plug-and-play sockets (`J_M1..J_M4`, `J_BAT`, `J_USB`, `J_CAM`, `J_LED_EXT`), all 10 `WS2812B-2020` RGB LEDs, `STM32G473`, `ICM-42688-P`, `DRV5032FA`, and the `ESP8285 + SX1281` ELRS 2.4GHz subsystem sit on `F.Cu`, while the `12A` 4-in-1 ESC, `TPS63020` BEC, shunt sense, and `AT7456E` OSD sit cleanly on `B.Cu` (`<= 1.1 mm` height, zero through-hole pins above the 1S LiHV battery bay).
3. **`TPS63020DSJR` Silicon Pinout Fix**: Corrected every pin of `U3` to match TI `SLVS916I` Page 4 (`DSJ` package).
4. **`BETAFPVG473` 100% Firmware Pin Parity**: Mapped `MOTOR1..4` to `PB0, PB1, PB6, PC13`, moved `WS2812B` `LED_STRIP` off `PB8-BOOT0` onto `PB2` (adding `R_BOOT` `10k` pull-down on `PB8`), and wired onboard ELRS `CRSF` to `UART3` (`PB10/PB11`) and VTX SmartAudio to `UART2_TX` (`PA2`) so upstream Betaflight `BETAFPVG473` flashes and flies with zero custom C++ builds.
5. **True Complementary 3-Phase Inverter (`FDMA1032CZ` Dual N+P `DFN-8 2x2mm`)**: Replaced single N-FETs with 12 Dual N+P Complementary half-bridge MOSFETs (`1=S1_N GND`, `2=G1_N Pwm`, `3=S2_P +VBAT`, `4=G2_P Com`, `5..8=Phase Drain`) plus 3-resistor `10k` virtual-neutral BEMF star networks (`R_M1A..R_M4C`) per motor.
6. **Complete `AT7456E` Analog OSD + 5-Pin `J_CAM` Pod Interface + Shunt Amp + USB Protection**: Added mandatory `27.000 MHz` OSD subcarrier crystal (`Y3` + `C_Y3A/B` `15pF C0G`), `/RESET` pull-up (`R_OSD_RST`), AC-coupled `C_VIN` (`100nF X7R`), sag-compensated `C_VOUT` (`22uF X7S`), 5-pin `J_CAM` (`+5V_BEC, GND, CAM_RAW, VTX_VIDEO, UART2_TX`), `INA199A1DCKR` `50V/V` shunt monitor, and `USBLC6-2SC6` + `MBR0520` bench USB protection.
7. **100% High-Temp Capacitor Dielectrics (`X7R` / `X7S` / `C0G`) & 1-to-1 BOM ↔ CPL Parity**: Zero `X5R` ceramics across all 107 SMD components (`22uF 10V 0805 X7S`, `10uF 10V 0603 X7R`, `100nF 16V 0402 X7R`, `15pF/100pF 50V 0402 C0G`).
