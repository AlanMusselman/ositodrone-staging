#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CGAL 3D Boolean Mating Collision, Stator Solder-Tab Relief & Fastener Seating Verification Suite
Proves 0.000 mm^3 interference directly against the compiled Binary STL files across all 3 upgraded
KODIAK-75 frames (`Protected_v2`, `Protected_80Pro_45mm`, `Frame_v1`) and mated accessory STLs against:
  1. Spinning 40mm / 45mm propellers (+0.20mm radial runout envelope, Z = 2.60 .. 8.45mm)
  2. 25.5x25.5mm Whoop AIO FC PCB + 4x M2 stack screws (cardinal diamond 0/90/180/270 deg at R = 18.031mm)
  3. 4x 0803/1002/1102 motor bells (13.8mm OD), 2.15mm shafts/C-clips, 12x M1.4 screws + 2.60mm button heads
  4. 4x 180-deg radial motor stator PCB wire-solder tabs (R_local = 4.10..6.20mm, 2.40mm wide, protruding
     0.75mm below Z = 2.50mm) + 3x 30AWG motor wire ribbons routed inside the Z = 1.65..2.50mm arm trench
     straight through the Z = 3.00mm inboard prop-hoop wall into the FC bay!
  5. Mated compiled `KODIAK75_550Cradle_v1.stl`, `KODIAK75_Deck_FPV_v1.stl`, `KODIAK75_Deck_LOS_v1.stl`,
     `KODIAK75_Horns_v1.stl`, and Cheek N52 Magnets (2.00x1.00mm)
  6. 100% solid 2.50mm clamping land around all 12x d=2.60mm M1.4 screw seats AND d=7.80mm aluminum stator ring!
"""

import os
import subprocess
import tempfile
from pathlib import Path

OPENSCAD_CLI = r"C:\Program Files\OpenSCAD\openscad.com"
CAD_DIR = Path(r"c:\Users\Alan Musselman\OneDrive\Documents\Osito drone\03_Hardware_and_Drones\Active_Subprojects\Bumper Drones\cad")

COLLISION_SCAD_TEMPLATE = """
$fn = 64;
fc_r = 25.5 / sqrt(2);

module hardware_and_mated_stls(wb_diag, prop_d, has_hoops) {{
    m_rad = wb_diag / 2.0;
    bridge_r = m_rad / sqrt(2);

    union() {{
        // 1. 4x Spinning Propellers (prop_d + 0.20mm runout margin, Z = 2.60 .. 8.45mm)
        for (ang = [45, 135, 225, 315]) {{
            rotate([0, 0, ang])
                translate([m_rad, 0, 2.60])
                    cylinder(d=prop_d + 0.20, h=5.85);
        }}

        // 2. 4x Motor Bells (13.8mm OD above Z=2.52mm) + C-clip + 12x M1.4 Screws/Heads + 180-deg Stator Solder Tabs & Wires!
        for (ang = [45, 135, 225, 315]) {{
            rotate([0, 0, ang]) {{
                translate([m_rad, 0, 0]) {{
                    translate([0, 0, 2.52])
                        cylinder(d=13.8, h=8.0);
                    translate([0, 0, -0.50])
                        cylinder(d=2.15, h=3.50);
                    for (m_ang = [0, 120, 240]) {{
                        rotate([0, 0, m_ang])
                            translate([3.30, 0, 0]) {{
                                translate([0, 0, -1.00])
                                    cylinder(d=1.40, h=4.50);
                                translate([0, 0, -1.02])
                                    cylinder(d=2.60, h=1.00);
                            }}
                    }}
                    // 180-deg inward 3-pad (U/V/W) stator PCB wire-solder tab protruding 0.75mm below Z=2.50mm (Z=1.75..2.52mm)
                    translate([-6.20, -1.20, 1.75])
                        cube([2.00, 2.40, 0.77]);
                }}
                // 3x 30AWG motor wire ribbon (2.40mm wide x 0.78mm tall at Z=1.70..2.48mm) running straight through hoop wall to AIO corner pads!
                translate([11.65, -1.20, 1.70])
                    cube([(m_rad - 4.20) - 11.65, 2.40, 0.78]);
            }}
        }}

        // 3. 4x M2 FC Stack Screws (d=2.00mm) + Full 3D OSITO_KODIAK_FC_v1 Board (Z=5.52..6.52mm),
        //    B.Cu Inductor/POSCAPs (Z=4.00..5.52mm), F.Cu J_M1..J_M4 JST-1.25mm Vertical Sockets +
        //    Mated Plugs + Routed 30AWG Motor Wire Loops (Z=1.70..12.10mm), J_BAT, J_LED_EXT, J_CAM, J_USB, ANT1!
        for (c_ang = [0, 90, 180, 270]) {{
            rotate([0, 0, c_ang])
                translate([fc_r, 0, -5.0])
                    cylinder(d=2.00, h=22.0);
        }}
        osito_kodiak_fc_and_routed_harnesses();

        // 4. Actual Compiled Mated STL Accessories: 550mAh Cradle (flipped back under Z=-0.02mm) + FPV & LOS Decks above FC
        translate([0, 0, -0.02])
            rotate([180, 0, 0])
                import("{cad_dir}/KODIAK75_550Cradle_v1.stl");
        translate([0, 0, 6.80])
            import("{cad_dir}/KODIAK75_Deck_FPV_v1.stl");
        translate([0, 0, 6.80])
            import("{cad_dir}/KODIAK75_Deck_LOS_v1.stl");

        // 5. Cheek N52 Magnets (2.00mm OD x 1.00mm thick) seated in 90/270 deg sockets
        if (has_hoops) {{
            for (c_ang = [90, 270]) {{
                rotate([0, 0, c_ang])
                    translate([bridge_r + 2.5, 0, 9.70 - 1.65])
                        cylinder(d=2.00, h=1.00);
            }}
        }} else {{
            // Guardless Frame_v1 mates with KODIAK75_Horns_v1.stl below Z = -0.02mm
            translate([0, 0, -4.02])
                import("{cad_dir}/KODIAK75_Horns_v1.stl");
        }}
    }}
}}

// Exact 3D envelope of OSITO_KODIAK_FC_v1.kicad_pcb + all 8 mated connectors + 4x routed motor harnesses
module osito_kodiak_fc_and_routed_harnesses() {{
    difference() {{
        union() {{
            // 28.4x28.4mm rotated diamond FR4 substrate (trimmed around M2 holes below)
            translate([0, 0, 5.52])
                rotate([0, 0, 45])
                    translate([-14.2, -14.2, 0])
                        cube([28.4, 28.4, 1.00]);
            // B.Cu Tall Components (L1 1.5mm inductor, 2x POSCAP 1.25mm, BB21/FETs 1.20mm -> Z = 4.02..5.52mm)
            translate([-7.5, -7.5, 4.02])
                cube([15.0, 15.0, 1.50]);
            // F.Cu ICs & 10x WS2812B-2020 Status LEDs (including LED3 at (1.27, -14.85), Z = 6.52..7.25mm)
            translate([1.27, -14.85, 6.52])
                rotate([0, 0, 45])
                    translate([-1.05, -1.05, 0])
                        cube([2.10, 2.10, 0.75]);
            // J_M1..J_M4 Vertical JST-1.25mm 3P Sockets + Mated Plugs & Wire Bend Loops (Z = 6.52..12.10mm)
            translate([-3.82, -13.44, 6.52]) rotate([0, 0, 45])   translate([-2.8, -1.6, 0]) cube([5.6, 3.2, 5.58]); // J_M1
            translate([ 5.02, -12.09, 6.52]) rotate([0, 0, 135])  translate([-2.8, -1.6, 0]) cube([5.6, 3.2, 5.58]); // J_M2
            translate([-3.89,  13.22, 6.52]) rotate([0, 0, -45])  translate([-2.8, -1.6, 0]) cube([5.6, 3.2, 5.58]); // J_M3
            translate([13.36,   3.75, 6.52]) rotate([0, 0, -135]) translate([-2.8, -1.6, 0]) cube([5.6, 3.2, 5.58]); // J_M4
            // 4x Routed 30AWG Motor Wire Risers climbing from Z=3.05mm outside R_waist=14.35mm over PCB edge into J_M1..J_M4!
            hull() {{ translate([-7.8, -13.8, 3.05]) cylinder(d=2.2, h=1.0); translate([-5.0, -14.4, 9.80]) cylinder(d=2.2, h=1.8); }} // M1 riser
            hull() {{ translate([ 7.2, -14.2, 3.05]) cylinder(d=2.2, h=1.0); translate([ 6.0, -13.2, 9.80]) cylinder(d=2.2, h=1.8); }} // M2 riser
            hull() {{ translate([-7.8,  13.8, 3.05]) cylinder(d=2.2, h=1.0); translate([-5.0,  14.2, 9.80]) cylinder(d=2.2, h=1.8); }} // M3 riser
            hull() {{ translate([14.4,   7.2, 3.05]) cylinder(d=2.2, h=1.0); translate([14.2,   4.8, 9.80]) cylinder(d=2.2, h=1.8); }} // M4 riser
            // J_BAT (BT2.0 RA, Z=6.52..9.70mm), J_LED_EXT (JST-SH-3P, Z=6.52..9.40mm), J_CAM, J_USB, ANT1
            translate([-12.59, -4.38, 6.52]) rotate([0, 0, 45])  translate([-2.6, -2.2, 0]) cube([5.2, 4.4, 3.18]);
            translate([-12.80,  3.46, 6.52]) rotate([0, 0, 135]) translate([-2.6, -1.8, 0]) cube([5.2, 3.6, 2.88]);
            translate([  7.28,  8.27, 6.52]) rotate([0, 0, 45])  translate([-3.4, -2.0, 0]) cube([6.8, 4.0, 2.88]);
            translate([ -6.22, -7.64, 6.52]) rotate([0, 0, 135]) translate([-3.0, -2.0, 0]) cube([6.0, 4.0, 2.88]);
            translate([  3.39, 14.00, 6.52]) rotate([0, 0, 45])  translate([-1.6, -1.6, 0]) cube([3.2, 3.2, 3.18]);
        }}
        for (c_ang = [0, 90, 180, 270]) {{
            rotate([0, 0, c_ang])
                translate([fc_r, 0, 5.0])
                    cylinder(d=2.10, h=3.0);
        }}
    }}
}}

intersection() {{
    import("{cad_dir}/{frame_stl}");
    hardware_and_mated_stls({wb_diag}, {prop_d}, {has_hoops});
}}
"""

SCREW_AND_STATOR_SEAT_TEMPLATE = """
$fn = 64;

// Verify that 12x d=2.60mm M1.4 screw-head clamping rings (Z=0.02..2.48mm) AND 4x d=7.80mm
// machined aluminum stator mounting rings (d_in=2.40, d_out=7.80, Z=0.02..2.48mm minus screw holes)
// are 100% enclosed inside solid 2.50mm motor-pad material!
module clamping_lands(wb_diag) {{
    m_rad = wb_diag / 2.0;
    for (ang = [45, 135, 225, 315]) {{
        rotate([0, 0, ang])
            translate([m_rad, 0, 0.02]) {{
                difference() {{
                    union() {{
                        cylinder(d=7.80, h=2.46);
                        for (m_ang = [0, 120, 240]) {{
                            rotate([0, 0, m_ang])
                                translate([3.30, 0, 0])
                                    cylinder(d=2.60, h=2.46);
                        }}
                    }}
                    translate([0, 0, -0.1]) cylinder(d=2.40, h=2.70);
                    for (m_ang = [0, 120, 240]) {{
                        rotate([0, 0, m_ang])
                            translate([3.30, 0, -0.1])
                                cylinder(d=1.55, h=2.70);
                    }}
                }}
            }}
    }}
}}

difference() {{
    clamping_lands({wb_diag});
    import("{cad_dir}/{frame_stl}");
}}
"""


def run_empty_csg_check(label: str, scad_code: str):
    with tempfile.TemporaryDirectory() as td:
        scad_f = os.path.join(td, "check.scad")
        stl_f = os.path.join(td, "out.stl")
        with open(scad_f, "w", encoding="utf-8") as f:
            f.write(scad_code)
        res = subprocess.run(
            [OPENSCAD_CLI, "--export-format", "binstl", "-o", stl_f, scad_f],
            capture_output=True,
            text=True,
            timeout=120,
        )
        out = (res.stdout or "") + "\n" + (res.stderr or "")
        is_empty = ("Current top level object is empty" in out) and (not os.path.exists(stl_f) or os.path.getsize(stl_f) <= 84)
        status = "PASS (0.000 mm^3)" if is_empty else f"FAIL! Output:\n{out}"
        print(f"  [{status}] {label}")
        if not is_empty:
            raise AssertionError(f"Boolean check failed for {label}: {out}")


def main():
    print("=" * 88)
    print("RUNNING CGAL 3D BOOLEAN COLLISION, STATOR SOLDER-TAB & CLAMPING TESTS ON BINARY STLS")
    print("=" * 88)
    cad_str = str(CAD_DIR).replace("\\", "/")

    cases = [
        ("KODIAK75_Frame_Protected_v2.stl (75mm / 40mm Props)", "KODIAK75_Frame_Protected_v2.stl", 75.0, 40.0, "true"),
        ("KODIAK75_Frame_Protected_80Pro_45mm.stl (80.8mm / 45mm Props)", "KODIAK75_Frame_Protected_80Pro_45mm.stl", 80.8, 45.0, "true"),
        ("KODIAK75_Frame_v1.stl (75mm Guardless + Horns / 45mm Props)", "KODIAK75_Frame_v1.stl", 75.0, 45.0, "false"),
    ]
    for title, stl_name, wb, pdia, hoops in cases:
        code_col = COLLISION_SCAD_TEMPLATE.format(
            cad_dir=cad_str, frame_stl=stl_name, wb_diag=wb, prop_d=pdia, has_hoops=hoops
        )
        run_empty_csg_check(f"Zero-Interference Hardware + Wire Trench + Mated STLs -> {title}", code_col)

        code_seat = SCREW_AND_STATOR_SEAT_TEMPLATE.format(
            cad_dir=cad_str, frame_stl=stl_name, wb_diag=wb
        )
        run_empty_csg_check(f"100% Solid 2.5mm M1.4 Screw + d=7.8mm Stator Seat -> {title}", code_seat)

    # Also prove 0.000 mm^3 collision between BOTH upper decks (Deck_LOS & Deck_FPV at Z=6.80mm)
    # and the full 3D OSITO_KODIAK_FC_v1 + J_M1..J_M4 mated plugs + routed motor wire risers + 40/45mm props!
    for deck_stl in ("KODIAK75_Deck_LOS_v1.stl", "KODIAK75_Deck_FPV_v1.stl"):
        deck_check_scad = COLLISION_SCAD_TEMPLATE.split("intersection()")[0] + f"""
intersection() {{
    translate([0, 0, 6.80])
        import("{cad_str}/{deck_stl}");
    union() {{
        osito_kodiak_fc_and_routed_harnesses();
        for (ang = [45, 135, 225, 315]) {{
            rotate([0, 0, ang])
                translate([37.5, 0, 2.60])
                    cylinder(d=45.20, h=8.00);
        }}
    }}
}}
"""
        run_empty_csg_check(f"Zero-Interference Upper Deck + OSITO_KODIAK_FC_v1 + 4x Motor Harnesses -> {deck_stl}", deck_check_scad)

    print("ALL 8 CGAL 3D BOOLEAN BINARY-STL COLLISION, FC-HARNESS, WIRE-TRENCH & CLAMPING CHECKS PASSED!")


if __name__ == "__main__":
    main()
