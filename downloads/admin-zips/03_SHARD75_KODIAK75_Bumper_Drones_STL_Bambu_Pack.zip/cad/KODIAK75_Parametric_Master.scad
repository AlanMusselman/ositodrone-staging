// ============================================================================
// KODIAK-75: Production Parametric CAD Master (OpenSCAD CSG) — Rev 3.3
// True Boolean CSG Geometry — Verified for Physical Clearance & Printability
// ============================================================================
// REAL-WORLD ENGINEERING VERIFICATION (Rev 3.3 — Reinforced Pads + FC Wire Routing):
// 1. 75.0mm Standard Frame (KODIAK75_Frame_Protected_v2.stl):
//    - Uses 42.0mm ID / 45.2mm OD 360° prop hoops for 40mm (Gemfan 1610/1635)
//      props. Inboard hoop edge sits at R = 37.5 - 22.6 = 14.9mm from center,
//      clearing the 25.5x25.5mm Whoop AIO FC PCB (14.2mm half-width) completely!
// 2. 80.8mm "75 Pro" Frame (KODIAK75_Frame_Protected_80Pro_45mm.stl):
//    - Matches BetaFPV Meteor75 Pro 80.8mm diagonal wheelbase (R_motor = 40.4mm)
//      with 47.0mm ID / 50.2mm OD 360° prop hoops for 45mm props, maintaining
//      the exact same 15.3mm inboard FC PCB clearance!
// 3. Reinforced 12.4mm Motor Pads + Teardrop Gussets + Stator Wire U-Channel:
//    - Enlarged motor_boss_dia from 8.6mm to 12.4mm (R = 6.20mm) with smooth 2D
//      teardrop arm gussets and tapered radial struts around the M1.4 3-hole
//      (6.6mm circle) motor mounts + 2.3mm shaft/C-clip relief.
//    - Guarantees >= 2.18-3.55mm (>5 continuous 0.4mm nozzle perimeters) of
//      full-height 2.50mm solid carbon wall around every M1.4 hole across
//      Protected_v2, Protected_80Pro_45mm, and Frame_v1 while staying inside
//      the 12.8-13.8mm motor bell aerodynamic shadow.
//    - Flat Z = 0.000mm Textured PEI bottom across all arms (zero underside
//      bridging/supports) + recessed 2.70mm x 0.85mm top U-channel starting at
//      R_local = 4.05mm (180 deg inward wire exit) to relieve 0803/1002/1102
//      stator PCB solder joints, shield 3x 30AWG motor wires below Z = 2.50mm
//      prop plane, and pass straight through the Z = 3.00mm inboard hoop wall.
// 4. Cardinal Diamond (0, 90, 180, 270 deg at R = 18.031mm) M2 FC standoffs.
// 5. Raised 8.5mm outer 230° prop-guard wall aligned with the spinning prop plane.
// ============================================================================

$fn = 72;

// Overridden via command-line: openscad -D PART_ID=1 ...
// 0 = Exploded Full Assembly Preview
// 1 = KODIAK75_Frame_Protected_v2.stl (75.0mm Wheelbase / 42mm ID Hoops for 40mm Props)
// 2 = KODIAK75_Frame_Protected_80Pro_45mm.stl (80.8mm Wheelbase / 47mm ID Hoops for 45mm Props)
// 4 = KODIAK75_Frame_v1.stl (Guardless Open-Prop 75mm X-Frame)
// 5 = KODIAK75_Horns_v1.stl (Net-Deflection Standoff Horns)
// 6 = KODIAK75_550Cradle_v1.stl (Unobstructed 1S 550mAh Belly Cradle)
// 7 = KODIAK75_Deck_LOS_v1.stl (Contoured LOS LED Dome)
// 8 = KODIAK75_Deck_FPV_v1.stl (Contoured 14x14mm Nano FPV Camera Pod)
// 9 = KODIAK75_ArmorPlates_v1.stl (4x Breakaway Armor Pods + N52 Magnet Cups)
// 10 = KODIAK75_Magnet_Polarity_Wand.stl (Shop Magnet Polarity Assembly Tool)
PART_ID = 0;

// --- Core Parameters ---
arm_width           = 5.2;
arm_height          = 2.5;
wire_chan_width     = 2.70;  // Leaves 2x 1.25mm (3-perimeter) structural side flanges
wire_chan_depth     = 0.85;  // Floor at Z = 1.65mm (10 solid PAHT-CF layers; wires recessed < Z=2.50mm)

// Motor Bosses (0803 / 1002 / 1102: 3-hole 6.6mm bolt circle, M1.4 screws)
// 12.4mm OD (R=6.20mm) provides >= 2.18mm solid carbon wall outside R=4.025mm hole edge
motor_boss_dia      = 12.4;
motor_gusset_span   = 9.5;
motor_hole_circle   = 6.6;
motor_screw_dia     = 1.45;
motor_shaft_dia     = 2.3;

// Flight Controller Mount (25.5 x 25.5mm Whoop AIO Cardinal Diamond)
fc_mount_span       = 25.5;
fc_radius           = fc_mount_span / sqrt(2); // 18.0312 mm at 0, 90, 180, 270 deg
fc_hole_dia         = 2.05;
fc_air_gap          = 3.0;    // Raised standoff height (Z = 2.5 to 5.5mm)

// 1S 550mAh LiHV Battery Cradle (70.0 x 18.5 x 7.5mm internal slot)
batt_len            = 70.0;
batt_width          = 18.5;
batt_height         = 7.5;
cradle_wall         = 1.6;
velcro_slot_w       = 8.5;
velcro_slot_h       = 1.8;

// Anti-Shatter N52 Magnet Socket (2mm x 1mm disc: 2.10mm ID x 1.20mm deep)
mag_pocket_dia      = 2.10;
mag_pocket_depth    = 1.20;
shear_dimple_dia    = 3.60;
shear_dimple_depth  = 0.50;

// ============================================================================
// HELPER MODULES
// ============================================================================

module n52_magnet_socket() {
    translate([0, 0, -shear_dimple_depth])
        cylinder(d1=mag_pocket_dia, d2=shear_dimple_dia, h=shear_dimple_depth + 0.05);
    translate([0, 0, -(mag_pocket_depth + shear_dimple_depth)])
        cylinder(d=mag_pocket_dia, h=mag_pocket_depth + 0.05);
}

// Protruding 0.45mm conical shear boss + 2.10x1.20mm magnet pocket for removable parts
shear_boss_dia1     = 3.40;
shear_boss_dia2     = 2.10;
shear_boss_height   = 0.45;

module n52_mating_boss() {
    cylinder(d1=shear_boss_dia1, d2=shear_boss_dia2, h=shear_boss_height);
}

module n52_mating_pocket_cut() {
    translate([0, 0, -mag_pocket_depth])
        cylinder(d=mag_pocket_dia, h=mag_pocket_depth + shear_boss_height + 0.1);
}

module fc_hole_positions() {
    for (angle = [0, 90, 180, 270]) {
        rotate([0, 0, angle])
            translate([fc_radius, 0, 0])
                children();
    }
}

module fc_hole_positions_2d() {
    for (angle = [0, 90, 180, 270]) {
        rotate([0, 0, angle])
            translate([fc_radius, 0])
                children();
    }
}

module fc_diamond_hub_2d() {
    hull() {
        circle(d=24.0);
        fc_hole_positions_2d() {
            circle(d=6.4);
        }
    }
}

module fc_diamond_hub(thickness) {
    linear_extrude(height=thickness)
        fc_diamond_hub_2d();
}

// ============================================================================
// 2D HELPER PROFILES FOR WATERTIGHT MANIFOLD FRAME EXTRUSION
// ============================================================================
module prop_swept_circles_2d(m_rad, hoop_id) {
    for (angle = [45, 135, 225, 315]) {
        rotate([0, 0, angle])
            translate([m_rad, 0])
                circle(d=hoop_id);
    }
}

module motor_holes_2d(m_rad) {
    for (angle = [45, 135, 225, 315]) {
        rotate([0, 0, angle])
            translate([m_rad, 0]) {
                circle(d=motor_shaft_dia);
                for (m_ang = [0, 120, 240]) {
                    rotate([0, 0, m_ang])
                        translate([motor_hole_circle/2, 0])
                            circle(d=motor_screw_dia);
                }
            }
    }
}

module arm_and_motor_pad_2d(m_rad) {
    for (angle = [45, 135, 225, 315]) {
        rotate([0, 0, angle]) {
            // Main diagonal arm
            translate([0, -arm_width/2])
                square([m_rad, arm_width]);
            // Smooth teardrop gusset blending 5.2mm arm into 12.4mm motor mount pad
            hull() {
                translate([m_rad, 0])
                    circle(d=motor_boss_dia);
                translate([m_rad - motor_gusset_span, -arm_width/2])
                    square([0.6, arm_width]);
            }
        }
    }
}

// Top-only recessed U-channel for 0803/1002/1102 180-deg 3-pad (U/V/W) stator PCB
// wire-solder tab relief + prop-safe 3x 30AWG motor wire routing through hoop wall
// + flared inboard FC waist wire-riser pocket (R = 11.00..14.80mm) for strain-free
// routing up around the 14.20mm AIO FC waist into J_M1..J_M4 JST-1.25mm sockets.
// Uses r=0.45mm corner fillets so full 2.40-2.70mm width clears all 3 U/V/W solder
// joints out to m_rad - 4.05mm (outside d=7.80mm stator seat and +1.71mm clear of
// both 120/240-deg d=2.60mm M1.4 screw-head clamping lands).
module arm_wire_channel_2d(m_rad) {
    r_fillet  = 0.45;
    y_off     = (wire_chan_width / 2.0) - r_fillet; // 0.90 mm -> 2.70 mm arm channel width
    y_flare   = 2.30 - r_fillet;                    // 1.85 mm -> 4.60 mm flared FC waist riser pocket
    x_inboard = 11.00 + r_fillet;                   // R = 11.00mm inside hub (leaves 3.3mm wall outside d=14.5 hole)
    x_waist   = 14.80 + r_fillet;                   // R = 14.80mm just outside 14.20mm FC PCB waist edge
    x_end     = m_rad - (4.05 + r_fillet);          // Outboard edge at m_rad - 4.05mm under U/V/W tab
    if (x_end > x_waist + 0.5) {
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle]) {
                // Main arm U-channel (R = 14.80mm .. m_rad - 4.05mm)
                hull() {
                    for (sy = [-1, 1]) {
                        translate([x_waist, sy * y_off]) circle(r=r_fillet);
                        translate([x_end,   sy * y_off]) circle(r=r_fillet);
                    }
                }
                // Flared hub waist wire-riser transition (R = 11.00mm .. 14.80mm)
                hull() {
                    for (sy = [-1, 1]) {
                        translate([x_inboard, sy * y_flare]) circle(r=r_fillet);
                        translate([x_waist,   sy * y_off])   circle(r=r_fillet);
                    }
                }
            }
        }
    }
}

// ============================================================================
// PARAMETRIC PROTECTED FRAME GENERATOR (Supports 75mm/40mm AND 80.8mm/45mm)
// ============================================================================
module build_protected_frame(wb_diag, hoop_id) {
    m_rad      = wb_diag / 2.0;
    hoop_wall  = 1.6;
    hoop_od    = hoop_id + 2 * hoop_wall;
    base_h     = 3.0;
    guard_h    = 8.5;
    bridge_r   = m_rad / sqrt(2); // X/Y coordinate of motor centers

    difference() {
        union() {
            // TIER 1 (Z = 0 .. arm_height = 2.5mm): Hub, Flat-Bottom Arms, 12.4mm Motor Pads & Radial Struts
            // Strut tips terminate at hoop_id/2 + 0.8mm (strictly inside the 1.6mm hoop wall)
            linear_extrude(height=arm_height) {
                union() {
                    fc_diamond_hub_2d();
                    arm_and_motor_pad_2d(m_rad);
                    for (angle = [45, 135, 225, 315]) {
                        rotate([0, 0, angle])
                            translate([m_rad, 0]) {
                                for (s_ang = [-55, 0, 55]) {
                                    rotate([0, 0, s_ang])
                                        hull() {
                                            translate([motor_boss_dia/2 - 1.8, -1.85])
                                                square([0.6, 3.7]);
                                            translate([hoop_id/2 + 0.8, -1.50])
                                                square([0.1, 3.0]);
                                        }
                                }
                            }
                    }
                }
            }

            // TIER 2A (Z = 0 .. base_h = 3.0mm): Inner Cardinal Truss Webs (strictly nested at ends)
            linear_extrude(height=base_h) {
                difference() {
                    for (c_ang = [0, 90, 180, 270]) {
                        rotate([0, 0, c_ang])
                            hull() {
                                translate([fc_radius, 0])
                                    circle(d=5.8);
                                translate([bridge_r + 0.2, -5.0])
                                    square([2.0, 10.0]);
                            }
                    }
                    for (angle = [45, 135, 225, 315]) {
                        rotate([0, 0, angle])
                            translate([m_rad, 0])
                                circle(d=hoop_id + 1.2);
                    }
                }
            }

            // TIER 2B (Z = 0 .. guard_h = 8.5mm, trimmed inboard above Z = base_h = 3.0mm):
            // Single extrusion of 360° Hoops so inner & outer hoop walls are 100% continuous!
            difference() {
                linear_extrude(height=guard_h) {
                    difference() {
                        union() {
                            for (angle = [45, 135, 225, 315]) {
                                rotate([0, 0, angle])
                                    translate([m_rad, 0])
                                        circle(d=hoop_od);
                            }
                        }
                        prop_swept_circles_2d(m_rad, hoop_id);
                    }
                }
                // Trim inboard hoop arcs down to base_h (3.0mm) so only outer 230° guard wall stands 8.5mm tall
                for (angle = [45, 135, 225, 315]) {
                    rotate([0, 0, angle])
                        translate([m_rad - hoop_od - 3.0, -hoop_od/2 - 1.0, base_h])
                            cube([hoop_od, hoop_od + 2.0, guard_h]);
                }
            }

            // TIER 2C (Z = 0 .. guard_h = 8.5mm): Outer Cardinal Bumper Bridges (strictly nested in hoop walls)
            for (c_ang = [0, 90, 180, 270]) {
                b_hy = bridge_r - hoop_id/2 - 0.45;
                rotate([0, 0, c_ang])
                    translate([bridge_r - 0.8, -b_hy, 0])
                        cube([4.2, 2 * b_hy, guard_h]);
            }

            // TIER 3 (Z = 0 .. 5.5mm): 4x Raised 3.0mm Thermal Air-Gap FC Standoffs (d=5.4 strictly inside d=5.8/6.4)
            fc_hole_positions() {
                cylinder(d=5.4, h=arm_height + fc_air_gap);
            }

            // TIER 4 (Z = 0 .. 9.7mm): Left & Right Cheek Breakaway Armor Plate Magnet Bosses
            for (c_ang = [90, 270]) {
                rotate([0, 0, c_ang])
                    translate([bridge_r + 2.5, 0, 0])
                        cylinder(d=7.6, h=guard_h + 1.2);
            }
        }

        // --- UNIFIED 3D BOOLEAN SUBTRACTIONS ---

        // A. Center Weight-Reduction & Airflow Cutout
        translate([0, 0, -0.1])
            cylinder(d=14.5, h=arm_height + 0.2);

        // B. 4x Cardinal Diamond M2 Flight Controller Through-Holes
        fc_hole_positions() {
            translate([0, 0, -0.1])
                cylinder(d=fc_hole_dia, h=guard_h + 2.0);
        }

        // C. Motor Center Shaft Relief (2.3mm) + 3x M1.4 Screw Holes (6.6mm circle)
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle])
                translate([m_rad, 0, -0.1]) {
                    cylinder(d=motor_shaft_dia, h=arm_height + 0.2);
                    for (m_ang = [0, 120, 240]) {
                        rotate([0, 0, m_ang])
                            translate([motor_hole_circle/2, 0, 0])
                                cylinder(d=motor_screw_dia, h=arm_height + 0.2);
                    }
                }
        }

        // D. Top Recessed Stator Solder-Tab & Motor-Wire U-Channel (Z = 1.65 .. 3.65mm)
        // Cuts cleanly through both the Z=2.50mm arm top AND the Z=3.00mm inboard hoop wall
        // (zero blind overhang ceiling; bottom Z=0.00mm stays 100% flat on PEI build plate).
        translate([0, 0, arm_height - wire_chan_depth])
            linear_extrude(height=(base_h - (arm_height - wire_chan_depth)) + 0.65)
                arm_wire_channel_2d(m_rad);

        // E. Recessed N52 Magnet Sockets on Left & Right Cheek Bridges (90 & 270 deg)
        for (c_ang = [90, 270]) {
            rotate([0, 0, c_ang])
                translate([bridge_r + 2.5, 0, guard_h + 1.2])
                    n52_magnet_socket();
        }
    }
}

// ============================================================================
// 1A. KODIAK75_Frame_Protected_v2.stl (75.0mm Wheelbase / 40mm Props)
// ============================================================================
module KODIAK75_frame_protected() {
    build_protected_frame(75.0, 42.0);
}

// ============================================================================
// 1B. KODIAK75_Frame_Protected_80Pro_45mm.stl (80.8mm Wheelbase / 45mm Props)
// ============================================================================
module KODIAK75_frame_protected_80pro() {
    build_protected_frame(80.8, 47.0);
}

// ============================================================================
// 1C. KODIAK75_Frame_v1.stl — Guardless 75mm Open-Prop X-Frame (Reinforced 12.4mm Pads)
// ============================================================================
module KODIAK75_frame() {
    m_rad = 37.5;
    difference() {
        union() {
            linear_extrude(height=arm_height) {
                difference() {
                    union() {
                        fc_diamond_hub_2d();
                        arm_and_motor_pad_2d(m_rad);
                    }
                    circle(d=14.5);
                    fc_hole_positions_2d() circle(d=fc_hole_dia);
                    motor_holes_2d(m_rad);
                }
            }
            linear_extrude(height=arm_height + fc_air_gap) {
                difference() {
                    fc_hole_positions_2d() circle(d=5.4);
                    fc_hole_positions_2d() circle(d=fc_hole_dia);
                }
            }
        }
        translate([0, 0, arm_height - wire_chan_depth])
            linear_extrude(height=wire_chan_depth + 0.5)
                arm_wire_channel_2d(m_rad);
    }
}

// ============================================================================
// 2. KODIAK75_Horns_v1.stl — Sandwich TPU 68D / PAHT-CF Net-Deflection Standoffs
// ============================================================================
module KODIAK75_horns() {
    horn_r = 52.5;
    horn_t = 2.4;
    difference() {
        union() {
            linear_extrude(height=horn_t) {
                difference() {
                    union() {
                        fc_diamond_hub_2d();
                        for (angle = [0, 90, 180, 270]) {
                            rotate([0, 0, angle])
                                hull() {
                                    translate([14.0, 0]) circle(d=6.5);
                                    translate([horn_r - 2.5, 0]) circle(d=7.6);
                                }
                        }
                    }
                    circle(d=18.2);
                    // Diagonal waist scallops so motor wires & B.Cu passives have extra clearance
                    for (d_ang = [45, 135, 225, 315]) {
                        rotate([0, 0, d_ang])
                            translate([15.2, 0])
                                circle(d=5.6);
                    }
                    fc_hole_positions_2d() circle(d=fc_hole_dia);
                }
            }
            for (angle = [0, 90, 180, 270]) {
                rotate([0, 0, angle])
                    translate([horn_r - 2.5, 0, 0])
                        cylinder(d=7.6, h=horn_t + 1.6);
            }
        }
        for (angle = [90, 270]) {
            rotate([0, 0, angle])
                translate([horn_r - 2.5, 0, horn_t + 1.6])
                    n52_magnet_socket();
        }
    }
}

// ============================================================================
// 3. KODIAK75_550Cradle_v1.stl — Unobstructed 1S 550mAh TPU Belly Cradle
// ============================================================================
module KODIAK75_550_cradle() {
    outer_l = batt_len + 2*cradle_wall;
    outer_w = batt_width + 2*cradle_wall;
    outer_h = batt_height + 2*cradle_wall;

    difference() {
        union() {
            translate([-outer_l/2, -outer_w/2, -outer_h])
                cube([outer_l, outer_w, outer_h]);
            // Outboard Left & Right M2 Stack Mounting Wings at (0, +/-18.031mm)
            translate([0, 0, -cradle_wall*1.5])
                linear_extrude(height=cradle_wall*1.5) {
                    for (y_sign = [-1, 1]) {
                        hull() {
                            translate([0, y_sign * (outer_w/2 - 1.5)])
                                circle(d=8.5);
                            translate([0, y_sign * fc_radius])
                                circle(d=6.4);
                        }
                    }
                }
            for (x_pos = [-18.0, 18.0]) {
                translate([x_pos, 0, -outer_h - 1.6])
                    cylinder(d=7.6, h=2.0);
            }
        }
        // Unobstructed 70.0 x 18.5 x 7.5mm battery tunnel
        translate([-outer_l/2 - 0.1, -batt_width/2, -cradle_wall - batt_height])
            cube([outer_l + 0.2, batt_width, batt_height]);
        for (x_win = [-22, 0, 22]) {
            translate([x_win - 5.5, -outer_w/2 - 0.1, -cradle_wall - batt_height + 1.5])
                cube([11.0, outer_w + 0.2, batt_height - 3.0]);
        }
        translate([-velcro_slot_w/2, -outer_w/2 - 0.1, -cradle_wall - velcro_slot_h])
            cube([velcro_slot_w, outer_w + 0.2, velcro_slot_h + 0.1]);
        for (y_sign = [-1, 1]) {
            translate([0, y_sign * fc_radius, -outer_h - 0.1])
                cylinder(d=fc_hole_dia, h=outer_h + 0.2);
        }
        for (x_pos = [-18.0, 18.0]) {
            translate([x_pos, 0, -outer_h - 1.6])
                rotate([180, 0, 0])
                    n52_magnet_socket();
        }
    }
}

// ============================================================================
// SHARED CARDINAL M2 VAULTED PILLAR HELPER (100% OSITO_KODIAK_FC_v1 Connector-Clear)
// Leaves all 4 diagonal quadrants (J_M1..J_M4 + motor wire loops + J_BAT + J_LED_EXT
// + J_CAM + J_USB + ANT1) 100% unobstructed and prints support-free (>=37 deg slope).
// ============================================================================
module kodiak_fc_clear_pillar_2d() {
    hull() {
        translate([fc_radius, 0])        circle(d=4.00);
        translate([fc_radius + 1.35, 0]) circle(d=5.00);
    }
}

// ============================================================================
// 4. KODIAK75_Deck_LOS_v1.stl — Vaulted 4-Pillar LOS Canopy + Crown Boss (0 Degen)
// ============================================================================
module KODIAK75_deck_los() {
    difference() {
        union() {
            // 4x Low-Profile Cardinal M2 Standoff Feet (Z = 0 .. 2.60mm -> open M2 screw access above!)
            linear_extrude(height=2.60) {
                for (c_ang = [0, 90, 180, 270]) {
                    rotate([0, 0, c_ang])
                        kodiak_fc_clear_pillar_2d();
                }
            }
            // 4x Steep 67-deg Riser Legs (Z=2.0..5.8mm at R=14.6..16.2mm, clearing both M2 screw heads
            // and all FC connectors) + 39.5-deg Vaulted Arch Ribs above Z=5.80mm (Z_world=12.60mm > 12.10mm J_M1..4!)
            for (c_ang = [0, 90, 180, 270]) {
                rotate([0, 0, c_ang]) {
                    hull() {
                        translate([16.10, -1.30, 1.80])
                            cube([1.55, 2.60, 0.80]);
                        translate([14.60, -1.30, 5.80])
                            cube([1.60, 2.60, 1.50]);
                    }
                    hull() {
                        translate([14.60, -1.30, 5.80])
                            cube([1.60, 2.60, 1.50]);
                        translate([0, 0, 14.60])
                            cylinder(d=5.40, h=1.80, $fn=48);
                    }
                }
            }
            // Zone 1 Top Crown N52 Magnet Boss (flares cleanly at 45 deg from Z=13.40 to d=8.0mm)
            translate([0, 0, 13.40])
                cylinder(d1=5.20, d2=8.00, h=1.40, $fn=72);
            translate([0, 0, 14.80])
                cylinder(d=8.00, h=2.40, $fn=72);
        }
        // 4x Cardinal Diamond M2 Through-Holes
        fc_hole_positions() {
            translate([0, 0, -0.10])
                cylinder(d=fc_hole_dia, h=4.00);
        }
        // Zone 1 Top Crown N52 Magnet Socket
        translate([0, 0, 17.20])
            n52_magnet_socket();
    }
}

// ============================================================================
// 5. KODIAK75_Deck_FPV_v1.stl — Vaulted 14x14mm Nano Camera Pod (+X Nose, FC-Clear)
// ============================================================================
module KODIAK75_deck_fpv() {
    difference() {
        union() {
            // 4x Low-Profile Cardinal M2 Standoff Feet (Z = 0 .. 2.60mm -> open M2 screw access!)
            linear_extrude(height=2.60) {
                for (c_ang = [0, 90, 180, 270]) {
                    rotate([0, 0, c_ang])
                        kodiak_fc_clear_pillar_2d();
                }
            }
            // 4x Steep 67-deg Riser Legs clearing M2 screw heads AND J_M1..J_M4 up to Z=5.80mm
            for (c_ang = [0, 90, 180, 270]) {
                rotate([0, 0, c_ang])
                    hull() {
                        translate([16.10, -1.30, 1.80])
                            cube([1.55, 2.60, 0.80]);
                        translate([14.60, -1.30, 5.80])
                            cube([1.60, 2.60, 1.50]);
                    }
            }
            // Port (+Y) & Starboard (-Y) 41-deg Arch Struts rising from Z=5.80mm into 14.3mm-gap Camera Cheeks
            for (sy = [-1, 1]) {
                hull() {
                    translate([-1.30, sy * 14.60 + (sy < 0 ? -1.60 : 0.0), 5.80])
                        cube([2.60, 1.60, 1.50]);
                    translate([-3.80, sy * 7.15 + (sy < 0 ? -1.85 : 0.0), 11.80])
                        cube([9.40, 1.85, 8.20]);
                }
                // Pitched 45-deg roof vault from each side cheek up into Top Crown Boss
                hull() {
                    translate([-3.40, sy * 7.15 + (sy < 0 ? -1.85 : 0.0), 18.20])
                        cube([8.60, 1.85, 1.80]);
                    translate([1.00, 0, 22.60])
                        cylinder(d=8.00, h=1.80, $fn=64);
                }
            }
            // Front (+X) Centerline Chin Strut (above Z=5.80mm -> clears J_M4 & J_CAM!) + V-Yoke to Cheeks
            hull() {
                translate([14.60, -1.30, 5.80])
                    cube([1.60, 2.60, 1.50]);
                translate([10.00, -1.30, 9.40])
                    cube([1.80, 2.60, 1.80]);
            }
            for (sy = [-1, 1]) {
                hull() {
                    translate([10.00, -1.30, 9.40])
                        cube([1.80, 2.60, 1.80]);
                    translate([3.60, sy * 7.15 + (sy < 0 ? -1.85 : 0.0), 13.80])
                        cube([2.00, 1.85, 2.00]);
                }
            }
            // Rear (-X) Centerline Spine Strut (above Z=5.80mm -> clears J_BAT & J_LED_EXT!) + V-Yoke
            hull() {
                translate([-16.20, -1.30, 5.80])
                    cube([1.60, 2.60, 1.50]);
                translate([-8.80, -1.60, 11.20])
                    cube([2.40, 3.20, 2.40]);
            }
            for (sy = [-1, 1]) {
                hull() {
                    translate([-8.80, -1.60, 11.20])
                        cube([2.40, 3.20, 2.40]);
                    translate([-3.80, sy * 7.15 + (sy < 0 ? -1.85 : 0.0), 15.60])
                        cube([2.00, 1.85, 3.60]);
                }
            }
            // Pre-hollowed Rear -25 deg dipole antenna sleeve rooted in Rear Spine
            translate([-7.80, 0, 12.40])
                rotate([0, -25, 0])
                    difference() {
                        cylinder(d=3.80, h=9.50, $fn=32);
                        translate([0, 0, -0.20])
                            cylinder(d=1.80, h=9.90, $fn=32);
                    }
            // Zone 1 8.0mm Top Crown N52 Magnet Boss
            translate([1.00, 0, 22.60])
                cylinder(d=8.00, h=2.80, $fn=64);
        }
        // 4x Cardinal Diamond M2 mounting holes
        fc_hole_positions() {
            translate([0, 0, -0.10])
                cylinder(d=fc_hole_dia, h=4.00);
        }
        // M2 Nano FPV camera side-mount pivot holes through Left & Right cheeks
        translate([0.90, 0, 16.20])
            rotate([90, 0, 0])
                cylinder(d=2.05, h=24.0, center=true, $fn=32);
        // Zone 1 Top Crown N52 Magnet Socket
        translate([1.00, 0, 25.40])
            n52_magnet_socket();
    }
}

// ============================================================================
// 6. KODIAK75_ArmorPlates_v1.stl — 4x Breakaway Armor Pods + N52 Magnet Cups
// ============================================================================
module KODIAK75_ArmorPlates() {
    // 1. Top Canopy Crown Armor Pod (with 0.45mm protruding conical shear boss on bottom)
    difference() {
        union() {
            difference() {
                union() {
                    cylinder(d1=18.0, d2=10.0, h=6.0);
                    translate([-7.0, -1.2, 0]) cube([14.0, 2.4, 11.0]);
                }
                // 0.45mm annular relief for 8.0mm Top Deck boss so conical boss protrudes 0.45mm
                translate([0, 0, -0.05])
                    cylinder(d=8.4, h=shear_boss_height + 0.05);
            }
            // Downward-protruding 0.45mm conical shear boss (d1=3.40 at Z=0.45, d2=2.10 at Z=0)
            cylinder(d1=shear_boss_dia2, d2=shear_boss_dia1, h=shear_boss_height);
        }
        // 2.10mm x 1.20mm recessed magnet pocket
        translate([0, 0, -0.05])
            cylinder(d=mag_pocket_dia, h=mag_pocket_depth + shear_boss_height + 0.05);
    }

    // 2 & 3. Left & Right Cheek Armor Pods (with 0.45mm protruding conical shear boss on top)
    for (y_off = [-26.0, 26.0]) {
        translate([0, y_off, 0]) {
            difference() {
                union() {
                    hull() {
                        cylinder(d=9.0, h=3.2);
                        translate([-12.0, 0, 0]) cylinder(d=5.0, h=2.4);
                        translate([12.0, 0, 0])  cylinder(d=5.0, h=2.4);
                    }
                    translate([0, 0, 3.2])
                        n52_mating_boss();
                }
                translate([0, 0, 3.2])
                    n52_mating_pocket_cut();
            }
        }
    }

    // 4. Dual-Magnet Belly Skid Armor Pod (with 2x 0.45mm protruding conical shear bosses at +/-18.0mm)
    translate([30.0, 0, 0]) {
        difference() {
            union() {
                hull() {
                    translate([-20.0, 0, 0]) cylinder(d=14.0, h=2.8);
                    translate([20.0, 0, 0])  cylinder(d=14.0, h=2.8);
                }
                for (x_pos = [-18.0, 18.0]) {
                    translate([x_pos, 0, 2.8])
                        n52_mating_boss();
                }
            }
            for (x_pos = [-18.0, 18.0]) {
                translate([x_pos, 0, 2.8])
                    n52_mating_pocket_cut();
            }
        }
    }
}

// ============================================================================
// 7. KODIAK75_Magnet_Polarity_Wand.stl — Shop Assembly Polarity Jig Tool
// ============================================================================
module KODIAK75_polarity_wand() {
    difference() {
        union() {
            translate([-45.0, -4.0, 0]) cube([90.0, 8.0, 4.0]);
            translate([-45.0, 0, 0]) cylinder(d=8.5, h=5.2);
            translate([40.5, -4.5, 0]) cube([9.0, 9.0, 5.2]);
        }
        translate([-45.0, 0, 4.0]) cylinder(d=2.08, h=1.5);
        translate([45.0, 0, 4.0])  cylinder(d=2.08, h=1.5);
    }
}

// ============================================================================
// RENDER DISPATCHER (Uses integer PART_ID for shell-safe CLI invocation)
// ============================================================================
if (PART_ID == 1) {
    KODIAK75_frame_protected();
} else if (PART_ID == 2) {
    KODIAK75_frame_protected_80pro();
} else if (PART_ID == 4) {
    KODIAK75_frame();
} else if (PART_ID == 5) {
    KODIAK75_horns();
} else if (PART_ID == 6) {
    rotate([180, 0, 0]) KODIAK75_550_cradle();
} else if (PART_ID == 7) {
    KODIAK75_deck_los();
} else if (PART_ID == 8) {
    KODIAK75_deck_fpv();
} else if (PART_ID == 9) {
    KODIAK75_ArmorPlates();
} else if (PART_ID == 10) {
    KODIAK75_polarity_wand();
} else {
    color("DimGray")     KODIAK75_frame_protected();
    color("DodgerBlue")  translate([0, 0, -2.0]) KODIAK75_550_cradle();
    color("Gold")        translate([0, 0, 10.0]) KODIAK75_deck_los();
    color("Crimson")     translate([0, 0, 22.0]) KODIAK75_ArmorPlates();
}
