// ============================================================================
// OSITO MINICUB-65 BNF (REV 2.2): Proprietary Parametric 65mm 1S CAD Suite
// ============================================================================
// Proprietary Osito Drone LLC Industrial Design & Structural Architecture:
//   1. Grizzly-Ring 65 Airframe : 8-Sided Octa-Facet Chamfered Impact Ducts
//   2. Anti-Resonance Struts    : 3-Spoke Tangential Swirl Tri-Truss Motor Mounts
//   3. Osito CubCap Canopy      : Faceted Bear-Ear Impact Shell w/ Wide VTX Window,
//                                 12 deg Slight-Upward Camera Cradle & 3.8mm VTX Bore
//   4. Tail Pigtail Retention   : Cantilevered BT2.0/PH2.0 Strain-Relief Bridge
//   5. Core Mechanical Envelope :
//      - 65.0 mm Diagonal Motor-to-Motor Wheelbase
//      - 25.5 x 25.5 mm M2 Diamond FC Mounting Pattern (29x29x7.6mm CubBrain-65 AIO)
//      - 31.0 mm 3-Blade / 4-Blade Propeller Clearance (32.6mm Duct ID = 0.80mm Tip Clearance)
//      - CubCell 1S 300mAh 80C LiHV Battery Cradle (11.8 x 6.8 x 42.0 mm)
//
// Bambu Lab P2S Combo 4-Tier Filament Assignment:
//   - Airframe (FRAME_BRUSHED / FRAME_BRUSHLESS) : Tier 1 Bambu PETG-CF (P2S #1 AMS Slot 1)
//   - Canopy (CANOPY_CUBCAP)                     : Tier 4 Bambu TPU for AMS 68D (Slot 4)
//                                                  or Bambu TPU 95A HF (P2S #2 External Port)
// ============================================================================

PART_SELECT      = "ALL"; // "ALL", "FRAME_BRUSHED", "FRAME_BRUSHLESS", "CANOPY_CUBCAP", "FC_CUBBRAIN"
PART_ID          = 0;     // 0=ALL, 1=FRAME_BRUSHED, 2=FRAME_BRUSHLESS, 3=CANOPY_CUBCAP, 4=FC_CUBBRAIN
CAM_TILT_DEG     = 12;    // Position 1 (Beginner / STEM Hover): 12 deg slight upward tilt
CAM_TILT_MID_DEG = 25;    // Position 2 (Sport / Freestyle):     25 deg mid upward tilt
CAM_TILT_MAX_DEG = 38;    // Position 3 (Aggressive Acro/Race):  38 deg high upward tilt
$fn = 48;

// --- Core 65mm Micro-Drone Functional Dimensions ---
wheelbase       = 65.0;                     // 65.0mm diagonal motor-to-motor wheelbase
motor_r         = wheelbase / 2.0;          // 32.5mm radial distance from center
motor_xy        = motor_r * cos(45);        // 22.981mm X/Y coordinate
fc_width        = 29.0;                     // 29.0 x 29.0mm CubBrain-65 AIO envelope
fc_length       = 29.0;
fc_pcb_thick    = 1.0;                      // 1.0mm 4-Layer TG170 FR4 JLC04101H-3313 (1oz Outer / 0.5oz Inner Cu)
fc_mount_span   = 25.5;                     // 25.5 x 25.5mm M2 diamond pattern
fc_post_r       = fc_mount_span / sqrt(2);  // 18.031mm diamond post radius
fc_hole_d       = 2.1;                      // M2 silicone grommet mounting hole
prop_d          = 31.0;                     // 31mm micro ducted propeller
duct_id         = 32.6;                     // 0.80mm radial prop tip clearance
duct_od         = 35.4;                     // Structural wall outer diameter
duct_h          = 7.6;                      // Full sub-50g youth-safe prop shroud height

// --- Motor Mount Parameters (Trim A: CubCore 0615 Brushed vs Trim B: CubSpin 0702SE Brushless) ---
brushed_id      = 6.10;                     // 6x15mm coreless brushed motor slip-fit ID
brushed_od      = 8.80;                     // Brushed motor pod OD (1.35mm C-clamp wall)
brushed_pod_h   = 12.2;                     // Supports 15mm tall 0615 motor can
brushless_od    = 12.40;                    // Expanded 12.40mm OD pad (>=2.17mm wall outside 6.6mm BCD)
brushless_bcd   = 6.60;                     // 3-hole 0702SE 6.60mm bolt circle diameter
brushless_screw = 1.45;                     // M1.4 motor screw clearance hole
brushless_c_hole= 2.15;                     // Center shaft/c-clip clearance hole

// --- CubCell 1S 300mAh LiHV Battery Bay Parameters ---
bat_w           = 11.8;                     // Fits CubCell 1S 300mAh LiHV (BT2.0 or PH2.0)
bat_h           = 6.8;
bat_l           = 42.0;

// ============================================================================
// HELPER: OCTA-FACET CHAMFERED DUCT PROFILE (Grizzly-Ring 65 Outer Rim)
// ============================================================================
module octa_duct_shell(id, od, h) {
    difference() {
        union() {
            cylinder(d = od, h = h);
            rotate([0, 0, 22.5])
                cylinder(d = od + 1.4, h = h, $fn = 8);
            // Bottom chamfered Octa-Facet bumper band (flush on Z=0 plane)
            rotate([0, 0, 22.5])
                cylinder(d = od + 2.0, h = 1.5, $fn = 8);
            // Top chamfered Octa-Facet bumper band (45-deg lower transition eliminates 90-deg mid-air overhang)
            translate([0, 0, h - 1.8])
                rotate([0, 0, 22.5])
                    cylinder(d1 = od + 1.4, d2 = od + 2.0, h = 0.4, $fn = 8);
            translate([0, 0, h - 1.4])
                rotate([0, 0, 22.5])
                    cylinder(d = od + 2.0, h = 1.4, $fn = 8);
        }
        translate([0, 0, -0.5])
            cylinder(d1 = id, d2 = id + 0.2, h = h + 1.0); // 1.5-deg draft angle
    }
}

// ============================================================================
// 1. OSITO CUBBRAIN-65 AIO FLIGHT CONTROLLER MOCKUP (29.0 x 29.0 x 7.6mm)
// ============================================================================
module fc_cubbrain_mockup() {
    difference() {
        union() {
            // 1.0mm 4-Layer TG170 FR4 Substrate with R=2.0mm corner fillets
            linear_extrude(height = fc_pcb_thick)
                offset(r = 2.0) offset(delta = -2.0)
                    square([fc_width, fc_length], center = true);

            // Top-Side Components (+Z from 1.0mm to +4.6mm)
            // U1: STM32F411CEU6 (UFQFPN-48 7x7x0.8mm at 0,0)
            translate([-3.5, -3.5, fc_pcb_thick]) cube([7.0, 7.0, 0.9]);
            // U2: Bosch BMI270 Gyro (2.5x3.0x0.8mm at 0,-5.8)
            translate([-1.25, -7.3, fc_pcb_thick]) cube([2.5, 3.0, 0.9]);
            // U3: Semtech SX1280 SPI3 ELRS 2.4GHz (4x4x0.9mm at 0,7.6)
            translate([-2.0, 5.6, fc_pcb_thick]) cube([4.0, 4.0, 0.9]);
            // ANT1: 2.4GHz SMD Ceramic Chip Antenna (at 0,13.1)
            translate([-1.6, 12.3, fc_pcb_thick]) cube([3.2, 1.6, 3.2]);
            // U4: AT7456E Analog OSD (HTSSOP-28-EP at -10.0,0.0)
            translate([-12.2, -4.5, fc_pcb_thick]) cube([4.4, 9.0, 1.1]);
            // Top H-Bridge MOSFETs Q1A, Q1B, Q2A, Q2B (SOIC-8 at X=10.6)
            for (yp = [-7.2, -2.4, 2.4, 7.2]) {
                translate([8.15, yp - 1.95, fc_pcb_thick]) cube([4.9, 3.9, 1.2]);
            }
            // J1: 12-Pin USB Type-C Receptacle TYPE-C-31-M-12 (Rear Edge at 0,-12.25)
            translate([-4.5, -14.1, fc_pcb_thick]) cube([9.0, 6.5, 3.6]);
            // J_CAM: 3-Pin JST-SH FPV Camera Header (at -5.8,12.1)
            translate([-8.0, 10.6, fc_pcb_thick]) cube([4.5, 2.8, 2.2]);
            // J_VTX_ANT (at 8.2,13.1) & J_ANT_ELRS (at 5.08,12.5): SMT U.FL Coax Receptacles
            translate([8.2 - 1.5, 13.1 - 1.5, fc_pcb_thick]) cube([3.0, 3.0, 1.25]);
            translate([5.08 - 1.5, 12.5 - 1.5, fc_pcb_thick]) cube([3.0, 3.0, 1.25]);
            // 2x Reinforced 4-Layer PTH Battery Pads (PAD_BAT+ / PAD_BAT- at +/-6.4, -9.0)
            for (sx = [-1, 1]) {
                translate([sx * 6.4 - 0.8, -9.9, -0.2]) cube([1.6, 1.8, 1.4]);
            }
            // 4x M2 Silicone Anti-Vibration Grommet Collars at 25.5x25.5mm (Full -3.0..+4.6mm height so all 4 corners sit flush on build plate)
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * fc_mount_span/2, sy * fc_mount_span/2, -3.0])
                    cylinder(d = 3.8, h = 7.6);
            }

            // Bottom-Side Components (-Z from 0 down to -3.0mm)
            // 4x JST-1.25mm Motor Headers (J_M1..J_M4 at +/-5.20, +/-12.20 matching Pick-and-Place CPL)
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * 5.2 - 2.2, sy * 12.2 - 1.5, -3.0])
                    cube([4.4, 3.0, 3.0]);
            }
            // Bottom H-Bridge MOSFETs Q3A..Q4B & 4x EFM8BB21 ESC MCUs (U5..U8)
            for (yp = [-7.2, -2.4, 2.4, 7.2]) {
                translate([-13.05, yp - 1.95, -1.2]) cube([4.9, 3.9, 1.2]);
            }
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * 5.6 - 1.5, sy * 5.6 - 1.5, -0.9])
                    cube([3.0, 3.0, 0.9]);
            }
            // U13 RTC6705 VTX + U14 RTC6659E PA + U10 TPS63020 BEC + C_BULK 220uF POSCAP
            translate([-3.0, 0.6, -0.9]) cube([6.0, 6.0, 0.9]);
            translate([-1.5, 7.5, -0.9]) cube([3.0, 3.0, 0.9]);
            translate([-1.5, -7.2, -1.0]) cube([3.0, 4.0, 1.0]);
            translate([10.8, -6.55, -1.9]) cube([2.8, 3.5, 1.9]);
        }

        // 4x 25.5x25.5mm M2 Mounting Holes (d=2.1mm) + 2x PTH Battery Drills (d=1.0mm)
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * fc_mount_span/2, sy * fc_mount_span/2, -5.0])
                cylinder(d = fc_hole_d, h = 15.0);
        }
        for (sx = [-1, 1]) {
            translate([sx * 6.4, -9.0, -5.0])
                cylinder(d = 1.0, h = 15.0);
        }
    }
}

module cubbrain65_fc_mockup() {
    fc_cubbrain_mockup();
}

// ============================================================================
// 2. MINICUB-65 GRIZZLY-RING 65 AIRFRAME (BRUSHED 0615 OR BRUSHLESS 0702SE)
// ============================================================================
module minicub65_frame(is_brushless = false) {
    difference() {
        union() {
            // A. 4x Octa-Facet Propeller Ducts at (+/-22.981, +/-22.981)
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * motor_xy, sy * motor_xy, 0]) {
                    octa_duct_shell(duct_id, duct_od, duct_h);

                    if (!is_brushless) {
                        // Top flush with duct_h = 7.60mm (-4.6 + 12.2 = 7.60mm) so upside-down print sits 100% flat on all 4 ducts
                        translate([0, 0, -4.6])
                            cylinder(d = brushed_od, h = brushed_pod_h);
                    } else {
                        cylinder(d = brushless_od, h = 2.6);
                        // Teardrop gusset into inward wire-carrier spine
                        rotate([0, 0, atan2(sy, sx) + 180])
                            hull() {
                                cylinder(d = brushless_od, h = 2.4);
                                translate([8.8, 0, 0]) cylinder(d = 4.2, h = 2.4);
                            }
                    }

                    // Proprietary 3-Spoke Tangential Swirl Tri-Truss Struts (Oriented to inward_ang = atan2(sy,sx)+180)
                    // Spoke 1 (0 deg = Radially Inward toward FC): 4.0mm wide Wire-Carrier Spine w/ Protected Under-Trough
                    rotate([0, 0, atan2(sy, sx) + 180])
                        translate([2.6, -2.0, 0])
                            cube([(duct_id / 2) - 1.5, 4.0, 2.4]);
                    // Spokes 2 & 3 (+120 deg & +240 deg): Tangential Swirl Anti-Resonance Chords (clear 60/180/300 M1.4 screws)
                    for (ang_off = [120, 240]) {
                        rotate([0, 0, atan2(sy, sx) + 180 + ang_off])
                            translate([2.2, -1.25, 0])
                                rotate([0, 0, -14])
                                    cube([(duct_id / 2) - 1.4, 2.5, 2.4]);
                    }
                }
            }

            // B. Perimeter Tri-Truss Box Beams (Terminated at +/-5.2mm inside duct wall annulus)
            for (sx = [-1, 1]) {
                hull() {
                    translate([sx * motor_xy, -5.2, 0]) cylinder(d = 3.2, h = 2.4);
                    translate([sx * motor_xy,  5.2, 0]) cylinder(d = 3.2, h = 2.4);
                }
            }
            for (sy = [-1, 1]) {
                hull() {
                    translate([-5.2, sy * motor_xy, 0]) cylinder(d = 3.2, h = 2.4);
                    translate([ 5.2, sy * motor_xy, 0]) cylinder(d = 3.2, h = 2.4);
                }
            }

            // C. Central Octagonal Torque Ring, Twin-Beam Wire-Channel Diagonal Arms & 25.5x25.5mm Diamond FC Standoffs
            // Diagonal chassis arms & twin-beam structural rails framing the unobstructed 3.30x6.50mm JST-1.25mm Pass-Through Windows
            for (sx = [-1, 1], sy = [-1, 1]) {
                hull() {
                    translate([sx * 7.2, sy * 7.2, 0]) cylinder(d = 3.8, h = 2.4);
                    translate([sx * (motor_xy - 11.8), sy * (motor_xy - 11.8), 0]) cylinder(d = 3.6, h = 2.4);
                }
                // Flanking Twin-Beam Diagonal Rails (+/-2.55mm offset) keeping full 2.40mm height
                for (off_s = [-1, 1]) {
                    hull() {
                        translate([sx * 6.8 + off_s * sy * 1.8, sy * 6.8 - off_s * sx * 1.8, 0]) cylinder(d = 2.5, h = 2.4);
                        translate([sx * (motor_xy - 12.2) + off_s * sy * 1.8, sy * (motor_xy - 12.2) - off_s * sx * 1.8, 0]) cylinder(d = 2.5, h = 2.4);
                    }
                }
                // Outboard & Inboard 2.40mm Structural Box-Beams framing the [|x|=7.55..10.85, |y|=3.60..10.10] Vertical JST Pass-Through Window
                hull() {
                    translate([sx * 12.0, sy * 3.0, 0]) cylinder(d = 2.6, h = 2.4);
                    translate([sx * 12.0, sy * 9.6, 0]) cylinder(d = 2.6, h = 2.4);
                }
                hull() {
                    translate([sx * 7.2, sy * 11.2, 0]) cylinder(d = 2.4, h = 2.4);
                    translate([sx * 10.2, sy * 11.2, 0]) cylinder(d = 2.4, h = 2.4);
                }
            }
            // Flat 2.4mm Cardinal Standoff Gussets + Vertical 5.5mm M2 Pillars (eliminates sloped ramp under FC edges)
            for (ang = [0, 90, 180, 270]) {
                rotate([0, 0, ang]) {
                    hull() {
                        translate([fc_post_r, 0, 0]) cylinder(d = 5.2, h = 2.4);
                        translate([11.2, 0, 0]) cylinder(d = 3.8, h = 2.4);
                    }
                    // Flat-top Z=5.50mm M2 Standoff Pillar w/ 0.30mm top bevel (universal seat for Ø2.10mm CubBrain PCB O-rings & Ø3.8mm whoop gummies)
                    translate([fc_post_r, 0, 0]) cylinder(d = 5.2, h = 5.2);
                    translate([fc_post_r, 0, 5.2]) cylinder(d1 = 5.2, d2 = 4.8, h = 0.3);
                }
            }

            // Central Octagonal Chassis Plate (Open center for VTX & BEC airflow)
            difference() {
                rotate([0, 0, 22.5]) cylinder(d = 26.5, h = 2.4, $fn = 8);
                translate([0, 0, -0.5])
                    rotate([0, 0, 22.5]) cylinder(d = 19.5, h = 3.4, $fn = 8);
            }

            // D. Under-Slung CubCell 1S 300mAh LiHV Battery Bay + Cantilevered BT2.0 Strain Gate
            // Outer box height bat_h + 2.8 = 9.60mm reaches world Z = +1.40mm for deep 1.40mm structural fusion
            translate([0, 0, -bat_h - 1.4]) {
                difference() {
                    union() {
                        translate([-(bat_w + 3.2)/2, -bat_l/2, 0])
                            cube([bat_w + 3.2, bat_l, bat_h + 2.8]);
                        // Flush Bottom Skid Runners at local Z = 0.0 (entire 15.2x42.0mm bottom sits 100% flat on PEI build plate)
                        for (sx = [-1, 1]) {
                            translate([sx * (bat_w/2 + 0.8) - 1.0, -bat_l/2, 0.0])
                                cube([2.0, bat_l, 1.2]);
                        }
                        // Continuous Full-Width Rear BT2.0 Strain-Relief Bridge (fuses into side walls & rear beam)
                        translate([-(bat_w + 3.2)/2, -bat_l/2 - 3.2, bat_h - 0.8])
                            cube([bat_w + 3.2, 4.2, 3.6]);
                    }
                    // Inner battery tunnel (height = bat_h = 6.80mm at local Z = 1.20..8.00mm, so roof straddles global Z = 0.00mm cleanly)
                    translate([-bat_w/2, -bat_l/2 - 0.2, 1.2])
                        cube([bat_w, bat_l + 1.4, bat_h]);
                    // Side weight-saving & grip windows
                    for (yp = [-12, 0, 12]) {
                        translate([-(bat_w + 6)/2, yp - 3.5, 2.6])
                            cube([bat_w + 6, 7.0, bat_h - 2.0]);
                    }
                    // 4x True Under-VTX Cooling Chimneys cut cleanly through the 1.40mm top roof
                    for (yp = [-10, -3, 4, 11]) {
                        translate([-4.5, yp - 2.0, bat_h + 1.0])
                            cube([9.0, 4.0, 2.4]);
                    }
                    // Top-entry U-Channel Wire Slot in Rear Strain-Relief Bridge (preserves continuous bottom crossbar)
                    translate([-2.2, -bat_l/2 - 3.6, bat_h + 0.4])
                        cube([4.4, 4.8, 3.0]);
                }
            }
        }

        // --- Subtractive Motor Bores, 5-Stage Motor Wire Routing Channels & Standoff Screw Holes ---
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * motor_xy, sy * motor_xy, 0]) {
                if (!is_brushless) {
                    translate([0, 0, -1.6]) cylinder(d = brushed_id, h = 15.0);
                    translate([0, 0, -4.0]) cylinder(d = 4.6, h = 4.0);
                    // Stage 1A: Full-Height Inward C-Clamp Wire Slot (X=0..4.45mm cuts 100% of r=4.40mm pod wall without gashing Spoke 1 roof)
                    // + Bottom Endbell Relief Arch & 3.10mm wide Bottom-Lip JST-1.25mm 2-Pin Plug Pass-Through (aligned to Z=-4.6..+7.6mm pod)
                    rotate([0, 0, atan2(sy, sx) + 180]) {
                        translate([0, -0.75, -5.2]) cube([4.45, 1.5, 14.0]);
                        translate([0, -1.1, -5.2]) cube([5.2, 2.2, 6.45]);
                        translate([0, -1.55, -3.5]) cube([4.2, 3.1, 1.95]);
                        translate([0, -1.55, -5.2]) cube([4.2, 3.1, 2.0]);
                    }
                } else {
                    translate([0, 0, -1.0]) cylinder(d = brushless_c_hole, h = 5.0);
                    // Stage 1B: Inward-Aligned 60/180/300 deg 6.60mm BCD Screw Pattern (leaves 0 deg inward wire exit clear)
                    for (ma = [60, 180, 300]) {
                        rotate([0, 0, atan2(sy, sx) + 180 + ma])
                            translate([brushless_bcd / 2, 0, -1.0])
                                cylinder(d = brushless_screw, h = 5.0);
                    }
                    // Inward 0702 Stator Wire Bevel (starts at X=4.20mm -> >=2.175mm solid wall outside 60/300 deg M1.4 holes!)
                    // + 3.4x3.8mm Side-Entry Wire Gate at X=4.55..7.95mm extending 1.75mm clear past r=6.20mm motor pad perimeter
                    rotate([0, 0, atan2(sy, sx) + 180]) {
                        translate([4.20, -1.1, 0.80])
                            cube([2.4, 2.2, 2.2]);
                        translate([4.55, 0.0, -0.5])
                            cube([3.4, 3.8, 1.75]);
                    }
                }

                // Stage 2 & 3: Protected Under-Strut & Through-Duct-Wall Wire U-Channel (starts at X=4.20mm for >=2.175mm brushless wall)
                rotate([0, 0, atan2(sy, sx) + 180]) {
                    translate([4.20, -1.1, -0.5])
                        cube([14.6, 2.2, 1.75]);
                    hull() {
                        translate([4.20, -1.1, 1.10]) cube([14.6, 2.2, 0.15]);
                        translate([4.20, -0.6, 1.10]) cube([14.6, 1.2, 0.35]);
                    }
                }
            }
        }

        // Stage 4: Unobstructed 3.30x6.50mm Vertical JST-1.25mm Pass-Through Windows (100% outside |x|<=7.50mm Battery Bay)
        // + Diagonal Wire Channels & Localized Bottom-JST Header Relief Pockets (preserving full 2.40mm twin-beam rail height)
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx > 0 ? 7.55 : -10.85, sy > 0 ? 3.60 : -10.10, -0.5])
                cube([3.30, 6.50, 3.5]);
        }
        difference() {
            for (ang = [45, 135, 225, 315]) {
                rotate([0, 0, ang])
                    translate([8.4, -1.6, -0.5])
                        cube([6.4, 3.2, 3.5]);
            }
            // Preserve 100% of the Battery Bay outer walls & 1.40mm roof (Z <= 1.40mm within X = +/-7.5mm)
            translate([-(bat_w + 3.2)/2, -bat_l/2 - 4.0, -1.0])
                cube([bat_w + 3.2, bat_l + 8.0, 2.42]);
        }
        // 4B. Under-FC Wire Channel (between twin beams) & Outboard Bottom-JST Header Relief Pockets (Z = 1.40..3.0mm)
        // Keeps the flanking twin-beam diagonal rails (|Y_45| = 1.6..3.8mm) at their full 2.40mm structural thickness!
        for (ang = [45, 135, 225, 315]) {
            rotate([0, 0, ang]) {
                translate([8.0, -1.6, 1.40])
                    cube([6.8, 3.2, 1.6]);
                for (side_s = [-1, 1]) {
                    hull() {
                        translate([10.4, side_s * 4.5, 1.40]) cylinder(d = 2.0, h = 1.6);
                        translate([13.4, side_s * 5.2, 1.40]) cylinder(d = 2.4, h = 1.6);
                    }
                }
            }
        }

        // Stage 5: Localized Outer Duct Inward FC-Edge & Top-Wire Clearance Flats (r = 13.0..15.1mm on 4 diagonals, Z = 2.40..8.5mm)
        // Flush with Z = 2.40mm arm top (eliminates 0.05mm step) and leaves 32.6mm inner duct bores 100% intact
        for (ang = [45, 135, 225, 315]) {
            rotate([0, 0, ang])
                translate([13.0, -2.6, 2.40])
                    cube([2.1, 5.2, 6.0]);
        }

        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * motor_xy, sy * motor_xy, 2.4])
                difference() {
                    cylinder(d = duct_id, h = duct_h + 2.0);
                    if (!is_brushless) {
                        translate([0, 0, -0.5]) cylinder(d = brushed_od, h = duct_h + 3.0);
                    }
                }
        }

        for (ang = [0, 90, 180, 270]) {
            rotate([0, 0, ang])
                translate([fc_post_r, 0, -1.0])
                    cylinder(d = 1.75, h = 10.0);
        }
    }
}

module grizzly_ring65_frame(is_brushless = false) {
    minicub65_frame(is_brushless);
}

// ============================================================================
// 3. OSITO "CUBCAP" SCULPTED BEAR-EAR CANOPY (Lightweight Aerodynamic TPU Shell)
// ============================================================================
function cubcap_cbell(d, w) = (abs(d) >= w) ? 0 : pow(0.5 + 0.5 * cos((d / w) * 180), 1.55);
function cubcap_awrap(a) = a - 360 * floor((a + 180) / 360);

function cubcap_pt(u_deg, vt, inset = 0.0) =
    let(
        cr = cos(vt * 90),
        sz = sin(vt * 90),
        // Apex shifts gently forward (+2.5mm) for sleek teardrop rear slope & enclosed 14.3mm cam pocket
        yc = 2.5 * pow(vt, 1.22) - 0.2 * (1 - vt),

        // Smooth cheek, upper-brow & integrated forward nose hood swells
        cheek_swell = 0.68 * sin(vt * 180) * pow(abs(cos(u_deg)), 1.3),
        brow_swell  = 1.35 * pow(sin(vt * 180), 1.05) * (cubcap_cbell(cubcap_awrap(u_deg - 48), 48) + cubcap_cbell(cubcap_awrap(u_deg - 132), 48)),
        nose_hood   = (inset > 0 ? 0.35 : 1.0) * 1.95 * cubcap_cbell(cubcap_awrap(u_deg - 90), 40) * cubcap_cbell(vt - 0.14, 0.50),

        rx_core  = (12.0 - inset + cheek_swell) * cr + (inset > 0 ? 0.35 : 1.0) * brow_swell * cr,
        ry_front = (11.55 - inset) * cr + (inset > 0 ? 0.25 : 0.75) * brow_swell * cr + nose_hood,
        ry_rear  = (13.4 - inset) * cr,
        ry_core  = (sin(u_deg) >= 0) ? ry_front : ry_rear,

        // Unbroken S-curve flared fender skirts to Left (-X), Right (+X), and Rear (-Y) M2 mounts
        // Inner cavity (inset > 0) partially follows upper fender flare to core out heavy skirt wedges
        lobe_r  = cubcap_cbell(cubcap_awrap(u_deg - 0),   35),
        lobe_l  = cubcap_cbell(cubcap_awrap(u_deg - 180), 35),
        lobe_b  = cubcap_cbell(cubcap_awrap(u_deg + 90),  33),
        lobe_fc = (inset > 0) ? 0 : cubcap_cbell(vt, 0.34) * (cubcap_cbell(cubcap_awrap(u_deg - 68), 22) + cubcap_cbell(cubcap_awrap(u_deg - 112), 22)),

        skirt_outer = (inset > 0) ? 0 : cubcap_cbell(vt, 0.47),
        skirt_inner = (inset > 0) ? cubcap_cbell(vt, 0.40) : 0,

        flare_x = (skirt_outer * 9.20 + skirt_inner * 3.10) * (lobe_r + lobe_l) + 0.9 * lobe_fc,
        flare_y = (skirt_outer * 7.60 + skirt_inner * 2.10) * lobe_b + 2.2 * lobe_fc,

        x = (rx_core + flare_x) * cos(u_deg),
        y = yc + (ry_core + flare_y) * sin(u_deg),

        // Sculpted roofline: proud rounded brow + subtle central spine valley + sleek teardrop tail
        fore_lift   = 1.38 * sin(vt * 180) * max(0, sin(u_deg)),
        rear_taper  = -1.30 * sin(vt * 180) * max(0, -sin(u_deg)),
        brow_valley = (inset > 0 ? 0.08 : 0.30) * pow(sin(vt * 180), 1.3) * cubcap_cbell(cubcap_awrap(u_deg - 90), 20),
        brow_ridge  = (inset > 0 ? 0.20 : 0.85) * pow(sin(vt * 180), 1.02) * (cubcap_cbell(cubcap_awrap(u_deg - 50), 45) + cubcap_cbell(cubcap_awrap(u_deg - 130), 45)),

        z_raw = (14.85 - inset) * pow(sz, 0.87) + fore_lift + rear_taper + brow_ridge - brow_valley,
        z = (vt == 0) ? (-0.30 - inset * 0.5) : z_raw
    )
    [x, y, z];

module cubcap_loft_solid(inset = 0.0, nu = 72, nv = 24) {
    rings = [for (iv = [0 : nv - 1])
        let(vt = iv / nv)
        [for (iu = [0 : nu - 1]) cubcap_pt(iu * 360 / nu, vt, inset)]
    ];
    apex = cubcap_pt(90, 1.0, inset);
    pts = concat([for (r = rings) for (p = r) p], [apex]);
    apex_i = nu * nv;

    quad_tris = [for (iv = [0 : nv - 2]) for (iu = [0 : nu - 1])
        let(
            a = iv * nu + iu,
            b = iv * nu + ((iu + 1) % nu),
            c = (iv + 1) * nu + ((iu + 1) % nu),
            d = (iv + 1) * nu + iu
        )
        each [[a, b, c], [a, c, d]]
    ];
    cap_tris = [for (iu = [0 : nu - 1])
        [(nv - 1) * nu + iu, (nv - 1) * nu + ((iu + 1) % nu), apex_i]
    ];
    bot_face = [[for (iu = [nu - 1 : -1 : 0]) iu]];

    polyhedron(points = pts, faces = concat(quad_tris, cap_tris, bot_face), convexity = 8);
}

module canopy_cubcap_fpv() {
    difference() {
        // Clip outer positives strictly to Z >= 0.000mm for flat Bambu PEI bed seating
        intersection() {
            translate([-25, -25, 0]) cube([50, 50, 28]);
            union() {
                difference() {
                    union() {
                        // 1. Unbroken Class-A Aerodynamic Dome & S-Curve Flared Mounting Skirts
                        cubcap_loft_solid(inset = 0.0, nu = 72, nv = 24);

                        // 2A. Swept Multi-Angle (12..38 deg) Bullnose Camera Cowl & Sculpted Side Trunnion Bosses
                        hull() {
                            translate([0, 8.0, 6.2])
                                rotate([-(90 - CAM_TILT_DEG), 0, 0])
                                    translate([0, -0.10, 2.85])
                                        rotate_extrude($fn = 40)
                                            translate([5.65, 0])
                                                circle(r = 1.38, $fn = 20);
                            translate([0, 8.0, 6.2])
                                rotate([-(90 - CAM_TILT_MAX_DEG), 0, 0])
                                    translate([0, -0.05, 2.55])
                                        rotate_extrude($fn = 40)
                                            translate([5.52, 0])
                                                circle(r = 1.35, $fn = 20);
                            translate([0, 6.80, 7.55])
                                scale([1.02, 1.06, 0.94])
                                    sphere(r = 7.50, $fn = 36);
                        }
                        // Coaxial Left/Right Camera Trunnion Screw Bosses at [+/-X, 8.0, 6.2]
                        for (sx = [-1, 1]) {
                            hull() {
                                translate([sx * 9.35, 8.0, 6.2])
                                    rotate([0, sx * -90, 0])
                                        cylinder(d1 = 4.9, d2 = 6.0, h = 1.60, $fn = 28);
                                translate([sx * 6.50, 7.6, 6.1])
                                    sphere(r = 3.05, $fn = 24);
                            }
                        }

                        // 2B. Tucked Inboard Lower Cheek Fairings (Sweeps smoothly down to front apron with zero arch horn)
                        for (sx = [-1, 1]) {
                            hull() {
                                translate([0, 8.0, 6.2])
                                    rotate([-(90 - CAM_TILT_DEG), 0, 0])
                                        translate([sx * 4.65, 1.85, 2.35])
                                            sphere(r = 1.45, $fn = 24);
                                translate([sx * 5.05, 10.4, 1.85])
                                    sphere(r = 1.55, $fn = 24);
                                translate([sx * 4.2, 13.4, 0.0])
                                    cylinder(d = 4.2, h = 2.02, $fn = 28);
                            }
                        }

                        // 2C. Exact-Symmetry 4x M2 Pads + Low-Profile Curved Front Chin Apron (Z = 2.02mm below circular lens bezel)
                        for (ang = [0, 180, 270]) {
                            rotate([0, 0, ang])
                                hull() {
                                    translate([fc_post_r, 0, 0]) cylinder(d = 6.3375, h = 2.02, $fn = 36);
                                    translate([14.2, 0, 0]) cylinder(d = 5.6, h = 2.02, $fn = 28);
                                }
                        }
                        hull() {
                            translate([0, fc_post_r, 0]) cylinder(d = 6.3375, h = 2.02, $fn = 36);
                            for (sx = [-1, 1]) {
                                translate([sx * 4.2, 13.4, 0]) cylinder(d = 4.2, h = 2.02, $fn = 28);
                            }
                            translate([0, 10.5, 0]) cylinder(d = 5.6, h = 2.02, $fn = 28);
                        }

                        // 3. Signature Osito 3D-Rounded Bear-Cub Ears (Smooth forward-facing roll-bar lobes matching Hero photo)
                        for (sx = [-1, 1]) {
                            hull() {
                                translate([sx * 5.58, 0.48, 11.78])
                                    rotate([10, sx * 19, sx * -10])
                                        scale([1.14, 0.72, 0.90])
                                            sphere(r = 3.50, $fn = 32);
                                translate([sx * 7.08, 0.28, 13.80])
                                    rotate([10, sx * 21, sx * -10])
                                        scale([1.06, 0.64, 0.96])
                                            sphere(r = 3.16, $fn = 32);
                            }
                        }

                        // 4. Smoothly Faired Centered Rear 5.8GHz VTX Whip Guide at X = 0.0mm
                        hull() {
                            translate([0, -10.8, 3.2])
                                rotate([34, 0, 0])
                                    cylinder(d = 5.8, h = 6.3, $fn = 32);
                            translate([0, -9.8, 4.2])
                                rotate([34, 0, 0])
                                    scale([1.14, 1.06, 1.0])
                                        cylinder(d = 6.3, h = 1.8, $fn = 32);
                        }
                    }

                    // --- UNIFORM 1.38mm THIN-SHELL INTERIOR CAVITY + COWL & EAR CORING ---
                    union() {
                        cubcap_loft_solid(inset = 1.38, nu = 72, nv = 22);

                        // Core out interior behind multi-angle camera cowl (leaves front nose block solid for lens-clamp jaws)
                        hull() {
                            translate([0, 8.0, 6.2])
                                rotate([-(90 - CAM_TILT_DEG), 0, 0])
                                    translate([0, -0.3, 0.25])
                                        cylinder(d = 9.0, h = 0.35, $fn = 32);
                            translate([0, 8.0, 6.2])
                                rotate([-(90 - CAM_TILT_MAX_DEG), 0, 0])
                                    translate([0, -0.2, 0.20])
                                        cylinder(d = 8.8, h = 0.35, $fn = 32);
                            translate([0, 5.9, 6.5])
                                sphere(r = 5.35, $fn = 28);
                        }

                        // Clean ellipsoid ear-base coring (>=1.65mm backing behind front dimples)
                        for (sx = [-1, 1]) {
                            translate([sx * 5.75, 0.15, 11.45])
                                rotate([10, sx * 20, sx * -10])
                                    scale([0.90, 0.46, 1.22])
                                        sphere(r = 1.90, $fn = 24);
                        }

                        // Smooth rounded bottom camera insertion chute
                        translate([0, 4.3, -0.6])
                            linear_extrude(height = 6.4)
                                offset(r = 1.2, $fn = 20)
                                    square([11.8, 7.8], center = true);

                        // Internal Right-Flank U.FL (J_VTX_ANT & J_ANT_ELRS) Snap-Cap Pocket & Coax Sweep Channel to Rear VTX Hole
                        // Clears mated U.FL at (+15.06, +3.46) under 5.68mm outer fender skin with 45-deg self-supporting dome
                        hull() {
                            translate([14.70, 3.65, -0.5]) cylinder(d = 4.2, h = 1.85, $fn = 24);
                            translate([14.70, 3.65, 1.35]) cylinder(d1 = 4.2, d2 = 1.8, h = 1.05, $fn = 24);
                            translate([12.40, 5.20, -0.5]) cylinder(d = 4.4, h = 2.05, $fn = 24);
                            translate([12.40, 5.20, 1.55]) cylinder(d1 = 4.4, d2 = 2.0, h = 1.10, $fn = 24);
                            translate([8.60, 2.20, -0.5]) cylinder(d = 5.0, h = 2.80, $fn = 24);
                        }
                    }
                }

                // --- MOLDED INTERNAL CAMERA MOUNT HARDWARE (Trunnion Pads + 3-Step Ratchet Stops) ---
                // Internal flat camera-bracket pivot bearing pads at [+/-5.60..9.10, 8.0, 6.2]
                for (sx = [-1, 1]) {
                    translate([sx * 5.60, 8.0, 6.2])
                        rotate([0, sx * 90, 0])
                            cylinder(d1 = 4.2, d2 = 5.4, h = 3.50, $fn = 28);
                }
                // Internal 3-Step (12 / 25 / 38 deg) TPU Angle-Stop Ratchet Ribs fused cleanly into inner ceiling
                for (sx = [-1, 1], ta = [CAM_TILT_DEG, CAM_TILT_MID_DEG, CAM_TILT_MAX_DEG]) {
                    let(
                        wy_r = 8.0 - 6.65 * sin(ta) - 0.95 * cos(ta),
                        wz_r = 6.2 + 6.65 * cos(ta) - 0.95 * sin(ta)
                    )
                    hull() {
                        translate([sx * 3.25, wy_r, wz_r])
                            sphere(r = 0.65, $fn = 18);
                        translate([sx * 3.25, wy_r, 13.55])
                            sphere(r = 0.65, $fn = 18);
                    }
                }
            }
        }

        // A. Subtle Soft 3D Concave Front Ear Indentations
        for (sx = [-1, 1]) {
            translate([sx * 7.00, 2.25, 14.05])
                rotate([10, sx * 21, sx * -10])
                    scale([0.92, 0.30, 0.92])
                        sphere(r = 1.72, $fn = 28);
        }

        // B. Symmetric Low-Profile Scalloped Bottom Fender Arches on All 4 Diagonals (Clears ANT1, USB-C & J1 with zero cheek horn)
        // Front-Left (-X,+Y) & Front-Right (+X,+Y): sleek low Z=2.05mm gentle arches shifted to +/-46 deg (clears ANT1 Z=0.60mm)
        for (sx = [-1, 1]) {
            rotate([0, 0, sx * 46])
                translate([0, 13.8, -0.35])
                    rotate([90, 0, 0])
                        linear_extrude(height = 12.0, center = true)
                            hull() {
                                for (kx = [-1, 1]) translate([kx * 1.45, 0]) circle(r = 2.40, $fn = 28);
                            }
        }
        // Rear-Right (+X,-Y) at (+10.2, -10.2): symmetric low Z=2.45mm arch
        rotate([0, 0, 45])
            translate([0, -14.4, -0.45])
                rotate([90, 0, 0])
                    linear_extrude(height = 12.0, center = true)
                        hull() {
                            for (kx = [-1, 1]) translate([kx * 2.5, 0]) circle(r = 2.90, $fn = 28);
                        }
        // Rear-Left (-X,-Y) at (-10.0, -10.0): -45 deg USB-C J1 receptacle & plug access arch (clears J1 top Z=1.00mm)
        rotate([0, 0, -45])
            translate([0, -14.2, -0.4])
                rotate([90, 0, 0])
                    linear_extrude(height = 12.0, center = true)
                        hull() {
                            for (sx = [-1, 1]) translate([sx * 3.8, 0]) circle(r = 3.3, $fn = 28);
                            for (sx = [-1, 1]) translate([sx * 4.6, -2.0]) circle(r = 2.0, $fn = 20);
                        }

        // C. Multi-Angle (12 / 25 / 38 deg) Compliant Lens-Clamp Cradle, Trunnion Mounts & Top Lock Track
        // 1) Swept 12..38 deg rear camera throat pocket (stays 100% inside dome cheek walls)
        hull() {
            for (ta = [CAM_TILT_DEG, CAM_TILT_MID_DEG, CAM_TILT_MAX_DEG]) {
                translate([0, 8.0, 6.2])
                    rotate([-(90 - ta), 0, 0])
                        translate([0, 0, -2.35])
                            linear_extrude(height = 1.70)
                                offset(r = 1.35, $fn = 24)
                                    square([8.5, 8.9], center = true);
            }
        }
        // Smooth transition funnel from rear camera throat into 3-position lens barrel clamp
        hull() {
            for (ta = [CAM_TILT_DEG, CAM_TILT_MAX_DEG]) {
                translate([0, 8.0, 6.2])
                    rotate([-(90 - ta), 0, 0]) {
                        translate([0, 0, -0.80])
                            linear_extrude(height = 0.20)
                                offset(r = 1.35, $fn = 24)
                                    square([8.3, 8.7], center = true);
                        translate([0, 0, -0.22])
                            scale([0.90, 0.99, 1.00])
                                cylinder(d = 8.84, h = 0.20, $fn = 34);
                    }
            }
        }
        // 2) 3-Position (12 / 25 / 38 deg) Scalloped Compliant TPU Lens-Barrel Clamp Seats (staggered caps prevent float32 T-junctions)
        translate([0, 8.0, 6.2])
            rotate([-(90 - CAM_TILT_DEG), 0, 0])
                translate([0, 0, -0.46])
                    scale([0.91, 1.00, 1.00])
                        cylinder(d = 9.00, h = 2.72, $fn = 36);
        translate([0, 8.0, 6.2])
            rotate([-(90 - CAM_TILT_MID_DEG), 0, 0])
                rotate([0, 0, 5.0])
                    translate([0, 0, -0.56])
                        scale([0.91, 1.00, 1.00])
                            cylinder(d = 9.05, h = 2.92, $fn = 36);
        translate([0, 8.0, 6.2])
            rotate([-(90 - CAM_TILT_MAX_DEG), 0, 0])
                rotate([0, 0, 2.5])
                    translate([0, 0, -0.50])
                        scale([0.91, 1.00, 1.00])
                            cylinder(d = 8.97, h = 2.79, $fn = 36);
        // Pinch-waist detent transition channel so lens barrel clicks positively between 12, 25, and 38 deg
        hull() {
            for (ta = [CAM_TILT_DEG, CAM_TILT_MAX_DEG]) {
                translate([0, 8.0, 6.2])
                    rotate([-(90 - ta), 0, 0])
                        translate([0, 0, -0.60])
                            scale([0.84, 0.92, 1.00])
                                cylinder(d = 8.68, h = 2.98, $fn = 32);
            }
        }
        // 3) Swept Front Optical Viewport + Continuous 0.60mm Inward TPU Lens-Retaining Crash Lip
        hull() {
            for (ta = [CAM_TILT_DEG, CAM_TILT_MAX_DEG]) {
                translate([0, 8.0, 6.2])
                    rotate([-(90 - ta), 0, 0])
                        translate([0, 0, 2.15])
                            cylinder(d1 = 7.76, d2 = 9.40, h = 6.2, $fn = 36);
            }
        }
        // 4) Left & Right Internal Compliant Leaf-Spring Flex-Relief Grooves (2-wall inner jaw + 3-wall outer hood)
        for (sx = [-1, 1]) {
            translate([0, 8.0, 6.2])
                rotate([-(90 - CAM_TILT_MID_DEG), 0, 0])
                    translate([sx * 5.32, 0.0, 0.25])
                        linear_extrude(height = 4.65)
                            hull() {
                                translate([0, -1.20]) circle(d = 0.72, $fn = 20);
                                translate([0,  1.20]) circle(d = 0.72, $fn = 20);
                            }
        }
        // 5) Coaxial Left/Right 1.75mm M1.4/M2 Camera Pivot Screw Holes + Recessed Screw-Head Seats at [0, 8.0, 6.2]
        translate([0, 8.0, 6.2])
            rotate([0, 90, 0])
                cylinder(d = 1.75, h = 24.0, center = true, $fn = 24);
        for (sx = [-1, 1]) {
            translate([sx * 8.85, 8.0, 6.2])
                rotate([0, sx * 90, 0])
                    cylinder(d1 = 3.3, d2 = 3.8, h = 2.5, $fn = 24);
        }
        // 6) Top-Brow 3-Detent Keyhole Angle-Selector Slot (12 / 25 / 38 deg M1.4 Rear Top-Tab Lock Track)
        for (ta = [CAM_TILT_DEG, CAM_TILT_MID_DEG, CAM_TILT_MAX_DEG]) {
            translate([0, 8.0, 6.2])
                rotate([-(90 - ta), 0, 0])
                    translate([0, 0, -2.15])
                        rotate([90, 0, 0])
                            rotate([0, 0, 9])
                                translate([0, 0, 4.2])
                                    cylinder(d = 1.72, h = 11.2, $fn = 20);
        }
        hull() {
            for (ta = [CAM_TILT_DEG + 1.2, CAM_TILT_MAX_DEG - 1.2]) {
                translate([0, 8.0, 6.2])
                    rotate([-(90 - ta), 0, 0])
                        translate([0, 0, -2.15])
                            rotate([90, 0, 0])
                                translate([0, 0, 4.0])
                                    cylinder(d = 1.22, h = 11.6, $fn = 16);
            }
        }

        // D. 3x Fully-Enclosed Upward-Sweeping Pill Side Gill Louvers on Left & Right Flanks (Matches Hero Photo)
        for (gi = [0, 1, 2]) {
            let(
                gz = 5.45 + gi * 1.48,
                gy = 0.80 - gi * 0.34,
                glen = (gi == 1) ? 6.4 : ((gi == 0) ? 5.5 : 5.0)
            )
            translate([0, gy, gz])
                rotate([-14, 0, 0])
                    rotate([0, 90, 0])
                        linear_extrude(height = 46.0, center = true)
                            hull() {
                                translate([0, -glen/2]) circle(d = 1.06, $fn = 20);
                                translate([0,  glen/2]) circle(d = 1.06, $fn = 20);
                            }
        }

        // E. Centered 12.2 x 5.2 mm Stadium Top-Rear VTX Cooling & U.FL Access Window
        translate([0, -5.1, 7.50])
            rotate([25, 0, 0])
                hull() {
                    for (sx = [-1, 1])
                        translate([sx * 3.5, 0, 0])
                            cylinder(d = 5.2, h = 8.0, $fn = 24);
                }

        // F. Centered 4.0mm Rear Coaxial VTX Whip / U.FL Antenna Through-Bore + Smooth Internal Bellmouth Funnel at X = 0.0mm
        translate([0, -10.8, 3.2])
            rotate([34, 0, 0]) {
                translate([0, 0, -4.5])
                    cylinder(d = 4.0, h = 15.0, $fn = 32);
                translate([0, 0, -3.2])
                    cylinder(d1 = 6.0, d2 = 3.5, h = 4.2, $fn = 32);
            }

        // G. 4x Diamond M2 Screw Holes + Molded Button-Head Spotfaces + Bottom Silicone Grommet Counterbores
        for (ang = [0, 90, 180, 270]) {
            rotate([0, 0, ang])
                translate([fc_post_r, 0, 0]) {
                    translate([0, 0, -1.0])
                        cylinder(d = 2.20, h = 8.0, $fn = 28);
                    translate([0, 0, -0.2])
                        cylinder(d = 4.02, h = 1.23, $fn = 32);
                    translate([0, 0, 1.02])
                        cylinder(d1 = 4.02, d2 = 2.20, h = 0.50, $fn = 32);
                    translate([0, 0, 2.02])
                        cylinder(d1 = 4.6, d2 = 8.8, h = 3.5, $fn = 32);
                }
        }
    }
}

module cubcap_canopy() {
    canopy_cubcap_fpv();
}

// ============================================================================
// MASTER ASSEMBLY / PART SELECTOR
// ============================================================================
if (PART_ID == 1 || PART_SELECT == "FRAME_BRUSHED") {
    // Print orientation: inverted 180 deg so all 4 duct rims + flush 0615 pods sit flat on PEI bed & battery holder faces UP
    rotate([180, 0, 0]) minicub65_frame(is_brushless = false);
} else if (PART_ID == 2 || PART_SELECT == "FRAME_BRUSHLESS") {
    // Print orientation: inverted 180 deg so all 4 duct rims sit flat on PEI bed & battery holder faces UP
    rotate([180, 0, 0]) minicub65_frame(is_brushless = true);
} else if (PART_ID == 3 || PART_SELECT == "CANOPY_CUBCAP") {
    canopy_cubcap_fpv();
} else if (PART_ID == 4 || PART_SELECT == "FC_CUBBRAIN") {
    fc_cubbrain_mockup();
} else {
    color("#1B1B1B") minicub65_frame(is_brushless = false);
    translate([0, 0, 5.5]) rotate([0, 0, -45]) color("#232A68") fc_cubbrain_mockup();
    translate([0, 0, 9.1]) color("#7077CF") canopy_cubcap_fpv();
    // 5.8GHz Coaxial Dipole VTX Whip exiting cleanly out the centered 34-deg rear bore
    translate([0, -10.8, 9.1 + 3.2]) rotate([34, 0, 0]) {
        color("#1F2937") cylinder(d = 1.9, h = 18.0, $fn = 20);
        translate([0, 0, 18.0]) color("#DC2626") cylinder(d = 1.2, h = 12.9, $fn = 16);
    }
}
