# `CubBrain-65 AIO` (`OSITO-65-1S-ELRS-AIO REV 2.2`) — Turnkey 4-Layer JLCPCB Custom PCB Engineering Blueprint

**Board Part Number:** `OSITO-65-1S-ELRS-AIO REV 2.2` (`CubBrain-65 AIO` — JLCPCB Turnkey Production Release)  
**Mechanical Envelope:** `29.00 × 29.00 × 1.00 mm` (`R1.75 mm` rounded corners, `4× Ø2.10 mm` M2 NPTH mounting holes at `25.50 × 25.50 mm`)  
**Controlled-Impedance Stackup:** **`JLCPCB JLC04101H-3313`** (`1.00 mm` High-Tg `TG170` FR-4, `L1 F.Cu 1 oz` / `L2 In1.Cu 0.5 oz` Solid `GND` / `L3 In2.Cu 0.5 oz` Split Power / `L4 B.Cu 1 oz`, `3313` `3.92 mil` prepreg, `ENIG` gold finish, Matte Black `+0.03 mm/side` solder mask)  
**Controlled `50 Ω` RF Lines:** `0.18 mm` Coplanar Waveguide with Ground (`CPWG`) for `2.4 GHz` ExpressLRS (`SX1280` `Pin 21 = RFIO` $\rightarrow$ `ANT1` / `J_ANT_ELRS`) and `5.8 GHz` VTX (`RTC6705` $\rightarrow$ `RTC6659E` $\rightarrow$ `J_VTX_ANT`), with full 4-layer copper keepout (`F.Cu`/`In1.Cu`/`In2.Cu`/`B.Cu`) under `ANT1`  
**Turnkey SMT Assembly:** `130` SMT Components (`67` Top / `63` Bottom `B.Cu` X-mirrored CCW) across `53` BOM lines (`100%` 1-to-1 BOM $\leftrightarrow$ CPL parity, zero `85°C` `X5R` parts)  
**Routing & DRC Status:** **`123 / 123` Active Nets Routed (`100.0%`) $\cdot$ `3,029` Copper Segments (`2,419.92 mm`) $\cdot$ `425` Plated Vias $\cdot$ `6×` Optical Fiducials $\cdot$ `10×` 2-Wire C2 Pogo Pads $\cdot$ `0` DRC Violations (`PASS`)**

---

## 1. Photorealistic Assembled PCBA & 4-Layer Routing Inspection Views

| Photorealistic Assembled PCBA (`Top F.Cu + Bottom B.Cu`) | 4-Layer Master Routing Map (`JLC04101H-3313`) |
| :---: | :---: |
| ![Photorealistic Top and Bottom PCBA](./pcb/CubBrain65_AIO_Photorealistic_Top_and_Bottom_PCBA.png) | ![4-Layer Master Routing Map](./pcb/OSITO_CUBBRAIN65_AIO_4Layer_Routing_Master_Map.png) |

| Layer 1 (`F.Cu` — `1,114` Traces) | Layer 2 (`In1.Cu` — Solid `GND` + `544` Traces) | Layer 3 (`In2.Cu` — Split Power + `445` Traces) | Layer 4 (`B.Cu` — `926` Traces) |
| :---: | :---: | :---: | :---: |
| ![F.Cu](./pcb/PCB_Layer1_Top_FCu_Routing.png) | ![In1.Cu](./pcb/PCB_Layer2_In1_GND_Plane.png) | ![In2.Cu](./pcb/PCB_Layer3_In2_Power_Planes.png) | ![B.Cu](./pcb/PCB_Layer4_Bottom_BCu_ESC_and_VTX.png) |

---

## 2. Datasheet-Verified IC Pinout & DFM Architecture (`REV 2.2`)

1. **`U1` (`STM32F411CEU6` `UFQFPN-48` — Top `F.Cu`)**: `Pin 22 = VCAP1` (`2.2 µF X7S`), `Pin 23 = VSS (GND)`, `Pin 24 = VDD (+3V3_DIG)`; `DMA2 Stream 4` conflict-free `ADC1`; `6× Ø0.60 mm` top pogo pads (`TP_SWDIO`, `TP_SWCLK`, `TP_NRST`, `TP_BOOT0`, `TP_3V3`, `TP_GND`).
2. **`U2` (`Bosch BMI270` `LGA-14` — Top `F.Cu`)**: Powered by dedicated ultra-low-noise `LP5907MFX-3.3` LDO (`U12`, `+3V3_GYRO` on `Pins 5, 8`); `Pin 12 = CSB`, `Pin 13 = SCX`, `Pin 14 = SDX`, `Pin 1 = SDO`; unused OIS/INT2 pins left floating (`NC`).
3. **`U3` (`Semtech SX1280IMLTRT` `QFN-24` — Top `F.Cu`)**: `Pin 1 = VR_PA` (`ELRS_VR_PA`), `Pin 14 = DCC_SW` (`15 µH` `L_RF`), `Pin 19 = NSS`, `Pin 21 = RFIO` (`0.18 mm` `50 Ω` CPWG to Pi-match `C23/L1_RF/C24` and `ANT1`, with `In1.Cu` & `In2.Cu` notched `y <= 12.15 mm` under `ANT1`).
4. **`U4` (`AT7456E` `HTSSOP-28-EP` — Top `F.Cu`)**: Independent RC-filtered `OSD_DVDD` (`R7/C29`) & `OSD_AVDD` (`R6/C28`), `+5V_CLEAN` on `Pins 19, 24`, AC-coupled `75 Ω` video output (`Pins 25, 26` $\rightarrow$ `C31` $\rightarrow$ `R9`).
5. **`U5–U8` (`EFM8BB21F16G-C-QFN20`) + `Q1A–Q4B` (`AO4614B`) + `Q_DRV1–Q_DRV4` (`BC847BS`)**: 4-channel `12A` Full H-Bridge bidirectional DShot300 ESCs; all bottom `QFN-20` footprints X-mirrored (`CCW` bottom-view handedness) with dedicated `C2D` (`Pin 6`) + `C2CK` (`Pin 5`) pogo pads (`TP_C2D_M1..4`, `TP_C2CK_M1..4`).
6. **`U13` (`RichWave RTC6705` `QFN-40`) + `U14` (`RTC6659E` `QFN-16`) + `U15` (`EFM8BB10F8G` `QFN-20` — Bottom `B.Cu`)**: `U13` powered strictly from **`+3V3_DIG` (`3.3 V`, `< 3.6 V` abs-max)** across all 9 VCC pins (`1, 8, 13, 17, 22, 30, 31, 32, 39`, `20` internal pins left `NC`); `U14` `200 mW` PA on `+5V_CLEAN`; `U15` SmartAudio MCU with `TP_C2D_VTX` + `TP_C2CK_VTX` (`10×` total C2 pogo pads).
7. **`J1` (`TYPE-C-31-M-12` 12-Pin USB-C) + `D1` (`USBLC6-2SC6`)**: `4×` `G85` plated oval shield slots (`0.60 × 1.70 mm` & `0.60 × 1.20 mm`), `2× Ø0.65 mm` NPTH locator pegs at `(±2.89, -9.65) mm` with `Ø1.15 mm` inner-plane antipads, and dual `5.1 kΩ` `CC1`/`CC2` pull-downs (`R10`, `R11`).
8. **JLCPCB Turnkey Stencil & Optical Alignment**: `6×` optical SMT fiducials (`3 Top + 3 Bottom`, `Ø0.80 mm` Cu / `Ø1.60 mm` solder-mask opening), `0.120 mm` minimum matte-black solder-mask dam (`+0.03 mm/side`), `11` QFN thermal pads with `2×2` windowed paste apertures (`~58%` coverage), and `28` manual/pogo/fiducial pads excluded from paste.

---

## 3. Verified 15-Category DRC Summary (`pcb/drc_verification_report.json`)

| Metric / DRC Rule | Requirement | Verified `REV 2.2` Result | Verdict |
| :--- | :--- | :--- | :---: |
| **Active Netlist Completion & Shorts** | `123 / 123` Nets (`100%`), `0` Shorts | **`123 / 123` (`100.0%`), `0` Shorts** | **PASS** ✅ |
| **Routed Copper Segments & Vias** | Complete 4-Layer Physical + Plane Routing | **`3,029` Segments (`2,419.92 mm`), `425` Plated Vias** (`F.Cu=1,114`, `In1=544`, `In2=445`, `B.Cu=926`) | **PASS** ✅ |
| **Pad-to-Pad & Matte-Black Mask Dam** | `>= 0.100 mm` P2P / `>= 0.100 mm` Mask Dam | **`0.1750 mm` P2P / `0.1200 mm` Mask Dam** | **PASS** ✅ |
| **Trace-to-Pad / Via-to-Pad / Trace-to-Via** | `>= 0.100 mm` (`4.0 mil`) | **`0.1024 mm` T2P / `0.1150 mm` V2P / `0.1150 mm` T2V** | **PASS** ✅ |
| **Trace-to-Trace / Via-to-Via / Drill-to-Cu** | `>= 0.100 mm` Cu / `>= 0.200 mm` Drill | **`0.1028 mm` T2T / `0.1152 mm` V2V / `0.2050 mm` Drill** | **PASS** ✅ |
| **`In2.Cu` Split Power Isolation** | `>= 0.400 mm` Polygon Trench | **`0.4000 mm`** (`VBAT_ESC`, `+5V_CLEAN`, `+3V3_DIG`, `+5V_RAW`) | **PASS** ✅ |
| **Edge.Cuts, M2 & USB-C Peg Keepouts** | `>= 0.450 mm` Edge/M2, `>= 0.200 mm` Peg | **`0.4600 mm` Edge / `0.4598 mm` M2 / `0.2053 mm` Peg** | **PASS** ✅ |
| **2-Pin Series Shorts & High-Current Width** | `0 / 85` Shorts, `>= 0.35 mm` Motor/Power | **`0 / 85` Shorts, `0.35–1.20 mm` Width (`0` Neck-Downs)** | **PASS** ✅ |
| **Courtyards, Fiducials, Paste & Silkscreen** | `0` Collisions, `6` Fiducials, `11` QFN Windowed | **`0` Collisions, `6` Fiducials, `11/11` QFN, `0` Silk Overlaps** | **PASS** ✅ |
