# OSITO MINICUB-65 BNF (`REV 2.2`): Flagship 65mm 1S ELRS Hardware Architecture, Avionics, CAD, Firmware & Production Blueprint

**Platform Designation:** `Osito MiniCub65 BNF` (`Trim A: CubCore 0615 Brushed H-Bridge` & `Trim B: CubSpin 0702SE 25,000KV Brushless`)  
**Product Positioning:** Osito Drone LLC Flagship Sub-50g 65mm 1S ELRS Classroom STEM Trainer, Indoor FPV Racer & Arena Micro-Drone  
**Flight Controller Core:** `CubBrain-65 AIO` (`OSITO-65-1S-ELRS-AIO REV 2.2` — $29.0 \times 29.0 \times 7.6\text{ mm}$, $25.5 \times 25.5\text{ mm}$ Diamond M2 Mount, JLCPCB `JLC04101H-3313` `1.00 mm` Controlled-Impedance Stackup)  
**Proprietary Airframe & Canopy:** `Grizzly-Ring 65` (`Bambu PETG-CF`, `4.1g` Brushed / `3.8g` BL) + `Osito CubCap` Bear-Ear Canopy (`Bambu TPU 68D / 95A HF`, `1.6g`)  
**Verified Mass Envelope:** **`Trim A (0615 Brushed)`: `18.2g` Dry / `26.4g` AUW (`5:30–6:15 min` Flight)** $\cdot$ **`Trim B (0702SE Brushless)`: `17.4g` Dry / `25.6g` AUW (`4:30–5:15 min` Flight)** (with `8.2g` `CubCell 300mAh 1S 80C LiHV`)  
**Audit Status:** **PASSED ALL 5 VISIONARY GATES (`88%` Core Fleet Reuse | `<50g` Youth STEM & FAA Part 89 Exempt | `68/68` Firmware & FCC Part 15.249 Lock | `67.7%–70.1%` Gross Margin)**

---

## 0. Studio Product Photography & `CubBrain-65 AIO` Hardware Visuals

| Assembled `Osito MiniCub65 BNF` (`Grizzly-Ring 65` + `CubCap`) | `CubBrain-65 AIO` (`29×29mm` 4-Layer `TG170` Flight Controller) | Complete `MiniCub65 BNF` Modular Kit Flat-Lay |
| :---: | :---: | :---: |
| ![Osito MiniCub65 BNF Drone](./images/OSITO_MINICUB65_BNF_Hero_Drone.jpg) | ![Osito CubBrain-65 AIO PCB Closeup](./images/OSITO_CUBBRAIN65_AIO_PCB_Closeup.jpg) | ![Osito MiniCub65 BNF Kit Flat-Lay](./images/OSITO_MINICUB65_BNF_Kit_Knolling.jpg) |
| *8-Sided `Octa-Facet` `PETG-CF` ducts, tangential `Tri-Truss` motor struts, and Periwinkle Indigo (`#7077CF`) Bear-Ear `CubCap` canopy.* | *Matte black 4L `TG170` FR4, `ENIG` gold pads, center `STM32F411CEU6`, `BMI270` + `LP5907` LDO, `SX1280` ELRS ceramic antenna, and 4L `PTH` `BAT+`/`BAT-` anchors.* | *Complete solder-free modular BNF architecture: `Grizzly-Ring 65` frame, `CubBrain-65 AIO`, `CubCap` TPU hood, `800TVL` cam, plug-in motors, `31mm` props, and `CubCell` 1S packs.* |

---

## 1. Executive Summary: Proprietary `Osito MiniCub65 BNF` System Architecture

The **`Osito MiniCub65 BNF`** is Osito Drone LLC's in-house engineered 65mm 1S ExpressLRS micro-drone platform, purpose-built in San Francisco for K–12 STEM Youth Drone Academy classrooms, indoor FPV racing arenas, and direct-to-consumer (`ositodrone.com`) pilots.

```mermaid
flowchart LR
    subgraph AIRFRAME["1. Proprietary Airframe & Hood"]
        GR["Grizzly-Ring 65 Airframe\n(Octa-Facet PETG-CF + Tri-Truss Struts)"]
        CC["Osito CubCap Canopy\n(Bear-Ear TPU 68D + VTX Louvers)"]
        TG["Cantilevered BT2.0 Tail Gate\n(Zero PCB Solder Pad Tension)"]
    end

    subgraph AVIONICS["2. CubBrain-65 4-Layer TG170 AIO"]
        HB["True Full H-Bridge Brushed ESC\n(4x EFM8BB21 + 8x AO4614B Turtle Mode)"]
        PTH["4-Layer PTH Battery Pads + BT2.0\n(TPS63020 5V 2A Buck-Boost BEC)"]
        THERM["High-Heat TG170 + 125°C X7R/X7S\n(Disarmed 25mW VTX + 0.4s Stage-2 DROP)"]
    end

    subgraph ECON["3. Unit Economics & STEM GTM"]
        SKU1["SKU 1: Brushed BNF ($99.99)\n$29.85 BOM -> 70.1% Margin"]
        SKU2["SKU 2: Brushless BNF ($119.99)\n$36.40 BOM -> 69.7% Margin"]
        SKU3["SKU 3: 10-Pack STEM Pod ($1,995)\n$645 BOM -> +$1,350 Profit/School"]
    end

    AIRFRAME --> AVIONICS --> ECON
```

---

## 2. Proprietary Subsystem Taxonomy & Industrial Design Features

| Subsystem | Proprietary `Osito MiniCub65` Component Name | Part / Firmware ID | Core Engineering & Industrial Design Innovation |
| :--- | :--- | :--- | :--- |
| **Complete 65mm BNF Drone** | **`Osito MiniCub65 BNF`** (`MiniCub65-BR` Brushed / `MiniCub65-BL` Brushless) | `OSITO-MC65-BR` / `OSITO-MC65-BL` | Sub-30g (`26.4g` / `25.6g` AUW) ducted micro-drone in signature **Periwinkle Indigo (`#7077CF`)**, **Deep Royal (`#232A68`)**, and **Stealth Matte Black (`#161616`)**. |
| **29×29mm AIO Flight Controller** | **`CubBrain-65 AIO`** (`OSITO-65-1S-ELRS-AIO REV 2.2`) | `CUBBRAIN-65 REV 2.2` (`OSITO_MINICUB65`) | 4-Layer `TG170` FR4 (`JLC04101H-3313`, `1 oz` Outer / `0.5 oz` Inner Cu, `0.18 mm` `50 Ω` CPWG RF), `STM32F411CEU6`, isolated `LP5907` LDO + `BMI270` gyro, `SX1280` SPI3 ELRS (`ANT1` 4-layer keepout), `AT7456E` OSD, `3.3V` `RTC6705` + `RTC6659E` `25–200mW` SmartAudio VTX, `6×` optical fiducials, `10×` C2 pogo pads, and `B.Cu`-mirrored bottom `JST-1.25mm` motor headers (`±5.20, ±12.20 mm`). |
| **65mm Ducted Airframe** | **`Grizzly-Ring 65` Airframe** (`Bambu PETG-CF` Slot 1) | `GRIZZLY-RING-65` | **8-Sided `Octa-Facet` Chamfered Outer Bumper** + **Inward-Aligned 3-Spoke `Tangential Swirl Tri-Truss` Struts (`45°` Crowned Wire Trough)** + **Unobstructed `3.30×6.50mm` Vertical `JST-1.25mm` Pass-Through Windows**. |
| **FPV Camera Canopy** | **`Osito CubCap` Bear-Ear Louvered Canopy** (`Bambu TPU 68D` Slot 4 / `TPU 95A HF`) | `CUBCAP-65` | Photorealistic organic **`1.38 mm` thin-shell (`1,993 mm³`, `-36.6%` lighter)** aerodynamic hood featuring **3D-rounded ellipsoidal Bear-Cub Ears** with soft front dimples, **6 swept side gill louvers**, **`12°` bullnose camera cowl** (press-fit `14.3 × 14.3 mm` PCB pocket + `Ø10.4 mm` barrel + `Ø9.0 mm` TPU crash lip + `M1.4/M2` side screw holes), **`12.2 × 5.2 mm` stadium VTX cooling/U.FL window**, and **centered `Ø4.0 mm` rear VTX antenna bore (`X = 0.0 mm`)**. |
| **Micro Analog FPV Camera** | **`CubVision 800TVL` Global-WDR Micro Cam** (`1.1g`) | `OSITO-CUBVISION` | $1/4''$ Global-WDR CMOS sensor, $150^\circ$ diagonal FOV, plug-and-play 3-pin `JST-SH 1.0mm` connector for 60-second solder-free classroom servicing. |
| **Propulsion Motors** | **`CubCore 0615` (`19,500KV` Brushed)** / **`CubSpin 0702SE` (`25,000KV` BLDC)** | `OSITO-0615` / `OSITO-0702SE` | Pre-crimped `JST-1.25mm` 2-pin (`4.25×2.85mm` Brushed) and 3-pin (`5.50×2.85mm` Brushless) motor plugs routed through `45°`-crowned under-strut U-channels and unobstructed `3.30×6.50mm` vertical pass-through windows for zero-solder, zero-de-pinning servicing. |
| **1S 300mAh LiHV Battery** | **`CubCell 300mAh 1S 80C LiHV`** (`BT2.0` + `PH2.0` Solid-Pin Adapter) | `CUBCELL-1S-300HV` | Ultra-low-resistance `BT2.0` connector (`<4 mΩ`, `9A` continuous / `15A` burst) routed through the frame's **Cantilevered Strain-Relief Tail Gate**. |

---

## 3. Five Signature Hardware & Reliability Breakthroughs (+ 5-Stage Motor Wire Routing Audit)

| # | Core Subsystem | `Osito MiniCub65 BNF` Engineering Breakthrough |
| :---: | :--- | :--- |
| **1** | **Bidirectional Brushed Turtle Mode (`Trim A`)** | **True 4-Channel Full H-Bridge Brushed ESC:** 4× `EFM8BB21F16G` (`U5–U8`, `Bluejay v0.21`) + 8× `AO4614B` (`Q1A–Q4B`, `12A` Complementary N+P MOSFETs) + 4× `BC847BS` (`Q_DRV1–Q_DRV4`) enable **DShot300 Bidirectional Crash-Flip (Turtle Mode at `70%` thermal cap)** on brushed `0615` motors (`J_M1–J_M4`) so students flip inverted drones upright remotely via `Switch SC`. *(Trim B swaps the output stage to 3-phase BLDC half-bridges + 3-pin `A1257WV-S-3P` headers).* |
| **2** | **Sag-Proof 1S Power Architecture** | **Unified `BT2.0` (`<4 mΩ`) + `TPS63020` Buck-Boost BEC + `220µF 105°C` POSCAP (`C_BULK`):** Holds rock-solid `5.0V` regulation for the MCU, OSD, and VTX all the way down to `1.8V` battery sag. |
| **3** | **Tear-Proof Battery Lead Retention** | **4-Layer Plated Through-Hole (`PTH`) Battery Pads (`PAD_BAT+`/`PAD_BAT-`) + Rear Frame Strain Gate:** `Ø1.00mm` drills anchored across `F.Cu`, `In1.Cu`, `In2.Cu`, and `B.Cu` provide $>5\times$ peel strength while the frame's rear bridge absorbs all battery pull forces. |
| **4** | **High-Heat ($85\,^\circ\text{C}\text{–}105\,^\circ\text{C}$) Thermal & Voltage Guard** | **`TG170` 4L `JLC04101H-3313` (`1oz/0.5oz`) PCB + `125°C X7R/X7S` Caps + `3.3V` `RTC6705` Supply + `vtx_low_power_disarm = ON`:** Powers `U13` (`RTC6705`) strictly from `+3V3_DIG` (`< 3.6V` abs-max) and `U14` (`RTC6659E` PA) from `+5V_CLEAN`, throttles VTX to `25mW` while disarmed, vents heat through 4 under-VTX battery tray chimneys and top `CubCap` louvers, and displays live MCU junction temp on the OSD (`osd_core_temp_alarm = 85`). |
| **5** | **On-Demand San Francisco Print Farm Manufacturing** | **In-House `Bambu PETG-CF` Frame (`$0.28`, `4.1g`) + `Bambu TPU 68D` Bear-Ear Canopy (`$0.15`, `1.6g`):** Printed in batches of 24 units in 6.5 hours on Osito's 2× Bambu Lab P2S Combo farm (`8 frames/plate` in Slot 1, `12 canopies/plate` in Slot 4). |

### 3.1 Five-Stage Zero-Pinch / Zero-Prop-Strike Motor Wire Routing Architecture (`0615` & `0702SE` + Universal `25.5×25.5mm` 1S AIO Compatibility)

1. **Stage 1 — Motor Hub Wire Exit (`0615` Full-Height C-Clamp Slot & `0702SE` Inward-Aligned `60°/180°/300°` Pad)**:
   - **Trim A (`0615` Brushed)**: Each `Ø6.10mm` motor socket features a full-height (`Z = -3.5` to `+10.5mm`, `X = 0` to `4.35mm`) `1.50mm` wide inward C-clamp wire slot oriented along `inward_ang = atan2(sy, sx) + 180` (piercing 100% of the `r = 4.30mm` pod wall without cutting into Spoke 1's top ceiling), plus a `2.20mm` wide × `4.75mm` tall bottom endbell relief arch and a `3.10mm` wide bottom-lip cutout so pre-crimped `JST-1.25mm` 2-pin motors (`4.25 × 2.85mm` plug) pass straight through or slip in laterally without de-pinning.
   - **Trim B (`0702SE` Brushless)**: Each `Ø10.2mm` (`r = 5.10mm`) motor pad aligns its 3× `M1.4` screw holes (`6.60mm` BCD) at `inward_ang + [60°, 180°, 300°]`, placing all 3 screw heads cleanly in the open sectors between the 3 struts (`0°, 120°, 240°`) while leaving `inward_ang + 0°` 100% open with a continuous top stator wire bevel (`Z = 0.80` to `3.00mm`, overlapping the bottom trough with zero blind floor) and a `4.00 × 3.80mm` **Side-Entry Wire Gate** extending `2.30mm` clear past the `r = 5.10mm` motor pad perimeter into the under-strut trough.
2. **Stage 2 — Protected Under-Strut Wire U-Channel (`45° Self-Supporting Crown & Zero Prop-Strike Ceiling`)**:
   - In all 4 ducts, Spoke 1 (`4.0mm` wide × `2.4mm` tall) points directly along `inward_ang` toward the Flight Controller and integrates a `2.20mm` wide underside wire U-channel with a **`45°` self-supporting chamfered crown (`Z = 0.00` to `1.45mm`, tapering to a `1.20mm` bridge apex)** shielded from the spinning `31mm` propeller blades above by a continuous, unbroken `0.95–1.15mm` thick solid `PETG-CF` roof (`Z = 1.25/1.45` to `2.40mm`).
3. **Stage 3 — Through-Duct-Wall Base Tunnel (`r_motor = 3.2 to 18.8 mm`)**:
   - The `2.20 × 1.45mm` crowned wire U-channel passes straight underneath the base of the `Grizzly-Ring 65` duct wall into the chassis pass-through window while preserving a 100% continuous `32.6mm` inner cylindrical duct wall above `Z = 1.25mm`.
4. **Stage 4 — Unobstructed `3.30 × 6.50 mm` Vertical `JST-1.25mm` Pass-Through Windows (`100% Outside Battery Bay`) & Full-Height `2.40 mm` Twin-Beam Rails**:
   - Dedicated **`3.30mm` wide × `6.50mm` long vertical `JST-1.25mm` pass-through windows** (`|x| = 7.55` to `10.85mm`, `|y| = 3.60` to `10.10mm`) sit 100% outside the `|x| <= 7.50mm` Battery Bay walls and `1.40mm` Battery Roof, framed by full-height `2.40mm` structural box-beams and twin-beam diagonal rails. Both 2-pin (`4.25 × 2.85mm`) and 3-pin (`5.50 × 2.85mm`) `JST-1.25mm` (`Molex PicoBlade`) plugs pass vertically through with zero battery-wall obstruction, feeding into an under-FC wire channel and outboard **Bottom-JST Header Relief Pockets** (`Z = 1.40` to `5.50mm`, `4.10mm` vertical clearance).
5. **Stage 5 — Universal Bottom-Mount & Top/Edge-Mount `25.5×25.5mm` 1S AIO Clearances**:
   - Flat `2.40mm` cardinal standoff gussets + vertical `5.50mm` M2 pillars eliminate sloped ramps beneath the FC perimeter, while flush `5.20mm` wide outer-duct diagonal flats (`r = 13.0` to `15.1mm`, `Z = 2.40` to `8.40mm`) create a `0.60mm` clearance gap outside the `29.0 × 29.0mm` diamond FC edges (`r = 14.50mm`) so wires route effortlessly to either bottom-mounted `JST-1.25mm` headers (`CubBrain-65 AIO`) or top/edge-mounted headers and solder pads on off-the-shelf `25.5 × 25.5mm` 1S ELRS AIO boards.

---

## 4. Dual-Drivetrain Mass Budget & `CubBrain-65 AIO` Pinout Matrix

### 4.1 Verified Component-by-Component Mass Budget (`0.1g` Precision)

| Subsystem Component | **Trim A: `MiniCub65 Brushed BNF` (`0615`)** | **Trim B: `MiniCub65 Pro Brushless BNF` (`0702SE`)** | Filament / Material Spec |
| :--- | :---: | :---: | :--- |
| **`CubBrain-65 AIO` 4L `TG170` PCBA (`29×29×7.6mm`) + `BT2.0` Lead** | `4.2 g` | `4.1 g` | $29.0 \times 29.0 \times 1.0\text{ mm}$ `JLC04101H-3313` (`1oz/0.5oz` Cu), `ENIG`, `130` SMT parts |
| **`Grizzly-Ring 65` Octa-Facet Airframe** | `4.1 g` | `3.8 g` | **Tier 1 `Bambu PETG-CF`** (P2S #1 AMS Slot 1, `265°C` / `70°C`) |
| **4× Propulsion Motors (`JST-1.25mm` Plug-and-Play)** | `6.4 g` *(4× `CubCore 0615 19,500KV` @ `1.60g`)* | `6.0 g` *(4× `CubSpin 0702SE 25,000KV` @ `1.50g`)* | Solder-free bottom `JST-1.25mm` 2-pin (Brushed) / 3-pin (Brushless) |
| **`Osito CubCap` Bear-Ear Louvered Canopy** | `1.6 g` | `1.6 g` | **Tier 4 `Bambu TPU for AMS 68D`** (Slot 4) or `TPU 95A HF` (P2S #2 Ext) |
| **`CubVision 800TVL` Micro FPV Cam + `5.8GHz` Dipole Whip** | `1.1 g` | `1.1 g` | `1.1g` Global-WDR CMOS cam (`JST-SH` 3-pin) + brass whip |
| **4× `31mm` PC Ducted Props + 4× M2 Silicone Grommets + Screws** | `0.8 g` | `0.8 g` | `4 × 0.12g` props + `0.32g` M2 hardware |
| **TOTAL DRY BNF MASS (Without Battery)** | **`18.2 g`** | **`17.4 g`** | **Exact Sum of Rows 1–6** |
| **`CubCell 300mAh 1S 80C LiHV` Pack (`BT2.0`)** | `+8.2 g` | `+8.2 g` | `3.8V / 4.35V LiHV` (`1.14 Wh`, UL 1642 / UN 38.3 certified) |
| **TOTAL ALL-UP FLYING WEIGHT (`AUW`)** | **`26.4 g`** | **`25.6 g`** | **100% `<50g` Youth STEM Safe & `<250g` FAA Part 89 Exempt** |

---

### 4.2 Complete `CubBrain-65 AIO` (`STM32F411CEU6`) Pinout, Timer & Conflict-Free DMA Matrix

| MCU Pin | GPIO | Function | Peripheral / Timer / DMA Stream | Connected Component / Net (`CubBrain-65 REV 2.2`) |
| :---: | :---: | :--- | :--- | :--- |
| **10** | `PA0` | `MOTOR 1` (Rear Right) | `TIM2_CH1` (`DMA1 Stream 5 Ch 3`) | `U5` `EFM8BB21` M1 DShot300 Input (`C2D_M1`/`C2CK_M1` pogo pads) |
| **11** | `PA1` | `MOTOR 2` (Front Right) | `TIM2_CH2` (`DMA1 Stream 6 Ch 3`) | `U6` `EFM8BB21` M2 DShot300 Input (`C2D_M2`/`C2CK_M2` pogo pads) |
| **46** | `PB9` | `MOTOR 3` (Rear Left) | `TIM4_CH4` (`TIM4_UP` Burst DMA) | `U7` `EFM8BB21` M3 DShot300 Input (`C2D_M3`/`C2CK_M3` pogo pads) |
| **45** | `PB8` | `MOTOR 4` (Front Left) | `TIM4_CH3` (`DMA1 Stream 7 Ch 2`) | `U8` `EFM8BB21` M4 DShot300 Input (`C2D_M4`/`C2CK_M4` pogo pads) |
| **18** | `PB0` | `ADC_BATT` (`VBAT`) | `ADC1_IN8` (**`DMA2 Stream 4 Ch 0`**) | `R1/R2` ($10\text{ k}\Omega / 10\text{ k}\Omega$, $2:1$ Divider, `vbat_scale=20 / vbat_divider=10`) |
| **19** | `PB1` | `ADC_CURR` (`IBAT`) | `ADC1_IN9` (**`DMA2 Stream 4 Ch 0`**) | `U9` `INA199A1DCKR` ($50\text{ V/V}$) + `R_SHUNT` $5\text{ m}\Omega$ `1206` (`ibata_scale=2500`) |
| **14–17, 3** | `PA4–PA7, PC14` | `SPI1` Gyro + `EXTI14` | `SPI1` (`DMA2 Stream 0 RX / Stream 3 TX`) | `U2` Bosch `BMI270` (`LGA-14`, `LP5907` `+3V3_GYRO`, `CW90` + `align_board_yaw = 450`) |
| **25–28** | `PB12–PB15` | `SPI2` Analog OSD | `SPI2` Hardware Bus | `U4` `AT7456E` OSD $\rightarrow$ `C31/R9` ($75\,\Omega$) $\rightarrow$ `U13` `RTC6705` (`+3V3_DIG`) + `U14` `RTC6659E` (`+5V_CLEAN`) |
| **38–43, 2** | `PA15, PB3–PB7, PC13` | `SPI3` ExpressLRS 2.4GHz | `SPI3` Hardware Bus + `EXTI6` (`DIO1`) | `U3` Semtech `SX1280IMLTRT` (`Pin 21 = RFIO`, `0.18 mm` `50 Ω` CPWG) + $52\text{ MHz}$ TCXO + `ANT1` |
| **12** | `PA2` | `UART2 TX` (`VTX_SA`) | Hardware `USART2` | `U15` `EFM8BB10F8G` (`Pin 15`) SmartAudio v2.1 VTX controller (`C2D_VTX`/`C2CK_VTX` pogo pads) |
| **32 / 33** | `PA11 / PA12` | `USB_DM / USB_DP` | Full-Speed `USB OTG FS` | `D1` `USBLC6-2SC6` ESD $\rightarrow$ `J1` `TYPE-C-31-M-12` (`4× G85` shield slots + `2× Ø0.65mm` NPTH pegs + `5.1kΩ` `CC1/CC2`) |
| **34 / 37 / 7 / 44** | `PA13 / PA14 / NRST / PB2` | `SWDIO / SWCLK / NRST / BOOT0` | Serial Wire Debug & Factory Jig | `6×` `Ø0.60 mm` Top Pogo Test Pads (`TP_SWDIO`, `TP_SWCLK`, `TP_NRST`, `TP_BOOT0`, `TP_3V3`, `TP_GND`) |

---

## 5. Complete Landed BOM, Unit Economics & Turnkey Fab Package

### 5.1 Unified Landed Unit BOM (`Trim A: Brushed BNF` vs. `Trim B: Pro Brushless BNF`)

| # | Subsystem / Component | Batch of 25 (Pilot) | Batch of 100 (Standard) | Batch of 500 (Scale) |
| :-: | :--- | :-: | :-: | :-: |
| **1** | **Turnkey 4-Layer `TG170` PCBA (`CubBrain-65 AIO` — 130 SMT Parts)** | `$21.40` (BR) / `$22.35` (BL) | **`$16.85` (BR) / `$17.60` (BL)** | `$13.90` (BR) / `$14.50` (BL) |
| **2** | **4× Propulsion Motors (`CubCore 0615 19,500KV` vs. `CubSpin 0702SE 25,000KV`)** | `$4.60` (BR) / `$11.60` (BL) | **`$3.60` (BR) / `$9.40` (BL)** | `$2.80` (BR) / `$7.60` (BL) |
| **3** | **`CubVision 800TVL 1.1g` Micro FPV Camera + `5.8GHz` Dipole Whip** | `$5.80` | **`$4.65`** | `$3.90` |
| **4** | **In-House 2× Bambu P2S Print (`Grizzly-Ring 65 PETG-CF` + `CubCap TPU 68D`)** | `$0.50` (`$0.32 + $0.18`) | **`$0.43` (`$0.28 + $0.15`)** | `$0.37` (`$0.24 + $0.13`) |
| **5** | **31mm 4-Blade Props (4+2), M2 Silicone Grommets, `BT2.0` + `PH2.0` Adapter** | `$2.05` | **`$1.57`** | `$1.23` |
| **6** | **Retail BNF Box, Die-Cut EVA Foam, QR Card, Freight & Pogo-Jig QA** | `$3.55` | **`$2.75`** | `$2.00` |
| — | **TOTAL LANDED BNF COST (`Trim A: Classroom Brushed BNF`)** | **`$37.90`** | **`$29.85`** | **`$24.20`** |
| — | **TOTAL LANDED BNF COST (`Trim B: Pro Brushless BNF`)** | **`$45.85`** | **`$36.40`** | **`$29.60`** |

### 5.2 Retail D2C & STEM Classroom SKU Margin Matrix (Gate 4: `>= 60%` Gross Margin)

| SKU Code & Product Name | Target Channel | Landed BOM (`@ Qty 100`) | Selling Price | Gross Profit | Gross Margin % |
| :--- | :--- | :-: | :-: | :-: | :-: |
| **SKU 1A: `MiniCub65 Classroom Brushed BNF` (D2C)** | `ositodrone.com` & Camp Parents | `$29.85` | **`$99.99`** | **`+$70.14`** | **`70.1%`** ✅ |
| **SKU 1B: `MiniCub65 Classroom Brushed BNF` (EDU Fleet)** | Schools & Makerspaces (10+ Units) | `$29.85` | **`$89.00`** | **`+$59.15`** | **`66.5%`** ✅ |
| **SKU 2A: `MiniCub65 Pro Brushless BNF` (D2C)** | FPV Racers & Advanced Youth Pilots | `$36.40` | **`$119.99`** | **`+$83.59`** | **`69.7%`** ✅ |
| **SKU 2B: `MiniCub65 Pro Brushless BNF` (EDU Fleet)** | High School CTE & Racing Clubs | `$36.40` | **`$105.00`** | **`+$68.60`** | **`65.3%`** ✅ |
| **SKU 3: `MiniCub65 RTF Classroom 10-Pack Pod`** | **CA ELO-P / SF DCYF Object Code 4300** *(10× MiniCub65 + 10× T8L Radios + 30× 300mAh LiHV + 2× 6-Port Chargers)* | **`$645.00`** | **`$1,995.00`** | **`+$1,350.00`** *(+$340/Founder)* | **`67.7%`** ✅ |

### 5.3 Self-Contained Turnkey PCBA Fabrication & Verification Package (`pcb/`)
- [`pcb/1_Gerber_OSITO_65_1S_ELRS_AIO_FAB_PACKAGE.zip`](./pcb/1_Gerber_OSITO_65_1S_ELRS_AIO_FAB_PACKAGE.zip) — 14-file 4-Layer `TG170` RS-274X Gerber (`F.Cu`, `In1.Cu`, `In2.Cu`, `B.Cu`, `F.Mask`, `B.Mask`, `F.Paste`, `B.Paste`, `F.Silkscreen`, `B.Silkscreen`, `Edge.Cuts`), 2 Excellon drill files (`PTH.drl` with `4× G85` USB-C oval slots & `NPTH.drl` with `4× Ø2.10mm` M2 + `2× Ø0.65mm` USB-C pegs), and `00_FAB_NOTES_JLC04101H_3313_IMPEDANCE_STACKUP.txt` (`0` DRC violations, `123/123` active nets, `3,029` routed copper segments, `425` plated vias).
- [`pcb/2_BOM_OSITO_65_1S_ELRS_AIO_Turnkey_PCBA.csv`](./pcb/2_BOM_OSITO_65_1S_ELRS_AIO_Turnkey_PCBA.csv) — 53-line (`53` component rows / `130` SMT parts) turnkey BOM with exact LCSC part numbers (`U1–U15`, `Q1A–Q4B`, `Q_DRV1–Q_DRV4`, `J_M1–J_M4`, zero `85°C` `X5R` parts).
- [`pcb/3_CPL_OSITO_65_1S_ELRS_AIO_PickAndPlace.csv`](./pcb/3_CPL_OSITO_65_1S_ELRS_AIO_PickAndPlace.csv) — Top (`67` parts) + Bottom (`63` parts) = `130` SMT parts pick-and-place centroid file (`100%` 1-to-1 BOM parity).
- [`pcb/OSITO_65_1S_ELRS_AIO.kicad_pcb`](./pcb/OSITO_65_1S_ELRS_AIO.kicad_pcb) — Native KiCad 8.0 4-layer routed PCB layout (`672` electrical/fiducial pads + `4` M2 NPTH + `2` USB-C NPTH = `678` total pads, `123/123` active nets, `3,029` copper trace segments, `425` plated vias, `5` inner plane zones, `0.03 mm` mask clearance).
- [`pcb/route_and_verify_cubbrain65_pcb.py`](./pcb/route_and_verify_cubbrain65_pcb.py) — Deterministic 4-layer PCB footprint generator (`B.Cu` X-mirrored CCW bottom-view handedness), multi-wave copper trace router, RS-274X Gerber exporter, and 15-category automated JLCPCB DRC engine.
- [`pcb/render_photorealistic_cubbrain65_pcb.py`](./pcb/render_photorealistic_cubbrain65_pcb.py) — Coordinate-exact photorealistic assembled Top (`F.Cu`) & Bottom (`B.Cu`) PCBA renderer (`CubBrain65_AIO_Photorealistic_Top_and_Bottom_PCBA.png`).
- [`pcb/drc_verification_report.json`](./pcb/drc_verification_report.json) — Machine-readable 15-category DRC audit report (`drc_passed: true`, `0` violations across `123/123` active nets).

---

## 6. `CubBrain-65 AIO` (`REV 2.2`) 4-Layer `JLC04101H-3313` PCB Routing Architecture & Automated DRC Audit

### 6.1 4-Layer `TG170` Controlled-Impedance Stackup (`JLC04101H-3313`) & Layer-by-Layer Routing Metrics

| Layer ID | Copper Weight & Function | Component & Copper Features | Routed Segments | Plated Vias / Antipads |
| :--- | :--- | :--- | :---: | :---: |
| **`L1: F.Cu` (Top Layer)** | **`1 oz` (`35 µm`) Fine-Pitch Signal, Gyro, OSD & `2.4GHz` `50 Ω` CPWG RF** | `67` Top SMT parts + `3` Top optical fiducials (`FID_T1–T3`) + `6` SWD/Boot/3V3/GND pogo pads + `2` `BT2.0` PTH pads (`313` Top pads): `U1` (`STM32F411CEU6` `Pin 22 = VCAP1`, `Pin 23 = VSS`), `U2` (`BMI270` `LGA-14`), `U3` (`SX1280` `Pin 21 = RFIO` + `0.18 mm` `50 Ω` CPWG feed to `L1_RF`/`ANT1` with 4-layer `ANT1` copper keepout), `U4` (`AT7456E` OSD with RC-filtered `OSD_DVDD`/`OSD_AVDD` + AC-coupled `75 Ω` video `C31` $\rightarrow$ `R9`), `U11` (`AP2112K-3.3`), `U12` (`LP5907MFX-3.3` Gyro LDO), `D1` (`USBLC6-2SC6`), `Q1A–Q2B` (`AO4614B` M1/M2 H-bridges `0.35–1.20mm` straps), `J1` (`TYPE-C-31-M-12` 12-Pin USB-C with `4× G85` oval shield slots, `2× Ø0.65mm` NPTH pegs & `5.1kΩ` `CC1`/`CC2` pull-downs). | **`1,114` segments** | **`425` plated vias** (`Ø0.38mm` pad / `Ø0.20mm` drill) |
| **`L2: In1.Cu` (Inner Layer 1)** | **`0.5 oz` (`17.5 µm`) Continuous Solid `GND` Reference Plane (`3.92 mil` `3313` Prepreg)** | Full-board `27.8 × 27.8 mm` chamfered solid `GND` reference shield (notched under `ANT1` `|x| < 2.39 mm, y > 12.15 mm`) providing unbroken `50 Ω` CPWG return path beneath `2.4GHz` ELRS, `Ø0.62 mm` (`%LPC*%`) antipads around foreign vias, `Ø1.15 mm` antipads around USB-C NPTH pegs, collision-checked 4-spoke (`0.15 mm`) thermal reliefs on `GND` vias, and `0.24 mm` clearance moats around foreign inner buses. | **`544` segments** + **1 Solid `GND` Pour** | **`425` vias** (`4-spoke` thermal reliefs + `Ø0.62mm` antipads) |
| **`L3: In2.Cu` (Inner Layer 2)** | **`0.5 oz` (`17.5 µm`) 4-Domain Split Power Polygon Plane + Inner Crossovers** | 4 non-overlapping `%LPD*%` polygon pours (`>= 0.40 mm` isolation trenches, notched under `ANT1`: `VBAT_ESC` High-Current 1S Bus, `+5V_CLEAN` Filtered OSD/VTX PA Rail, `+3V3_DIG` Digital Logic & `RTC6705` Rail, `+5V_RAW` `TPS63020` Buck-Boost Output) + low-inductance decoupling vias and shielded inner-layer DShot300 / SPI crossovers. | **`445` segments** + **4 Power Pours** | **`425` vias** (`4-spoke` power thermal reliefs + `Ø0.62mm` antipads) |
| **`L4: B.Cu` (Bottom Layer)** | **`1 oz` (`35 µm`) `B.Cu`-Mirrored H-Bridge ESC Bus & `5.8GHz` `50 Ω` CPWG VTX** | `63` Bottom X-mirrored SMT parts (`CCW` bottom-view handedness) + `3` Bottom optical fiducials (`FID_B1–B3`) + `10` C2 programming pogo pads (`TP_C2D_*` & `TP_C2CK_*`) + `2` `BT2.0` PTH pads (`365` Bottom pads): `U5–U8` (`EFM8BB21` ESC MCUs), `Q3A–Q4B` (`AO4614B` M3/M4 H-bridges), `Q_DRV1–Q_DRV4` (`BC847BS`), `U9` (`INA199A1DCKR` + `R_SHUNT` `5mΩ`), `U10` (`TPS63020DSJR` `5V 2A` Buck-Boost), `U13` (`RTC6705` on `+3V3_DIG`) + `U14` (`RTC6659E` `5.8GHz` PA on `+5V_CLEAN` + `0.18 mm` `50 Ω` CPWG feed), `U15` (`EFM8BB10F8G` SmartAudio MCU), and `J_M1–J_M4` at `(±5.20, ±12.20) mm`. | **`926` segments** | **`425` plated vias** + `2× Ø1.00mm` `BT2.0` PTH + `4× G85` USB-C slots |
| **TOTAL (`JLC04101H-3313`)** | **`1.00 mm` `TG170` FR-4 (`1oz/0.5oz`, `ENIG` Gold, Matte Black `+0.03mm` Mask)** | **`130` CPL SMT Parts + `6` Fiducials + `16` Pogo Pads + `2` PTH (`672` Electrical/Fiducial Pads across `123/123` Active Nets = `100.0%` Routed)** | **`3,029` segments (`2,419.92 mm`)** | **`425` Plated Vias + `4× Ø2.10mm` M2 + `2× Ø0.65mm` USB-C NPTH** |

### 6.2 Automated 15-Category Design Rule Check (DRC) & JLCPCB DFM Verification Summary (`drc_verification_report.json`)

| DRC Category | Manufacturing Design Rule | Verified Minimum / Count | Worst-Case Inspected Pair / Feature | Verdict |
| :--- | :--- | :---: | :--- | :---: |
| **1. Netlist Connectivity & Shorts** | `100%` of `123` Active Nets Connected (Physical + Etched Plane), `0` Shorts | **`123 / 123` (`100.0%`), `0` Shorts** | All `672` pads + `425` vias + `0.05mm` etched inner planes verified via Union-Find | **PASS** ✅ |
| **2. Pad-to-Pad & Matte-Black Mask Dam** | $\ge 0.1000\text{ mm}$ P2P & $\ge 0.1000\text{ mm}$ Solder-Mask Dam (`+0.03mm/side`) | **`0.1750 mm` P2P / `0.1200 mm` Mask Dam** | `D_M3.1` $\leftrightarrow$ `J_M3.SH1` (`0` P2P & `0` Mask-Dam Violations across `0.50mm` QFNs) | **PASS** ✅ |
| **3. Trace-to-Pad Clearance** | $\ge 0.1000\text{ mm}$ (`4.0 mil`) Trace-to-Foreign-Pad | **`0.1024 mm`** (`0` Violations) | `seg(+3V3_DIG, B.Cu)` $\leftrightarrow$ `Q_DRV4.6(M4_PG1)` | **PASS** ✅ |
| **4. Via-to-Pad Clearance** | $\ge 0.1000\text{ mm}$ (`4.0 mil`) Via-Ring-to-Foreign-Pad | **`0.1150 mm`** (`0` Violations) | `via(M3_PG1 @ -9.25, -13.12)` $\leftrightarrow$ `R18.2(M3_PG2)` | **PASS** ✅ |
| **5. Trace-to-Via Clearance** | $\ge 0.1000\text{ mm}$ (`4.0 mil`) Trace-to-Foreign-Via-Ring | **`0.1150 mm`** (`0` Violations) | `seg(M4_NPN_B1, B.Cu)` $\leftrightarrow$ `via(OSD_CS @ -6.30, 1.68)` | **PASS** ✅ |
| **6. Trace-to-Trace Clearance** | $\ge 0.1000\text{ mm}$ (`4.0 mil`) Same-Layer Trace Spacing | **`0.1028 mm`** (`0` Violations) | `seg(NRST, In2.Cu)` $\leftrightarrow$ `seg(ELRS_RESET, In2.Cu)` | **PASS** ✅ |
| **7. Via-to-Via, Drill & Plane Iso** | $\ge 0.1000\text{ mm}$ Via-to-Via / $\ge 0.2000\text{ mm}$ Drill / $\ge 0.4000\text{ mm}$ In2 Iso | **`0.1152 / 0.2050 / 0.4000 mm`** (`0` Violations) | `via(SPI3_SCK @ 3.23, 8.18)` $\leftrightarrow$ `via(ELRS_VDD_OUT @ 3.24, 7.68)` | **PASS** ✅ |
| **8. Edge.Cuts, M2 & USB-C Peg Keepout** | $\ge 0.4500\text{ mm}$ Edge/M2 & $\ge 0.2000\text{ mm}$ USB-C `Ø0.65mm` NPTH Peg Clr | **`0.4600 / 0.4598 / 0.2053 mm`** (`0` Violations) | `29.0 × 29.0 mm` (`R1.75 mm`), $4\times (\pm 12.75, \pm 12.75)\text{ mm}$ M2, $2\times (\pm 2.89, -9.65)\text{ mm}$ Pegs | **PASS** ✅ |
| **9. 2-Terminal Series Passive Audit** | Pin 1 $\ne$ Pin 2 Across All `85` Two-Pin Passives (`R*`, `C*`, `L*`, `D*`, `F*`) | **`0 / 85` Shorts** | Every decoupling cap, series filter (`R6`/`R7`), AC cap (`C31`/`R9`), and inductor (`L_BB`/`L_LC`/`L1_RF`) verified | **PASS** ✅ |
| **10. High-Current Ampacity Audit** | Zero `< 0.35 mm` Single-Trace Neck-Downs on Motor Phase & Power Nets | **`>= 0.35 mm` Min (`0.35–1.20 mm` Range)** | All 13 high-current nets (`M1_P1..M4_P2`, `VBAT_RAW`, `VBAT_ESC`, `+5V_RAW`, `BEC_SW_L1/L2`) $\ge 0.35\text{ mm}$ | **PASS** ✅ |
| **11. Component Courtyard & B.Cu Handedness** | `0` Courtyard Overlaps (`67` Top / `63` Bottom) & `100%` `B.Cu` CCW Mirroring | **`0` Collisions, `7/7` `B.Cu` QFN CCW** | All `130` CPL bodies checked; `U5–U8`, `U13`, `U14`, `U15` verified CCW in bottom view | **PASS** ✅ |
| **12. Fiducials, C2 Pogo, Paste & Silkscreen** | `6×` Fiducials, `10×` C2 Pogo, `11×` `4×` Windowed QFN Paste (`58%`), `0` Silk Overlaps | **`6` Fiducials, `10` C2, `11/11` QFN, `0` Silk** | `28` manual/test/fiducial pads excluded from paste; `4× G85` USB-C shield slots; `ANT1` 4L keepout | **PASS** ✅ |

### 6.3 High-Resolution Photorealistic PCBA & 4-Layer Routed PCB Inspection Maps (`pcb/`)

| Photorealistic Assembled PCBA (`Top F.Cu + Bottom B.Cu`) | 4-Layer Master Engineering Map (`All 4 Copper Layers`) | Layer 1 (`F.Cu` — Top `1oz` MCU, Gyro, `2.4GHz` ELRS & OSD) |
| :---: | :---: | :---: |
| ![Photorealistic Top and Bottom PCBA](./pcb/CubBrain65_AIO_Photorealistic_Top_and_Bottom_PCBA.png) | ![4-Layer Master PCB Map](./pcb/OSITO_CUBBRAIN65_AIO_4Layer_Routing_Master_Map.png) | ![Layer 1 Top F.Cu Routing](./pcb/PCB_Layer1_Top_FCu_Routing.png) |
| *Coordinate-exact `REV 2.2` assembled Top (`67` SMT + `3` fiducials) & Bottom (`63` X-mirrored SMT + `10` C2 pogo pads) PCBA.* | *Quad-view inspection map of `JLC04101H-3313` (`123/123` nets, `3,029` segments, `425` vias, `0` DRC errors).* | *Top `1oz` copper routing (`1,114` segments): `STM32F411`, `BMI270`, `SX1280` `50 Ω` `0.18mm` CPWG RF feed, `AT7456E` OSD, and `Q1A–Q2B`.* |

| Layer 2 (`In1.Cu` — `0.5oz` Solid `GND` Reference Plane) | Layer 3 (`In2.Cu` — `0.5oz` 4-Domain Split Power Plane) | Layer 4 (`B.Cu` — Bottom `1oz` Mirrored ESC & `5.8GHz` VTX) |
| :---: | :---: | :---: |
| ![Layer 2 In1.Cu GND Plane](./pcb/PCB_Layer2_In1_GND_Plane.png) | ![Layer 3 In2.Cu Power Planes](./pcb/PCB_Layer3_In2_Power_Planes.png) | ![Layer 4 Bottom B.Cu Routing](./pcb/PCB_Layer4_Bottom_BCu_ESC_and_VTX.png) |
| *`29 × 29 mm` solid `GND` shield (notched under `ANT1`) with 4-spoke thermal reliefs, `Ø0.62 mm` antipads, and `544` inner bus segments.* | *4 isolated power pours (`>= 0.40 mm` isolation, notched under `ANT1`: `VBAT_ESC`, `+5V_CLEAN`, `+3V3_DIG`, `+5V_RAW`) + `445` crossovers.* | *Bottom `1oz` mirrored copper (`926` segments): `EFM8BB21` `U5–U8`, `Q3A–Q4B`, `TPS63020`, `3.3V` `RTC6705` + `RTC6659E` VTX, and `10×` C2 pads.* |

